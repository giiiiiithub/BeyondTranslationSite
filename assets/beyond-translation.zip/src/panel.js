const elements = {
  optionsButton: document.getElementById("optionsButton"),
  noticeOptionsButton: document.getElementById("noticeOptionsButton"),
  emptyState: document.getElementById("emptyState"),
  workbench: document.getElementById("workbench"),
  selectedText: document.getElementById("selectedText"),
  setupNotice: document.getElementById("setupNotice"),
  errorBox: document.getElementById("errorBox"),
  loadingBox: document.getElementById("loadingBox"),
  analysisOutput: document.getElementById("analysisOutput"),
  reanalyzeButton: document.getElementById("reanalyzeButton"),
  copyButton: document.getElementById("copyButton"),
  chatLog: document.getElementById("chatLog"),
  chatForm: document.getElementById("chatForm"),
  questionInput: document.getElementById("questionInput"),
  askButton: document.getElementById("askButton"),
  licenseBanner: document.getElementById("licenseBanner"),
  licenseText: document.getElementById("licenseText"),
  getTokenLink: document.getElementById("getTokenLink"),
  activationForm: document.getElementById("activationForm"),
  activationInput: document.getElementById("activationInput"),
  activationBtn: document.getElementById("activationBtn")
};

let currentSession = null;
let settingsSummary = null;
let licenseState = null;
let analysis = "";
let history = [];
let isBusy = false;
let activeFollowUpStreamId = "";
let activeFollowUpBubble = null;

document.addEventListener("DOMContentLoaded", init);

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName !== "local") return;
  if (changes.settings) {
    refreshSettings().catch(showError);
  }
  if (changes.activeSession) {
    loadSession({ autoAnalyze: true });
  }
  if (changes.licenseV1 || changes._quotaExhausted || changes._quotaExhaustedMsg) {
    refreshLicense();
  }
});

chrome.runtime.onMessage.addListener((message) => {
  if (message?.type === "selection-ready") {
    loadSession({ autoAnalyze: true });
    return;
  }

  if (message?.type === "modelProgress") {
    handleModelProgress(message);
  }

  if (message?.type === "guideActivation") {
    elements.activationInput.focus();
    elements.licenseBanner.scrollIntoView({ behavior: "smooth" });
  }

  if (message?.type === "quotaStateChanged") {
    refreshLicense();
  }
});

async function init() {
  elements.optionsButton.addEventListener("click", openOptions);
  elements.noticeOptionsButton.addEventListener("click", openOptions);
  elements.reanalyzeButton.addEventListener("click", () => runAnalysis({ force: true }));
  elements.copyButton.addEventListener("click", copyAnalysis);
  elements.chatForm.addEventListener("submit", submitQuestion);
  elements.questionInput.addEventListener("keydown", (event) => {
    if (event.key === "Enter" && (event.ctrlKey || event.metaKey || event.altKey)) {
      event.preventDefault();
      elements.chatForm.dispatchEvent(new Event("submit", { cancelable: true }));
    }
  });

  // License
  elements.activationBtn.textContent = "确认";
  elements.activationBtn.disabled = false;
  elements.activationInput.disabled = false;
  elements.activationBtn.addEventListener("click", submitActivation);
  elements.activationInput.addEventListener("keydown", (event) => {
    if (event.key === "Enter") submitActivation();
  });

  await refreshLicense();
  refreshTokenBalance().catch(function () {});
  refreshSettings()
    .then(() => loadSession({ autoAnalyze: true }))
    .catch(showError);
}

async function refreshSettings() {
  settingsSummary = await sendMessage("getSettingsSummary");
  // providerStatus removed
}

// ── License ────────────────────────────────────

async function refreshLicense() {
  licenseState = await sendMessage("getLicenseStatus");
  renderLicense();
}

async function refreshTokenBalance() {
  try {
    await sendMessage("refreshTokenBalance");
  } catch (e) { /* storage.onChanged 会触发 refreshLicense */ }
}

function renderLicense() {
  var state = licenseState || {};
  var banner = elements.licenseBanner;
  var textEl = elements.licenseText;

  // 每次渲染时重置按钮状态（避免页面刷新的残留）
  elements.activationBtn.textContent = "确认";
  elements.activationBtn.disabled = false;
  elements.activationInput.disabled = false;

  if (state.active && state.plan_type === "token") {
    banner.className = "license-banner paid";
    elements.activationForm.classList.add("hidden");
    if (state.token_remaining != null) {
      textEl.textContent = "Token 剩余 " + formatTokenAmount(state.token_remaining) + " / " + formatTokenAmount(state.token_quota);
    } else {
      textEl.textContent = "Token 套餐";
    }
  } else {
    elements.activationForm.classList.remove("hidden");
    if (state.free_quota_exhausted) {
      banner.className = "license-banner free";
      textEl.textContent = state.free_quota_exhausted_msg || "免费额度已用完";
    } else if (state.plan_type === "token" && state.tokens_exhausted) {
      banner.className = "license-banner free";
      textEl.textContent = "Token 已用完，请购买新 Token";
    } else {
      banner.className = "license-banner free";
      textEl.textContent = "未激活";
    }
  }
}

async function submitActivation() {
  var code = elements.activationInput.value.trim();
  if (!code) return;

  elements.activationBtn.disabled = true;
  elements.activationInput.disabled = true;
  elements.activationBtn.textContent = "验证中...";

  try {
    var result = await sendMessage("activateLicense", { activation_code: code });
    if (result.valid) {
      await refreshLicense();
      elements.activationInput.value = "";
    } else {
      elements.licenseText.textContent = "激活码无效: " + (result.reason || "未知");
    }
  } catch (err) {
    elements.licenseText.textContent = "验证失败: " + (err.message || "");
  } finally {
    elements.activationBtn.textContent = "确认";
    elements.activationBtn.disabled = false;
    elements.activationInput.disabled = false;
  }
}

// ── Session ───────────────────────────────────

async function loadSession({ autoAnalyze }) {
  hideError();
  await refreshSettings();

  const session = await sendMessage("getActiveSession");
  if (!session?.text) {
    currentSession = null;
    analysis = "";
    history = [];
    elements.emptyState.classList.remove("hidden");
    elements.workbench.classList.add("hidden");
    return;
  }

  const isNewSession = currentSession?.id !== session.id;
  currentSession = session;
  analysis = session.analysis || "";
  elements.selectedText.textContent = "";
  elements.selectedText.appendChild(document.createTextNode(session.text));
  if (session.text) {
    elements.selectedText.appendChild(buildSpeakGroup(session.text));
  }
  if (session.analysisData) {
    renderRichAnalysis(elements.analysisOutput, session.analysisData);
  } else {
    renderMarkdown(elements.analysisOutput, analysis || "等待分析...");
  }
  elements.emptyState.classList.add("hidden");
  elements.workbench.classList.remove("hidden");

  if (isNewSession && !activeFollowUpStreamId) {
    history = [];
    renderHistory();
  }

  elements.setupNotice.classList.add("hidden");

  if (autoAnalyze && isNewSession && !analysis) {
    await runAnalysis({ force: false });
  }

  if (isNewSession) {
    elements.questionInput.scrollIntoView({ behavior: "smooth", block: "center" });
  }
}

async function runAnalysis({ force }) {
  if (!currentSession?.text || isBusy) return;
  if (!force && analysis) return;

  const sessionId = currentSession.id;
  setBusy(true);
  hideError();
  elements.analysisOutput.textContent = "";

  try {
    const response = await sendMessage("analyze", {
      sessionId,
      text: currentSession.text
    });
    if (currentSession?.id !== sessionId) return;
    analysis = response.content || "";
    renderMarkdown(elements.analysisOutput, analysis || "模型没有返回内容。");
    history = [];
    renderHistory();
  } catch (error) {
    if (currentSession?.id !== sessionId) return;
    renderMarkdown(elements.analysisOutput, analysis || "");
    showError(error);
  } finally {
    setBusy(false);
  }
}

async function submitQuestion(event) {
  event.preventDefault();
  if (!currentSession?.text || isBusy) return;

  const question = elements.questionInput.value.trim();
  if (!question) return;

  elements.questionInput.value = "";
  const streamId = crypto.randomUUID();
  const priorHistory = history.slice();
  addHistoryItem("user", question);
  const placeholder = addHistoryItem("assistant", "正在回答...");
  activeFollowUpStreamId = streamId;
  activeFollowUpBubble = placeholder;
  setBusy(true);
  hideError();

  try {
    const response = await sendMessage("followUp", {
      payload: {
        selectedText: currentSession.text,
        analysis,
        history: priorHistory,
        question,
        sessionId: currentSession.id,
        streamId
      }
    });

    renderMarkdown(placeholder, response.content || "模型没有返回内容。");
    history[history.length - 1] = {
      role: "assistant",
      content: response.content || "模型没有返回内容。"
    };
  } catch (error) {
    const message = error?.message || String(error);
    renderMarkdown(placeholder, `## 追问失败\n\n${message}`);
    if (history[history.length - 1]?.role === "assistant") {
      history[history.length - 1].content = `## 追问失败\n\n${message}`;
    }
    showError(error);
  } finally {
    if (activeFollowUpStreamId === streamId) {
      activeFollowUpStreamId = "";
      activeFollowUpBubble = null;
    }
    setBusy(false);
  }
}

function addHistoryItem(role, content) {
  history.push({ role, content });
  const bubble = document.createElement("div");
  bubble.className = `bubble ${role}`;
  if (role === "assistant") {
    renderMarkdown(bubble, content);
  } else {
    bubble.textContent = content;
  }
  elements.chatLog.appendChild(bubble);
  elements.chatLog.scrollTop = elements.chatLog.scrollHeight;
  return bubble;
}

function renderHistory() {
  elements.chatLog.textContent = "";
  for (const item of history) {
    const bubble = document.createElement("div");
    bubble.className = `bubble ${item.role}`;
    if (item.role === "assistant") {
      renderMarkdown(bubble, item.content);
    } else {
      bubble.textContent = item.content;
    }
    elements.chatLog.appendChild(bubble);
  }
}

async function copyAnalysis() {
  if (!analysis) return;
  await navigator.clipboard.writeText(analysis);
  const previous = elements.copyButton.textContent;
  elements.copyButton.textContent = "已复制";
  setTimeout(() => {
    elements.copyButton.textContent = previous;
  }, 1200);
}

function setBusy(value) {
  isBusy = value;
  elements.loadingBox.classList.toggle("hidden", !value);
  elements.reanalyzeButton.disabled = value;
  elements.askButton.disabled = value;
  elements.questionInput.disabled = value;
}

function openOptions() {
  chrome.runtime.openOptionsPage();
}

function showError(error) {
  const message = error?.message || String(error);
  elements.errorBox.textContent = message;
  elements.errorBox.classList.remove("hidden");
}

function hideError() {
  elements.errorBox.textContent = "";
  elements.errorBox.classList.add("hidden");
}

function handleModelProgress(message) {
  const content = String(message.content || "").trim();
  if (!content) return;

  if (message.mode === "analysis" && currentSession?.id === message.sessionId) {
    analysis = content;
    renderMarkdown(elements.analysisOutput, content);
    return;
  }

  if (message.mode === "followUp" && message.streamId === activeFollowUpStreamId && activeFollowUpBubble) {
    renderMarkdown(activeFollowUpBubble, content);
    if (history[history.length - 1]?.role === "assistant") {
      history[history.length - 1].content = content;
    }
  }
}

function renderMarkdown(target, source) {
  if (window.MarkdownRenderer?.render) {
    window.MarkdownRenderer.render(target, source);
    return;
  }
  target.textContent = source;
}

async function sendMessage(action, payload = {}) {
  const response = await chrome.runtime.sendMessage({ action, ...payload });
  if (!response?.ok) {
    throw new Error(response?.error?.message || "扩展后台没有返回有效响应。");
  }
  return response.result;
}

// ── 富渲染（结构化数据 → DOM） ──────────────

function renderRichAnalysis(target, data) {
  target.textContent = "";
  target.classList.add("rich-analysis");

  if (data.translation) {
    target.appendChild(createSection("译文", data.translation));
  }

  const sa = data.sentenceAnalysis || {};
  if (sa.paraphrase) target.appendChild(createSection("白话理解", sa.paraphrase));
  if (sa.skeleton) target.appendChild(createSection("主干", sa.skeleton));
  if (sa.tone) target.appendChild(createSection("语气/语境", sa.tone));

  if (Array.isArray(sa.learningPoints) && sa.learningPoints.length) {
    target.appendChild(createListSection("易错点", sa.learningPoints.slice(0, 4)));
  }

  if (Array.isArray(sa.structure) && sa.structure.length) {
    const section = createRowSection("结构层级");
    for (const row of sa.structure.slice(0, 5)) {
      section.appendChild(buildAnalysisRow(row.label || "结构", row.text, row.note));
    }
    target.appendChild(section);
  }

  if (Array.isArray(data.words) && data.words.length) {
    const section = createRowSection("重点单词");
    for (const word of data.words) {
      section.appendChild(buildWordRow(word));
    }
    target.appendChild(section);
  }

  if (Array.isArray(data.phrases) && data.phrases.length) {
    const section = createRowSection("可复用表达");
    for (const phrase of data.phrases.slice(0, 4)) {
      section.appendChild(buildAnalysisRow(phrase.text, phrase.translation, phrase.note));
    }
    target.appendChild(section);
  }

  if (Array.isArray(data.examples) && data.examples.length) {
    const section = createRowSection("例句");
    for (const ex of data.examples.slice(0, 3)) {
      const row = buildAnalysisRow("例句", ex.english, ex.translation);
      const textEl = row.querySelector(".analysis-text");
      if (textEl) textEl.appendChild(buildSpeakGroup(ex.english));
      section.appendChild(row);
    }
    target.appendChild(section);
  }
}

function createSection(title, text) {
  const section = document.createElement("div");
  section.className = "analysis-section";
  const h = document.createElement("div");
  h.className = "analysis-section-title";
  h.textContent = title;
  section.appendChild(h);
  const p = document.createElement("p");
  p.className = "analysis-text";
  p.textContent = text;
  section.appendChild(p);
  return section;
}

function createRowSection(title) {
  const section = document.createElement("div");
  section.className = "analysis-section";
  const h = document.createElement("div");
  h.className = "analysis-section-title";
  h.textContent = title;
  section.appendChild(h);
  return section;
}

function createListSection(title, items) {
  const section = document.createElement("div");
  section.className = "analysis-section";
  const h = document.createElement("div");
  h.className = "analysis-section-title";
  h.textContent = title;
  section.appendChild(h);
  const ul = document.createElement("ul");
  ul.className = "analysis-list";
  for (const item of items) {
    const li = document.createElement("li");
    li.textContent = item;
    ul.appendChild(li);
  }
  section.appendChild(ul);
  return section;
}

function buildAnalysisRow(label, text, detail) {
  const row = document.createElement("div");
  row.className = "analysis-row";

  const labelEl = document.createElement("span");
  labelEl.className = "analysis-label";
  labelEl.textContent = label;
  row.appendChild(labelEl);

  if (text) {
    const body = document.createElement("span");
    body.className = "analysis-body";
    const textEl = document.createElement("span");
    textEl.className = "analysis-text";
    textEl.textContent = text;
    body.appendChild(textEl);
    if (detail) {
      body.append(" — " + detail);
    }
    row.appendChild(body);
  } else if (detail) {
    const body = document.createElement("span");
    body.className = "analysis-body";
    body.textContent = detail;
    row.appendChild(body);
  }

  return row;
}

function buildWordRow(word) {
  const row = document.createElement("div");
  row.className = "analysis-word-row";

  // Left column
  const left = document.createElement("div");
  left.className = "word-left";

  const title = document.createElement("div");
  title.className = "word-title";
  title.textContent = [word.text, word.partOfSpeech].filter(Boolean).join(" · ");
  left.appendChild(title);

  const actions = document.createElement("div");
  actions.className = "word-actions";
  actions.appendChild(buildSpeakGroup(word.text));
  if (word.level) {
    const badge = document.createElement("span");
    badge.className = "egc-word-level-badge";
    badge.textContent = word.level;
    actions.appendChild(badge);
  }
  left.appendChild(actions);
  row.appendChild(left);

  // Right column
  const right = document.createElement("div");
  right.className = "word-right";

  if (word.translation) {
    const trans = document.createElement("div");
    trans.className = "word-translation";
    trans.textContent = word.translation;
    right.appendChild(trans);
  }

  if (word.note) {
    if (typeof word.note === "object" && !Array.isArray(word.note)) {
      for (const key of ["collocation", "synonym", "etymology"]) {
        const val = word.note[key];
        if (val) {
          const line = document.createElement("div");
          line.className = "word-note-line";
          line.textContent = val;
          right.appendChild(line);
        }
      }
    } else if (typeof word.note === "string" && word.note) {
      const line = document.createElement("div");
      line.className = "word-note-line";
      line.textContent = word.note;
      right.appendChild(line);
    }
  }

  row.appendChild(right);
  return row;
}

// ── 发音 ──────────────────────────────────────

let speechActive = false;

function speak(text, button, lang) {
  stopSpeech();
  if (!text || typeof speechSynthesis === "undefined") return;
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = lang || "en-US";
  utterance.rate = 0.88;
  speechActive = true;
  utterance.onstart = function () { button?.classList.add("egc-speaking"); };
  utterance.onend = function () { speechActive = false; button?.classList.remove("egc-speaking"); };
  utterance.onerror = function () { speechActive = false; button?.classList.remove("egc-speaking"); };
  speechSynthesis.speak(utterance);
}

function stopSpeech() {
  if (typeof speechSynthesis === "undefined") return;
  speechSynthesis.cancel();
  speechActive = false;
  document.querySelectorAll(".egc-speaking").forEach(function (b) { b.classList.remove("egc-speaking"); });
}

function buildSpeakGroup(text) {
  const group = document.createElement("span");
  group.className = "egc-speak-group";

  const uk = document.createElement("button");
  uk.type = "button";
  uk.className = "egc-speak-button";
  uk.setAttribute("aria-label", "英式发音");
  uk.textContent = "UK";
  uk.addEventListener("click", function (event) {
    event.preventDefault();
    speak(text, uk, "en-GB");
  });

  const us = document.createElement("button");
  us.type = "button";
  us.className = "egc-speak-button";
  us.setAttribute("aria-label", "美式发音");
  us.textContent = "US";
  us.addEventListener("click", function (event) {
    event.preventDefault();
    speak(text, us, "en-US");
  });

  group.appendChild(uk);
  group.appendChild(us);
  return group;
}

// ── 工具 ──────────────────────────────────────

function formatTokenAmount(tokens) {
  if (tokens >= 1000000) {
    var m = (tokens / 1000000).toFixed(tokens % 1000000 === 0 ? 0 : 1);
    return m + "M";
  }
  if (tokens >= 1000) {
    return (tokens / 1000).toFixed(0) + "K";
  }
  return String(tokens);
}
