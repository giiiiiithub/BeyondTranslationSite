// provider.js — FC 后端 API 调用
// LLM 交互代码已迁移至 FC 后端，扩展只负责发起请求和渲染。

// FC 后端地址（LLM + License 合并为同一个 FC 函数）
export const FC_API_BASE = "https://beyond-nslation-umvdiweytv.cn-hangzhou.fcapp.run";
export const LLM_API_BASE = FC_API_BASE;

export const LICENSE_API_BASE = FC_API_BASE;

export const DEFAULT_SETTINGS = {
  pageAnnotationTrigger: "auto",
  pageAnnotationBatchSize: 5,
  pageAnnotationConcurrency: 6,
  pageAnnotationMode: "components",
  pageAnnotationPrepositionFocus: true,
  pageAnnotationSiteRules: [],
  pageAnnotationDeclinedSiteRules: []
};

export const PAGE_ANNOTATION_LIMITS = {
  batchSize: { min: 1, max: 20 },
  concurrency: { min: 1, max: 6 }
};

export function resolveSettings(stored = {}) {
  const merged = { ...DEFAULT_SETTINGS, ...stored };
  return {
    ...merged,
    pageAnnotationBatchSize: normalizeIntegerSetting(
      merged.pageAnnotationBatchSize,
      DEFAULT_SETTINGS.pageAnnotationBatchSize,
      PAGE_ANNOTATION_LIMITS.batchSize
    ),
    pageAnnotationConcurrency: normalizeIntegerSetting(
      merged.pageAnnotationConcurrency,
      DEFAULT_SETTINGS.pageAnnotationConcurrency,
      PAGE_ANNOTATION_LIMITS.concurrency
    ),
    pageAnnotationSiteRules: normalizePageAnnotationSiteRules(merged.pageAnnotationSiteRules),
    pageAnnotationDeclinedSiteRules: normalizePageAnnotationSiteRules(merged.pageAnnotationDeclinedSiteRules)
  };
}

export function normalizePageAnnotationSiteRules(value) {
  const items = Array.isArray(value) ? value : [];
  const seen = new Set();
  const rules = [];

  for (const item of items) {
    const source = item && typeof item === "object" ? item : {};
    const pattern = normalizeSiteRuleDomain(source.pattern || source.host || source.domain || source.value);
    if (!pattern) continue;

    if (seen.has(pattern)) continue;
    seen.add(pattern);
    rules.push({
      scope: "domain",
      pattern,
      addedAt: normalizeIsoDate(source.addedAt)
    });
  }

  return rules.slice(0, 200);
}

function normalizeSiteRuleDomain(value) {
  const text = String(value || "").trim();
  if (!text) return "";

  const withProtocol = /^[a-z][a-z0-9+.-]*:\/\//i.test(text) ? text : `https://${text}`;
  try {
    const url = new URL(withProtocol);
    return getRegistrableDomain(normalizeHostname(url.hostname));
  } catch {
    const host = text
      .replace(/^[a-z][a-z0-9+.-]*:\/\//i, "")
      .split(/[/?#]/, 1)[0]
      .replace(/:\d+$/, "");
    return getRegistrableDomain(normalizeHostname(host));
  }
}

function normalizeHostname(value) {
  const host = String(value || "")
    .trim()
    .toLowerCase()
    .replace(/^\.+|\.+$/g, "");
  if (!host || /\s/.test(host)) return "";
  if (host === "localhost") return host;
  if (/^\d{1,3}(?:\.\d{1,3}){3}$/.test(host)) return host;
  if (!/^[a-z0-9.-]+$/.test(host)) return "";
  if (host.includes("..")) return "";
  const labels = host.split(".");
  if (labels.some((label) => !label || label.startsWith("-") || label.endsWith("-"))) return "";
  return host;
}

function getRegistrableDomain(host) {
  const normalizedHost = normalizeHostname(host);
  if (!normalizedHost || isIpAddress(normalizedHost) || !normalizedHost.includes(".")) {
    return normalizedHost;
  }

  const labels = normalizedHost.split(".").filter(Boolean);
  if (labels.length <= 2) return normalizedHost;

  const suffixLength = getPublicSuffixLabelCount(labels);
  return labels.slice(-Math.min(labels.length, suffixLength + 1)).join(".");
}

function getPublicSuffixLabelCount(labels) {
  const last = labels[labels.length - 1] || "";
  const secondLast = labels[labels.length - 2] || "";
  if (last.length === 2 && secondLast.length <= 3) {
    return 2;
  }
  return 1;
}

function isIpAddress(host) {
  return /^\d{1,3}(?:\.\d{1,3}){3}$/.test(host) || host.includes(":");
}

function normalizeIsoDate(value) {
  const text = String(value || "").trim();
  if (!text) return new Date().toISOString();
  const time = Date.parse(text);
  return Number.isFinite(time) ? new Date(time).toISOString() : new Date().toISOString();
}

function normalizeIntegerSetting(value, fallback, limits) {
  if (value === "" || value == null) return fallback;
  const number = Math.floor(Number(value));
  if (!Number.isFinite(number)) {
    return fallback;
  }
  return Math.min(limits.max, Math.max(limits.min, number));
}

// ── FC 后端 API 调用 ──────────────────────────

let _tokenInfoHandler = null;
let _quotaErrorHandler = null;

export function setTokenInfoHandler(handler) {
  _tokenInfoHandler = handler;
}

export function setQuotaErrorHandler(handler) {
  _quotaErrorHandler = handler;
}

export async function callLlmApi(path, body) {
  const url = `${LLM_API_BASE}${path}`;
  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });

  var json;
  try {
    json = await response.json();
  } catch (e) {
    throw new Error("LLM 服务请求失败 (HTTP " + response.status + ")");
  }

  // 统一检查业务 code
  if (json.code !== "000200") {
    if (_quotaErrorHandler && (json.code === "000001" || json.code === "000002")) {
      _quotaErrorHandler(json.code).catch(function () {});
    }
    var err = new Error(json.msg || "服务请求失败");
    err.code = json.code || "";
    throw err;
  }

  if (_tokenInfoHandler && json.data && json.data.token_info) {
    _tokenInfoHandler(json.data.token_info).catch(function () {});
  }
  return json.data;
}

// ── LLM 功能 API ──────────────────────────────
// deviceId 用于免费用户的每日额度追踪。

export async function analyzeText(text, activationCode, deviceId) {
  const body = { text };
  if (activationCode) body.activation_code = activationCode;
  if (deviceId) body.client_id = deviceId;
  return callLlmApi("/api/llm/analyze", body);
}

export async function followUp(params, activationCode, deviceId) {
  const body = {
    selectedText: params.selectedText,
    analysis: params.analysis || "",
    history: params.history || [],
    question: params.question
  };
  if (activationCode) body.activation_code = activationCode;
  if (deviceId) body.client_id = deviceId;
  return callLlmApi("/api/llm/follow-up", body);
}

export async function annotateSentence(sentence, activationCode, deviceId) {
  const body = { sentence };
  if (activationCode) body.activation_code = activationCode;
  if (deviceId) body.client_id = deviceId;
  return callLlmApi("/api/llm/annotate-sentence", body);
}

export async function annotateSentences(sentences, activationCode, deviceId) {
  const body = { sentences };
  if (activationCode) body.activation_code = activationCode;
  if (deviceId) body.client_id = deviceId;
  const result = await callLlmApi("/api/llm/annotate-batch", body);
  return result.items;
}

export async function segmentSentence(sentence, activationCode, deviceId) {
  const body = { sentence };
  if (activationCode) body.activation_code = activationCode;
  if (deviceId) body.client_id = deviceId;
  return callLlmApi("/api/llm/segment-sentence", body);
}

export async function segmentSentences(sentences, activationCode, deviceId) {
  const body = { sentences };
  if (activationCode) body.activation_code = activationCode;
  if (deviceId) body.client_id = deviceId;
  const result = await callLlmApi("/api/llm/segment-batch", body);
  return result.items;
}

export async function testLlmConnection() {
  return callLlmApi("/api/llm/test", {});
}

export function redactSensitiveText(text, sensitiveValues = []) {
  let result = String(text || "");
  for (const value of sensitiveValues) {
    result = result.split(value).join("[REDACTED]");
  }
  return result
    .replace(/\b(Bearer|Basic)\s+[A-Za-z0-9._~+/=-]{8,}/gi, "$1 [REDACTED]")
    .replace(/\b(authorization|api[-_\s]*key|access[-_\s]*token|refresh[-_\s]*token|secret|password|cookie)\b\s*[:=]\s*["']?[^"',\s}]{8,}/gi, "$1: [REDACTED]");
}
