(function () {
  const SCRIPT_VERSION = "2026-05-23-tooltip-nested-guard-v41";
  if (window.__englishGrammarPageAnnotationVersion === SCRIPT_VERSION) return;
  window.__englishGrammarPageAnnotationVersion = SCRIPT_VERSION;

  const ROOT_CLASS = "egc-page-annotation";
  const SENTENCE_CLASS = "egc-sentence";
  const PART_CLASS = "egc-part";
  const PART_LABEL_CLASS = "egc-part-label";
  const TRANSLATION_CLASS = "egc-translation";
  const NESTED_PANEL_CLASS = "egc-nested-analysis";
  const TRANSLATION_TOOLTIP_CLASS = "egc-translation-tooltip";
  const MAX_SENTENCES_PER_SCAN = 180;
  const MIN_SENTENCE_LENGTH = 5;
  const MAX_SENTENCE_LENGTH = 800;
  const BLOCK_FALLBACK_SELECTOR = "h1,h2,h3,h4,h5,h6,p,li,blockquote,figcaption,td,th,summary,a";
  const TRIGGER_CLICK = "click";
  const TRIGGER_AUTO = "auto";
  const DEFAULT_AUTO_BATCH_SIZE = 5;
  const DEFAULT_AUTO_CONCURRENCY = 6;
  const DEFAULT_AUTO_LIMITS = {
    batchSize: { min: 1, max: 20 },
    concurrency: { min: 1, max: 6 }
  };
  const AUTO_ANALYSIS_INTERVAL_MS = 220;
  const AUTO_PREFETCH_VIEWPORTS = 8;
  const AUTO_BACKTRACK_VIEWPORTS = 0.25;
  const LABEL_COLLISION_GAP_PX = 6;
  const LABEL_LINE_STEP_EM = 1.35;
  const TOOLTIP_OFFSET_PX = 12;
  const TOOLTIP_VIEWPORT_MARGIN_PX = 28;

  let nestedSegmentIdCounter = 0;
  let enabled = false;
  let triggerMode = TRIGGER_AUTO;
  let scanning = false;
  let scanTimer = 0;
  let autoVisibilityResizeTimer = 0;
  let observer = null;
  let autoVisibilityObserver = null;
  let sentenceCount = 0;
  let autoActiveBatches = 0;
  let autoBatchSize = DEFAULT_AUTO_BATCH_SIZE;
  let segmentationMode = false;
  let autoConcurrency = DEFAULT_AUTO_CONCURRENCY;
  let labelLayoutFrame = 0;
  let enqueueTimer = 0;
  let progressiveSmallBatches = 2;
  let wordLevels = null;
  let translationIdCounter = 0;
  let translationAnchorIdCounter = 0;
  let translationTooltip = null;
  let translationTooltipSentence = null;
  let tooltipHideTimer = 0;
  let tooltipTheme = null;
  let speechActive = false;
  const autoQueue = [];
  const pendingLabelLayout = new Set();

  installStyles();
  addSafeEventListener(document, "click", handleNestedPartClick, true);
  addSafeEventListener(document, "keydown", handleNestedPartKeydown, true);
  addSafeEventListener(document, "click", handleSentenceClick, true);
  addSafeEventListener(document, "pointerover", handleTranslationTooltipPointerOver, true);
  addSafeEventListener(document, "pointerout", handleTranslationTooltipPointerOut, true);
  addSafeEventListener(document, "pointermove", handleTranslationTooltipPointerMove, true);
  addSafeEventListener(document, "wheel", handleTranslationTooltipWheel, { capture: true, passive: false });
  addSafeEventListener(window, "scroll", handleTranslationTooltipScroll, true);
  addSafeEventListener(window, "resize", handleViewportResize, { passive: true });
  globalThis.chrome?.runtime?.onMessage?.addListener?.(handleRuntimeMessage);
  init().catch(() => {});

  async function init() {
    warmUpSpeech();
    await loadTooltipTheme();
    const settings = await sendMessage("getSettingsSummary").catch(() => null);
    applySettings(settings || {});
  }

  function warmUpSpeech() {
    if (typeof speechSynthesis === "undefined") return;
    const utterance = new SpeechSynthesisUtterance("");
    utterance.volume = 0;
    utterance.rate = 2;
    speechSynthesis.speak(utterance);
  }

  function handleRuntimeMessage(message) {
    if (message?.type !== "pageAnnotationSettingsChanged") return;
    init().catch(() => {});
  }

  function applySettings(settings) {
    triggerMode = normalizeTriggerMode(settings.pageAnnotationTrigger);
    autoBatchSize = DEFAULT_AUTO_BATCH_SIZE;
    autoConcurrency = DEFAULT_AUTO_CONCURRENCY;
    segmentationMode = settings.pageAnnotationMode === "segments";
    wordLevels = Array.isArray(settings.pageAnnotationWordLevels) ? settings.pageAnnotationWordLevels : null;
    setEnabled(settings.pageAnnotationEnabledForSite === true);
    if (enabled && triggerMode === TRIGGER_AUTO) {
      startAutoVisibilityObserver();
      queueExistingSentences();
      processAutoQueue();
    } else {
      stopAutoVisibilityObserver();
      clearAutoQueue();
    }
  }

  function setEnabled(value) {
    const next = Boolean(value);
    if (enabled === next) return;
    enabled = next;
    document.documentElement.classList.toggle(ROOT_CLASS, enabled);

    if (enabled) {
      scheduleScan(50);
      startObserver();
    } else {
      hideTranslationTooltip();
      stopObserver();
      stopAutoVisibilityObserver();
      clearAutoQueue();
      unwrapAnnotations();
    }
  }

  function startObserver() {
    if (observer || !document.body) return;
    observer = new MutationObserver(() => scheduleScan(600));
    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }

  function stopObserver() {
    if (!observer) return;
    observer.disconnect();
    observer = null;
  }

  function startAutoVisibilityObserver() {
    if (autoVisibilityObserver || typeof IntersectionObserver !== "function") return;
    autoVisibilityObserver = new IntersectionObserver(handleAutoVisibilityChange, {
      root: null,
      rootMargin: buildAutoVisibilityRootMargin(),
      threshold: 0
    });
  }

  function stopAutoVisibilityObserver() {
    clearTimeout(autoVisibilityResizeTimer);
    autoVisibilityResizeTimer = 0;
    if (!autoVisibilityObserver) return;
    autoVisibilityObserver.disconnect();
    autoVisibilityObserver = null;
    for (const sentenceNode of document.querySelectorAll(`.${SENTENCE_CLASS}[data-egc-auto-observed='true']`)) {
      sentenceNode.dataset.egcAutoObserved = "false";
    }
  }

  function handleAutoVisibilityChange(entries) {
    for (const entry of entries) {
      if (!entry.isIntersecting && entry.intersectionRatio <= 0) continue;
      const sentenceNode = entry.target;
      autoVisibilityObserver?.unobserve(sentenceNode);
      sentenceNode.dataset.egcAutoObserved = "false";
      enqueueAutoAnnotation(sentenceNode);
    }
  }

  function handleViewportResize() {
    hideTranslationTooltip();
    scheduleAnnotatedLabelLayout();
    clearTimeout(autoVisibilityResizeTimer);
    autoVisibilityResizeTimer = setTimeout(() => {
      scheduleAnnotatedLabelLayout();
      if (!enabled || triggerMode !== TRIGGER_AUTO) return;
      stopAutoVisibilityObserver();
      startAutoVisibilityObserver();
      queueExistingSentences();
    }, 250);
  }

  function buildAutoVisibilityRootMargin() {
    const margins = getAutoViewportMargins();
    return `${margins.top}px 0px ${margins.bottom}px 0px`;
  }

  function getAutoViewportMargins() {
    const viewportHeight = window.innerHeight || document.documentElement.clientHeight || 0;
    return {
      top: Math.round(viewportHeight * AUTO_BACKTRACK_VIEWPORTS),
      bottom: Math.round(viewportHeight * AUTO_PREFETCH_VIEWPORTS)
    };
  }

  function scheduleScan(delayMs) {
    if (!enabled) return;
    clearTimeout(scanTimer);
    scanTimer = setTimeout(() => {
      scanPage();
    }, delayMs);
  }

  function scanPage() {
    if (!enabled || scanning || !document.body) return;
    scanning = true;
    sentenceCount = 0;  // 每轮扫描重置，避免动态加载内容无法被处理

    try {
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
        acceptNode: (node) => {
          if (sentenceCount >= MAX_SENTENCES_PER_SCAN) return NodeFilter.FILTER_REJECT;
          if (!isProcessableText(node.nodeValue || "")) return NodeFilter.FILTER_REJECT;
          if (!isProcessableParent(node.parentElement)) return NodeFilter.FILTER_REJECT;
          return NodeFilter.FILTER_ACCEPT;
        }
      });

      const nodes = [];
      while (walker.nextNode() && sentenceCount < MAX_SENTENCES_PER_SCAN) {
        nodes.push(walker.currentNode);
      }

      for (const node of nodes) {
        annotateTextNode(node);
      }

      annotateSentenceLikeElements();
    } finally {
      scanning = false;
    }
  }

  function annotateTextNode(node) {
    if (!node.parentNode || !isProcessableParent(node.parentElement)) return;

    const suffix = collectSentenceSuffix(node);

    // Collect text from preceding inline elements (@mentions, #hashtags).
    // The elements and their text ranges are recorded so that
    // renderSentenceAnnotation can preserve them instead of duplicating.
    const prefixInfo = collectInlinePrefix(node);
    const prefixText = prefixInfo.text;

    const fullText = `${prefixText}${node.nodeValue || ""}${suffix.text}`;
    const pieces = splitIntoSentencePieces(fullText);
    if (!pieces.some((piece) => piece.isSentence)) return;

    const fragment = document.createDocumentFragment();
    const createdSentences = [];
    let prefixUsed = false;
    for (const piece of pieces) {
      if (!piece.text) continue;
      if (!piece.isSentence || sentenceCount >= MAX_SENTENCES_PER_SCAN) {
        fragment.appendChild(document.createTextNode(piece.text));
        continue;
      }

      const span = document.createElement("span");
      span.className = SENTENCE_CLASS;
      span.dataset.egcOriginal = piece.text;
      span.dataset.egcWrapper = "true";

      if (prefixInfo.elements.length && !prefixUsed) {
        span.dataset.egcProtectedRanges = JSON.stringify(
          prefixInfo.ranges.map(r => [r.start, r.end])
        );
        for (const el of prefixInfo.elements) {
          if (el.parentNode) el.remove();
          span.appendChild(el);
        }
        span.appendChild(document.createTextNode(piece.text.slice(prefixText.length)));
        prefixUsed = true;
      } else {
        span.textContent = piece.text;
      }

      fragment.appendChild(span);
      createdSentences.push(span);
      sentenceCount += 1;
    }

    node.replaceWith(fragment);
    for (const item of suffix.nodes) {
      if (item.isConnected) item.remove();
    }
    for (const sentenceNode of createdSentences) {
      queueAutoAnnotation(sentenceNode);
    }
  }

  function extractInlinePrefixFromNode(node) {
    if (node.nodeType === Node.TEXT_NODE) {
      const value = (node.nodeValue || "").trim();
      if (!value || value.length > 15) return null;
      if (!isSentenceSuffixText(value)) return { element: node, elText: value };
      return null;
    }
    if (node.nodeType !== Node.ELEMENT_NODE) return null;

    const el = node;
    if (el.matches?.("img,video,audio,canvas,iframe,svg,script,style,input,textarea,select,button")) return null;
    if (el.closest?.(`.${SENTENCE_CLASS}, .${TRANSLATION_CLASS}, .${PART_CLASS}`)) return null;

    const style = window.getComputedStyle(el);
    if (style.display === "none" || style.visibility === "hidden") return null;

    // Reject if the element itself or its children contain interactive UI controls
    // (buttons, inputs, etc.) — these are page chrome, not sentence prefixes.
    if (el.matches?.("button, [role='button'], input, select, textarea") ||
        el.querySelector?.("button, input, select, textarea, [role='button'], [contenteditable]")) return null;

    // Strategy: find the best inline content to collect

    // 1. If this IS an <a>, use its text directly
    if (el.tagName === "A") {
      const text = (el.textContent || "").trim();
      if (text && text.length <= 30) return { element: el, elText: text };
      return null;
    }

    // 2. If element contains an <a>, use that instead of the wrapper
    const anchor = el.querySelector("a");
    if (anchor) {
      const text = (anchor.textContent || "").trim();
      if (text && text.length <= 30) return { element: anchor, elText: text };
      return null; // <a> too long — don't collect the wrapper either
    }

    // 3. For inline/span elements with short text, use directly
    if (style.display.startsWith("inline") || el.tagName === "SPAN") {
      const text = (el.textContent || "").trim();
      if (text && text.length <= 30) return { element: el, elText: text };
      return null;
    }

    // 4. For flex/grid containers, try first child
    if (style.display === "flex" || style.display === "grid") {
      if (el.children.length > 0) return extractInlinePrefixFromNode(el.children[0]);
      const text = (el.textContent || "").trim();
      if (text && text.length <= 30) return { element: el, elText: text };
      return null;
    }

    // 5. Fallback: any element whose text looks like a mention/hashtag/short label
    const text = (el.textContent || "").trim();
    if (text && text.length <= 20 && /^[@#\w][\w'-]*$/.test(text)) {
      return { element: el, elText: text };
    }

    return null;
  }

  function isContentBoundary(el) {
    if (el.nodeType !== Node.ELEMENT_NODE) return false;
    if (el.closest?.(`.${SENTENCE_CLASS}, .${TRANSLATION_CLASS}, .${PART_CLASS}`)) return true;
    // Contains interactive/non-text elements: structural boundary
    if (el.querySelector("img, video, audio, canvas, iframe, button, input, select, textarea, [role='button'], [contenteditable]")) return true;
    const elStyle = window.getComputedStyle(el);
    const disp = elStyle.display;
    // Inline elements are always part of the text flow
    if (disp === "inline" || disp.startsWith("inline-")) return false;
    // Block-level element with short text might be a prefix container
    const text = (el.textContent || "").trim();
    if (text.length <= 30) return false;
    // Contains block-level children with substantial text: composite section
    for (const child of el.children) {
      const childStyle = window.getComputedStyle(child);
      if (childStyle.display === "block" || childStyle.display === "flex" || childStyle.display === "grid") {
        if ((child.textContent || "").trim().length > 15) return true;
      }
    }
    return false;
  }

  function collectInlinePrefix(node) {
    let text = "";
    const collected = [];
    let maxDepth = 6;

    // Walk up the ancestor chain. At each level, check the previous sibling
    // for inline content. Also walk left from each found sibling to catch
    // multiple inline elements (e.g. @user1 @user2 before text).
    // Stop when we encounter a content boundary (a block-level element from
    // a different section of the page) to avoid collecting unrelated UI text.
    let current = node;
    while (current && current !== document.body && text.length < 40 && maxDepth > 0) {
      const prev = current.previousSibling;
      if (prev) {
        // Content boundary check: if the first sibling at this level is a
        // block element from a different content section, stop entirely.
        if (isContentBoundary(prev)) break;

        // Walk left to collect all inline content at this level
        let walk = prev;
        while (walk && text.length < 40) {
          const info = extractInlinePrefixFromNode(walk);
          if (info) {
            collected.unshift(info);
            text = collected.map(c => c.elText).join("");
          }
          walk = walk.previousSibling;
        }
      }
      current = current.parentNode;
      maxDepth--;
    }

    const ranges = [];
    const elements = [];
    let cursor = 0;
    for (const item of collected) {
      ranges.push({ start: cursor, end: cursor + item.elText.length, element: item.element });
      elements.push(item.element);
      cursor += item.elText.length;
    }

    return { text, ranges, elements };
  }

  function collectSentenceSuffix(node) {
    const nodes = [];
    let text = "";
    let current = getNextSuffixCandidate(node);

    while (current && text.length < 16) {
      const value = getSuffixText(current);
      if (value == null) break;
      nodes.push(current);
      text += value;
      current = getNextSuffixCandidate(current);
      if (hasMeaningfulInlineSuffix(text)) break;
    }

    if (!hasMeaningfulInlineSuffix(text)) {
      return { text: "", nodes: [] };
    }

    return { text, nodes };
  }

  function getNextSuffixCandidate(node) {
    let current = node;
    while (current && current !== document.body) {
      if (current.nextSibling) return current.nextSibling;
      current = current.parentNode;
    }
    return null;
  }

  function getSuffixText(node) {
    if (!node) return null;
    if (node.nodeType === Node.TEXT_NODE) {
      const value = node.nodeValue || "";
      if (!value) return null;
      return isSentenceSuffixText(value) ? value : null;
    }
    if (node.nodeType !== Node.ELEMENT_NODE) return null;

    const element = node;
    if (!isProcessableParent(element.parentElement)) return null;
    if (element.closest?.(`.${SENTENCE_CLASS}, .${TRANSLATION_CLASS}, .${PART_CLASS}, .${NESTED_PANEL_CLASS}, .${TRANSLATION_TOOLTIP_CLASS}`)) return null;
    if (!isSentenceSuffixElement(element)) return null;

    const value = getElementReadableText(element);
    return isSentenceSuffixText(value) ? value : null;
  }

  function isSentenceSuffixElement(element) {
    const style = window.getComputedStyle(element);
    if (!style || style.display === "none" || style.visibility === "hidden") return false;
    if (element.matches?.("script,style,textarea,input,select,button,video,canvas,iframe")) return false;
    if (element.querySelector?.(`.${SENTENCE_CLASS}, .${TRANSLATION_CLASS}, .${PART_CLASS}, .${NESTED_PANEL_CLASS}, .${TRANSLATION_TOOLTIP_CLASS}`)) return false;

    const value = getElementReadableText(element);
    if (!isSentenceSuffixText(value)) return false;

    const rect = element.getBoundingClientRect();
    if (rect.height > 120) return false;
    return true;
  }

  function getElementReadableText(element) {
    if (element.matches?.("img,svg")) {
      return element.getAttribute("alt")
        || element.getAttribute("aria-label")
        || element.getAttribute("title")
        || "";
    }
    return element.textContent
      || element.getAttribute("aria-label")
      || element.getAttribute("title")
      || "";
  }

  function isSentenceSuffixText(text) {
    const value = String(text || "");
    if (!value || value.length > 16) return false;
    if (/[A-Za-z0-9\u4e00-\u9fff]/.test(value)) return false;
    return /^[\s\p{P}\p{S}]+$/u.test(value);
  }

  function hasMeaningfulInlineSuffix(text) {
    return /[\p{P}\p{S}]/u.test(String(text || ""));
  }

  function annotateSentenceLikeElements() {
    if (sentenceCount >= MAX_SENTENCES_PER_SCAN) return;

    for (const element of document.querySelectorAll(BLOCK_FALLBACK_SELECTOR)) {
      if (sentenceCount >= MAX_SENTENCES_PER_SCAN) break;
      if (!isElementFallbackCandidate(element)) continue;

      const sentence = normalizeSpaces(element.innerText || element.textContent || "");
      element.classList.add(SENTENCE_CLASS);
      element.dataset.egcOriginal = sentence;
      element.dataset.egcElement = "true";
      sentenceCount += 1;
      queueAutoAnnotation(element);
    }
  }

  function isElementFallbackCandidate(element) {
    if (!element || !isProcessableParent(element)) return false;
    if (element.classList.contains(SENTENCE_CLASS)) return false;
    if (element.querySelector(`.${SENTENCE_CLASS}, .${PART_CLASS}, .${TRANSLATION_CLASS}`)) return false;
    if (element.querySelector("p,li,blockquote,table,ul,ol,pre,code,input,textarea,select,button")) return false;
    if (!isSafeElementAnnotationTarget(element)) return false;

    const text = normalizeSpaces(element.innerText || element.textContent || "");
    if (!isCandidateSentence(text)) return false;
    if (countLikelySentences(text) > 1) return false;
    return true;
  }

  function isSafeElementAnnotationTarget(element) {
    if (!element || element.childElementCount > 0) return false;

    for (const node of element.childNodes) {
      if (node.nodeType !== Node.TEXT_NODE && node.nodeType !== Node.COMMENT_NODE) {
        return false;
      }
    }

    const visibleText = normalizeSpaces(element.innerText || "");
    const domText = normalizeSpaces(element.textContent || "");
    return Boolean(visibleText) && visibleText === domText;
  }

  function splitIntoSentencePieces(text) {
    const pieces = [];
    const segmenter = createSentenceSegmenter();

    if (segmenter) {
      let cursor = 0;
      for (const item of segmenter.segment(text)) {
        if (item.index > cursor) {
          pieces.push({ text: text.slice(cursor, item.index), isSentence: false });
        }
        pieces.push({
          text: item.segment,
          isSentence: isCandidateSentence(item.segment)
        });
        cursor = item.index + item.segment.length;
      }
      if (cursor < text.length) {
        pieces.push({ text: text.slice(cursor), isSentence: false });
      }
      return pieces;
    }

    const pattern = /[^.!?。！？]+[.!?]+(?:["')\]]+)?\s*|[^.!?。！？]+$/g;
    let cursor = 0;
    let match;
    while ((match = pattern.exec(text))) {
      if (match.index > cursor) {
        pieces.push({ text: text.slice(cursor, match.index), isSentence: false });
      }
      pieces.push({
        text: match[0],
        isSentence: isCandidateSentence(match[0])
      });
      cursor = match.index + match[0].length;
    }
    if (cursor < text.length) {
      pieces.push({ text: text.slice(cursor), isSentence: false });
    }
    return pieces;
  }

  function createSentenceSegmenter() {
    try {
      if (typeof Intl?.Segmenter !== "function") return null;
      return new Intl.Segmenter("en", { granularity: "sentence" });
    } catch {
      return null;
    }
  }

  function isProcessableText(text) {
    return /[A-Za-z]/.test(text);
  }

  function isCandidateSentence(text) {
    const normalized = normalizeSpaces(text);
    if (normalized.length < MIN_SENTENCE_LENGTH) return false;
    return countEnglishWords(normalized) >= 4;
  }

  function hasTerminalSentencePunctuation(text) {
    return /[.!?]$/.test(normalizeSpaces(text).replace(/["')\]]+$/g, ""));
  }

  function countEnglishWords(text) {
    return (String(text || "").match(/[@#]?[A-Za-z][A-Za-z'-]*/g) || []).length;
  }

  function englishLetterRatio(text) {
    const value = String(text || "");
    const letters = (value.match(/[A-Za-z]/g) || []).length;
    const visible = value.replace(/\s+/g, "").length || 1;
    return letters / visible;
  }

  function countLikelySentences(text) {
    const matches = normalizeSpaces(text).match(/[.!?]+(?:["')\]]+)?(?=\s+[A-Z0-9"]|$)/g);
    return matches ? matches.length : 0;
  }

  function isProcessableParent(element) {
    if (!element) return false;
    if (element.closest(`.${SENTENCE_CLASS}, .${TRANSLATION_CLASS}, .${PART_CLASS}, .${NESTED_PANEL_CLASS}, .${TRANSLATION_TOOLTIP_CLASS}`)) return false;
    if (
      element.closest(
        "script, style, noscript, template, svg, canvas, math, pre, code, kbd, samp, textarea, input, select, option, button, [contenteditable]:not([contenteditable='false']), [role='button'], [aria-hidden='true']"
      )
    ) {
      return false;
    }

    const style = window.getComputedStyle(element);
    if (style.display === "none" || style.visibility === "hidden") return false;
    return true;
  }

  function isNearViewport(element) {
    if (!element?.isConnected) return false;
    const rect = element.getBoundingClientRect();
    const hasBox = rect.width > 0 || rect.height > 0 || element.getClientRects().length > 0;
    if (!hasBox) return false;

    const margins = getAutoViewportMargins();
    const viewportWidth = window.innerWidth || document.documentElement.clientWidth || 0;
    const viewportHeight = window.innerHeight || document.documentElement.clientHeight || 0;
    return rect.bottom >= -margins.top
      && rect.top <= viewportHeight + margins.bottom
      && rect.right >= 0
      && rect.left <= viewportWidth;
  }

  function handleNestedPartClick(event) {
    if (!enabled) return;
    const part = findClickedNestedPart(event);
    if (!part?.isConnected) return;
    if (!part.__egcNestedSegment?.children?.length) return;
    if (window.getSelection()?.toString().trim()) return;

    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation?.();
    toggleNestedAnalysis(part);
  }

  function findClickedNestedPart(event) {
    const target = event.target;
    if (!target?.closest) return null;
    const label = target.closest(`.${PART_LABEL_CLASS}`);
    if (label) {
      return label.parentElement?.closest?.(`.${PART_CLASS}.egc-has-nested`) || null;
    }
    return target.closest(`.${PART_CLASS}.egc-has-nested`);
  }

  function handleNestedPartKeydown(event) {
    if (event.key !== "Enter" && event.key !== " ") return;
    handleNestedPartClick(event);
  }

  async function handleSentenceClick(event) {
    if (!enabled) return;
    const sentenceNode = event.target?.closest?.(`.${SENTENCE_CLASS}`);
    if (!sentenceNode) return;
    if (!sentenceNode.isConnected) return;
    if (window.getSelection()?.toString().trim()) return;

    event.preventDefault();
    event.stopPropagation();

    if (sentenceNode.dataset.egcLoading === "true") return;
    if (sentenceNode.dataset.egcAnnotated === "true") {
      const collapsed = sentenceNode.classList.toggle("egc-collapsed");
      setSentenceTranslationCollapsed(sentenceNode, collapsed);
      return;
    }

    await annotateSentence(sentenceNode);
  }

  function handleTranslationTooltipPointerOver(event) {
    if (!enabled) return;
    const sentenceNode = event.target?.closest?.(`.${SENTENCE_CLASS}.egc-annotated`);
    if (!sentenceNode?.isConnected) return;

    // Only suppress tooltip over the "· 展开" expand label so it remains
    // clickable without tooltip overlay. Regular component labels (主语, 谓语, …)
    // should not hide a visible tooltip while the cursor transits to it.
    const labelEl = event.target?.closest?.(`.${PART_LABEL_CLASS}`);
    if (labelEl && labelEl.parentElement?.classList?.contains("egc-has-nested")) {
      hideTranslationTooltip();
      return;
    }

    // Avoid redundant re-render when moving between children of the same sentence
    // when the tooltip is already visible for it.
    if (sentenceNode === translationTooltipSentence && translationTooltip?.classList.contains("egc-visible")) return;

    clearTooltipHideTimer();
    showTranslationTooltip(sentenceNode, event);
  }

  function handleTranslationTooltipPointerOut(event) {
    const sentenceNode = event.target?.closest?.(`.${SENTENCE_CLASS}.egc-annotated`);
    if (!sentenceNode || sentenceNode !== translationTooltipSentence) return;
    if (sentenceNode.contains(event.relatedTarget)) return;
    if (translationTooltip?.contains(event.relatedTarget)) return;
    scheduleTooltipHide();
  }

  function handleTranslationTooltipPointerMove(event) {
    if (!translationTooltip?.classList.contains("egc-visible")) return;
    const target = event.target;
    const overTooltip = target && translationTooltip.contains(target);
    const overSentence = target && translationTooltipSentence?.isConnected && translationTooltipSentence.contains(target);
    if (overTooltip || overSentence) {
      clearTooltipHideTimer();
    } else {
      // Short buffer while cursor is outside both sentence and tooltip.
      // Just enough for a 12px gap traversal to the tooltip, but
      // expires quickly once cursor stops or moves away.
      scheduleTooltipHide(80);
    }
  }

  function scheduleTooltipHide(delay = 280) {
    clearTooltipHideTimer();
    tooltipHideTimer = setTimeout(() => {
      hideTranslationTooltip();
    }, delay);
  }

  function clearTooltipHideTimer() {
    clearTimeout(tooltipHideTimer);
    tooltipHideTimer = 0;
  }

  function handleTranslationTooltipWheel(event) {
    if (!translationTooltip?.classList.contains("egc-visible")) return;
    if (!translationTooltipSentence?.isConnected) return;

    const overTooltip = event.target === translationTooltip || translationTooltip.contains(event.target);
    const overSentence = translationTooltipSentence.contains(event.target);
    if (!overTooltip && !overSentence) return;
    if (!isScrollableTooltip()) return;

    event.preventDefault();
    event.stopPropagation();
    translationTooltip.scrollTop += event.deltaY;
    translationTooltip.scrollLeft += event.deltaX;
  }

  function handleTranslationTooltipScroll(event) {
    if (translationTooltip && (event.target === translationTooltip || translationTooltip.contains(event.target))) {
      return;
    }
    hideTranslationTooltip();
  }

  function queueExistingSentences() {
    startAutoVisibilityObserver();
    for (const sentenceNode of document.querySelectorAll(`.${SENTENCE_CLASS}`)) {
      queueAutoAnnotation(sentenceNode);
    }
  }

  function queueAutoAnnotation(sentenceNode) {
    if (!enabled || triggerMode !== TRIGGER_AUTO) return;
    if (!sentenceNode?.isConnected) return;
    if (sentenceNode.dataset.egcAnnotated === "true") return;
    if (sentenceNode.dataset.egcLoading === "true") return;

    if (isNearViewport(sentenceNode)) {
      enqueueAutoAnnotation(sentenceNode);
      return;
    }

    observeAutoCandidate(sentenceNode);
  }

  function observeAutoCandidate(sentenceNode) {
    if (sentenceNode.dataset.egcAutoObserved === "true") return;
    if (!autoVisibilityObserver) {
      enqueueAutoAnnotation(sentenceNode);
      return;
    }

    sentenceNode.dataset.egcAutoObserved = "true";
    autoVisibilityObserver.observe(sentenceNode);
  }

  function enqueueAutoAnnotation(sentenceNode) {
    if (!enabled || triggerMode !== TRIGGER_AUTO) return;
    if (!sentenceNode?.isConnected) return;
    if (sentenceNode.dataset.egcAnnotated === "true") return;
    if (sentenceNode.dataset.egcLoading === "true") return;
    if (sentenceNode.dataset.egcAutoQueued === "true") return;

    sentenceNode.dataset.egcAutoQueued = "true";
    if (autoQueue.length === 0 && autoActiveBatches === 0) {
      progressiveSmallBatches = 2;
    }
    autoQueue.push(sentenceNode);
    clearTimeout(enqueueTimer);
    enqueueTimer = setTimeout(() => {
      processAutoQueue();
    }, 50);
  }

  function processAutoQueue() {
    if (!enabled || triggerMode !== TRIGGER_AUTO) return;
    if (!autoQueue.length) return;

    const started = [];
    while (autoActiveBatches < autoConcurrency && autoQueue.length) {
      const isSmall = progressiveSmallBatches > 0;
      const batch = takeAutoBatch(isSmall ? Math.min(2, autoBatchSize) : autoBatchSize);
      if (!batch.length) break;

      if (isSmall) progressiveSmallBatches -= 1;
      autoActiveBatches += 1;
      started.push(batch.length);
      annotateSentenceBatch(batch)
        .catch(() => {})
        .finally(() => {
          autoActiveBatches = Math.max(0, autoActiveBatches - 1);
          if (enabled && triggerMode === TRIGGER_AUTO && autoQueue.length) {
            processAutoQueue();
          }
        });
    }
  }

  function takeAutoBatch(maxSize) {
    const batch = [];
    const limit = maxSize || autoBatchSize;

    while (autoQueue.length && batch.length < limit) {
      const sentenceNode = autoQueue.shift();
      if (!sentenceNode?.isConnected) continue;

      sentenceNode.dataset.egcAutoQueued = "false";
      if (sentenceNode.dataset.egcAnnotated === "true" || sentenceNode.dataset.egcLoading === "true") continue;
      if (!isNearViewport(sentenceNode)) {
        observeAutoCandidate(sentenceNode);
        continue;
      }

      batch.push(sentenceNode);
    }

    if (batch.length) {
    }
    return batch;
  }

  function clearAutoQueue() {
    clearTimeout(enqueueTimer);
    for (const sentenceNode of autoQueue) {
      if (sentenceNode?.dataset) {
        sentenceNode.dataset.egcAutoQueued = "false";
      }
    }
    autoQueue.length = 0;
    progressiveSmallBatches = 2;
  }

  function scheduleProgressiveRender(sentenceNode, sentence, result, index) {
    setTimeout(() => {
      setSentenceLoading(sentenceNode, false);
      if (!sentenceNode.isConnected) return;
      if (result) {
        if (segmentationMode) {
          renderSegmentation(sentenceNode, sentence, result);
        } else {
          renderSentenceAnnotation(sentenceNode, sentence, result);
        }
      } else {
        renderSentenceError(sentenceNode, new Error("批量分析没有返回该句结果。"));
      }
    }, index * 80);
  }

  async function annotateSentenceBatch(sentenceNodes) {
    for (const sentenceNode of sentenceNodes) {
      setSentenceLoading(sentenceNode, true);
    }

    try {
      const sentences = sentenceNodes.map((sentenceNode) => sentenceNode.dataset.egcOriginal || sentenceNode.textContent || "");
      const t0 = Date.now();
      const response = await sendMessage("annotateSentences", { sentences });
      const t1 = Date.now();
      const results = Array.isArray(response) ? response : [];

      for (const [index, sentenceNode] of sentenceNodes.entries()) {
        if (!sentenceNode.isConnected) continue;
        const sentence = sentences[index];
        const result = results[index];
        if (result) {
          scheduleProgressiveRender(sentenceNode, sentence, result, index);
        } else {
          scheduleProgressiveRender(sentenceNode, sentence, null, index);
        }
      }
      const t2 = Date.now();
    } catch (error) {
      if (error && (error.code === "000001" || error.code === "000002")) showQuotaBanner(error.message);
      for (const sentenceNode of sentenceNodes) {
        if (sentenceNode.isConnected) {
          setSentenceLoading(sentenceNode, false);
          renderSentenceError(sentenceNode, error);
        }
      }
    } finally {
      // 不做 setSentenceLoading(false)，由 scheduleProgressiveRender 在渲染时清除
    }
  }

  async function annotateSentence(sentenceNode) {
    const sentence = sentenceNode.dataset.egcOriginal || sentenceNode.textContent || "";
    autoVisibilityObserver?.unobserve(sentenceNode);
    sentenceNode.dataset.egcAutoObserved = "false";
    sentenceNode.dataset.egcAutoQueued = "false";
    setSentenceLoading(sentenceNode, true);

    try {
      const result = await sendMessage("annotateSentence", { sentence });
      if (segmentationMode) {
        renderSegmentation(sentenceNode, sentence, result);
      } else {
        renderSentenceAnnotation(sentenceNode, sentence, result);
      }
    } catch (error) {
      if (error && (error.code === "000001" || error.code === "000002")) showQuotaBanner(error.message);
      renderSentenceError(sentenceNode, error);
    } finally {
      setSentenceLoading(sentenceNode, false);
    }
  }

  function setSentenceLoading(sentenceNode, value) {
    sentenceNode.dataset.egcLoading = value ? "true" : "false";
    sentenceNode.classList.toggle("egc-loading", Boolean(value));
  }

  const SEGMENTATION_COLORS = [
    "#5ba0d8", "#d4709f", "#5aad5e", "#e08a30",
    "#a87ee6", "#30a8b8", "#b8856a", "#c97a7a"
  ];

  function renderSegmentation(sentenceNode, sentence, result) {
    removeSentenceTranslation(sentenceNode);
    sentenceNode.dataset.egcLearningCard = JSON.stringify(buildLearningCardData(sentence, result));
    if (sentenceNode.dataset.egcElement === "true" && sentenceNode.dataset.egcOriginalHtml == null) {
      sentenceNode.dataset.egcOriginalHtml = sentenceNode.innerHTML;
    }
    sentenceNode.textContent = "";
    sentenceNode.removeAttribute("title");
    sentenceNode.dataset.egcAnnotated = "true";
    sentenceNode.classList.add("egc-annotated");

    let segments = Array.isArray(result?.segments) ? result.segments : [];

    if (segments.length === 1) {
      const seg = segments[0];
      const text = normalizeSpaces(seg?.text || "");
      const children = Array.isArray(seg.children) ? seg.children.filter((c) => normalizeSpaces(c?.text || "")) : [];
      if (children.length >= 2 && textsCoverSameMaterial(text, sentence)) {
        segments = children;
      }
    }

    // Fallback: if only 1 segment covering the whole sentence with no usable children,
    // try clause-boundary splitting so the user gets at least some visual segmentation
    if (segments.length <= 1) {
      const singleCover = segments.length === 1 && textsCoverSameMaterial(
        normalizeSpaces(segments[0]?.text || ""), sentence
      );
      if (singleCover || segments.length === 0) {
        const clauseSegments = fallbackSegmentClauses(sentence);
        if (clauseSegments.length >= 2) {
          segments = clauseSegments;
        }
      }
    }

    if (!segments.length) {
      sentenceNode.textContent = sentence;
      return;
    }

    const fragment = document.createDocumentFragment();
    let cursor = 0;
    let colorIndex = 0;

    for (const segment of segments) {
      const text = String(segment?.text || "").trim();
      if (!text) continue;

      const index = findSegmentIndex(sentence, text, cursor);
      if (index < 0) continue;

      if (index > cursor) {
        fragment.appendChild(document.createTextNode(sentence.slice(cursor, index)));
      }

      if (isPunctuationOnlySegment(text)) {
        fragment.appendChild(document.createTextNode(sentence.slice(index, index + text.length)));
        cursor = index + text.length;
        continue;
      }

      const color = SEGMENTATION_COLORS[colorIndex % SEGMENTATION_COLORS.length];
      colorIndex++;
      const span = document.createElement("span");
      span.textContent = sentence.slice(index, index + text.length);
      span.style.cssText = `border-bottom:2px solid ${color};cursor:pointer`;
      if (segment.translation) {
        span.dataset.egcSegTranslation = segment.translation;
      }
      fragment.appendChild(span);
      cursor = index + text.length;
    }

    if (cursor < sentence.length) {
      fragment.appendChild(document.createTextNode(sentence.slice(cursor)));
    }

    sentenceNode.appendChild(fragment);

    const translation = document.createElement("span");
    translation.className = TRANSLATION_CLASS;
    translation.textContent = buildTranslationText(result);
    attachSentenceTranslation(sentenceNode, translation);
  }

  function fallbackSegmentClauses(sentence) {
    if (!sentence || sentence.length < 10) return [];
    // Split at commas followed by known clause-starter words, and at semicolons/colons/em-dashes
    const clauseStarterRe = /[,] (?=(?:the|a|an|i|you|he|she|it|we|they|this|that|these|those|there|here|if|when|while|because|although|since|unless|until|though|who|which|what|where|why|how|to|for|with|by|from|in|on|at|of|about|as|will|would|can|could|may|might|shall|should|must|has|have|had|do|does|did|is|are|was|were|been|not|no|nor|so|yet|or|but|and|then|than|after|before|during)(?:\W|$))/gi;
    const alwaysSplitRe = /[;:] |[—–] /g;
    const splitPoints = [];
    let match;
    while ((match = clauseStarterRe.exec(sentence)) !== null) {
      const breakEnd = match.index + match[0].length;
      if (breakEnd + 3 <= sentence.length) splitPoints.push(breakEnd);
    }
    while ((match = alwaysSplitRe.exec(sentence)) !== null) {
      const breakEnd = match.index + match[0].length;
      if (breakEnd + 3 <= sentence.length && !splitPoints.includes(breakEnd)) {
        splitPoints.push(breakEnd);
      }
    }
    if (!splitPoints.length) return [];
    splitPoints.sort((a, b) => a - b);
    const segments = [];
    let lastIndex = 0;
    for (const sp of splitPoints) {
      segments.push({ text: sentence.slice(lastIndex, sp).trim(), translation: "" });
      lastIndex = sp;
    }
    segments.push({ text: sentence.slice(lastIndex).trim(), translation: "" });
    return segments.length >= 2 ? segments : [];
  }

  function renderSentenceAnnotation(sentenceNode, sentence, result) {
    removeSentenceTranslation(sentenceNode);
    sentenceNode.dataset.egcLearningCard = JSON.stringify(buildLearningCardData(sentence, result));

    // Save protected inline children (e.g. <a> with @mentions) before clearing
    const protectedChildren = [];
    let protectedRanges = [];
    const raw = sentenceNode.dataset.egcProtectedRanges;
    if (raw) {
      try { protectedRanges = JSON.parse(raw); } catch (e) {}
      delete sentenceNode.dataset.egcProtectedRanges;
      // Use firstChild repeatedly to handle both text and element children.
      // After removing the first child, the next one shifts to firstChild.
      for (let i = 0; i < protectedRanges.length; i++) {
        const child = sentenceNode.firstChild;
        if (!child) break;
        if (child.nodeType === Node.ELEMENT_NODE) {
          if (child.classList.contains("egc-part") || child.classList.contains("egc-translation")) break;
        }
        protectedChildren.push({ element: child, range: protectedRanges[i] });
        child.remove();
      }
    }

    if (sentenceNode.dataset.egcElement === "true" && sentenceNode.dataset.egcOriginalHtml == null) {
      sentenceNode.dataset.egcOriginalHtml = sentenceNode.innerHTML;
    }
    sentenceNode.textContent = "";
    sentenceNode.removeAttribute("title");
    sentenceNode.dataset.egcAnnotated = "true";
    sentenceNode.classList.add("egc-annotated");
    const flattenedSegments = flattenOtherSegments(result?.segments || []);
    const fixedSubjectSegments = unwrapSubjectWithPredicate(flattenedSegments);
    const promotedSegments = promoteOutOfSpanChildren(fixedSubjectSegments, sentence);
    const segFragment = buildSegmentedSentence(sentence, promotedSegments, 0, true);

    // Re-insert protected elements and strip their text from the matching segment.
    for (const item of protectedChildren) {
      const [start, end] = item.range;
      const protectedText = sentence.slice(start, end);
      if (!protectedText) continue;

      // Find the segment whose text starts with the protected text
      let node = segFragment.firstChild;
      let target = null;
      while (node) {
        if (node.nodeType === Node.ELEMENT_NODE) {
          const cls = node.classList;
          if (cls.contains("egc-part") || cls.contains("egc-element-other")) {
            if (node.textContent.startsWith(protectedText)) {
              target = node;
              break;
            }
          }
        }
        node = node.nextSibling;
      }

      if (target) {
        // Strip protected text from target segment
        const tn = target.firstChild;
        if (tn?.nodeType === Node.TEXT_NODE) {
          tn.textContent = tn.textContent.slice(protectedText.length);
        }
        // Remove segment if now empty
        if (!target.textContent.trim()) {
          target.remove();
          target = null;
        }
      }

      // Insert element before the target segment (or at start of fragment)
      const ref = target || segFragment.firstChild;
      if (ref) {
        segFragment.insertBefore(item.element, ref);
      } else {
        segFragment.appendChild(item.element);
      }
    }

    sentenceNode.appendChild(segFragment);
    schedulePartLabelLayout(sentenceNode);

    const translation = document.createElement("span");
    translation.className = TRANSLATION_CLASS;
    translation.textContent = buildTranslationText(result);
    attachSentenceTranslation(sentenceNode, translation);
  }

  function buildSegmentedSentence(sentence, segments, depth = 0, allowFallback = true) {
    const fragment = document.createDocumentFragment();
    const inlineWrapper = getInlineWrapperSegment(sentence, segments);
    if (inlineWrapper) {
      return buildInlineWrapperSentence(sentence, inlineWrapper, depth);
    }

    let cursor = 0;
    let matchedCount = 0;

    for (const segment of segments) {
      const text = String(segment?.text || "").trim();
      if (!text) continue;

      const index = findSegmentIndex(sentence, text, cursor);
      if (index < 0) continue;

      if (index > cursor) {
        fragment.appendChild(document.createTextNode(sentence.slice(cursor, index)));
      }

      if (isPunctuationOnlySegment(text)) {
        fragment.appendChild(document.createTextNode(sentence.slice(index, index + text.length)));
        cursor = index + text.length;
        matchedCount += 1;
        continue;
      }

      const part = document.createElement("span");
      const role = normalizeElement(segment.syntacticComponent);
      const children = Array.isArray(segment.children) ? segment.children : [];
      part.className = `${PART_CLASS} egc-element-${role}${depth > 0 ? " egc-nested-part" : ""}${children.length ? " egc-has-nested" : ""}`;
      const label = normalizeLabel(String(segment.label || ""), elementLabel(role));
      part.dataset.roleLabel = label;
      part.dataset.translation = String(segment.translation || "");
      part.dataset.egcDetail = [part.dataset.roleLabel, segment.translation, segment.reason].filter(Boolean).join("：");
      const originalText = sentence.slice(index, index + text.length);
      if (children.length) {
        part.classList.add("egc-nested-collapsed");
        part.dataset.egcNestedKey = `nested-${++nestedSegmentIdCounter}`;
        part.setAttribute("role", "button");
        part.setAttribute("tabindex", "0");
        part.setAttribute("aria-expanded", "false");
        part.title = "点击单独查看内部成分分析";
        part.__egcNestedSegment = {
          text: originalText,
          role,
          label,
          translation: String(segment.translation || ""),
          note: String(segment.reason || ""),
          children
        };
        part.appendChild(document.createTextNode(originalText));
      } else {
        part.appendChild(document.createTextNode(originalText));
      }
      if (label) part.appendChild(buildPartLabel(label));
      fragment.appendChild(part);
      cursor = index + text.length;
      matchedCount += 1;
    }

    if (!matchedCount && allowFallback) {
      const part = document.createElement("span");
      part.className = `${PART_CLASS} egc-element-other`;
      part.textContent = sentence;
      fragment.appendChild(part);
      return fragment;
    }

    if (!matchedCount) {
      fragment.appendChild(document.createTextNode(sentence));
      return fragment;
    }

    if (cursor < sentence.length) {
      fragment.appendChild(document.createTextNode(sentence.slice(cursor)));
    }

    return fragment;
  }

  function flattenOtherSegments(segments) {
    if (!Array.isArray(segments)) return segments;
    const result = [];
    for (const seg of segments) {
      const role = normalizeElement(seg?.syntacticComponent);
      const children = Array.isArray(seg.children) ? seg.children : [];

      if (isPunctuationOnlySegment(seg?.text)) continue;

      // Unknown or empty role → promote children if any, otherwise skip
      if (role === "unknown") {
        if (children.length > 0) {
          result.push(...flattenOtherSegments(children));
        }
        continue;
      }

      result.push(seg);
    }
    return result;
  }

  function unwrapSubjectWithPredicate(segments) {
    if (!Array.isArray(segments)) return segments;
    const result = [];
    for (const seg of segments) {
      const children = Array.isArray(seg.children) ? seg.children : [];
      if (seg.syntacticComponent === "subject" && children.some(c => c.syntacticComponent === "predicate")) {
        result.push(...children);
      } else {
        result.push(seg);
      }
    }
    return result;
  }

  function promoteOutOfSpanChildren(segments, sentence) {
    if (!Array.isArray(segments)) return segments;
    if (!sentence) return segments;
    const result = [];
    for (const seg of segments) {
      result.push(seg);
      const children = Array.isArray(seg.children) ? seg.children : [];
      if (children.length === 0) continue;
      const parentText = String(seg.text || "").trim();
      const parentStart = sentence.indexOf(parentText);
      if (parentStart < 0) continue;
      const parentEnd = parentStart + parentText.length;
      const within = [];
      const outside = [];
      for (const child of children) {
        const childText = String(child.text || "").trim();
        const childStart = sentence.indexOf(childText);
        if (childStart < 0 || childStart >= parentEnd) {
          outside.push(child);
        } else {
          within.push(child);
        }
      }
      if (outside.length > 0) {
        seg.children = within.length > 0 ? within : undefined;
        for (const child of outside) {
          result.push({ ...child, children: Array.isArray(child.children) ? child.children : undefined });
        }
      }
    }
    return result;
  }

  function getInlineWrapperSegment(sentence, segments) {
    if (!Array.isArray(segments) || segments.length !== 1) return null;
    const [segment] = segments;
    const text = normalizeSpaces(segment?.text || "");
    if (!text) return null;
    const children = Array.isArray(segment.children) ? segment.children.filter((child) => normalizeSpaces(child?.text || "")) : [];
    if (children.length < 2) return null;
    if (!textsCoverSameMaterial(text, sentence)) return null;
    if (!childrenCoverEnoughMaterial(children, sentence)) return null;
    return segment;
  }

  function buildInlineWrapperSentence(sentence, segment, depth) {
    const fragment = document.createDocumentFragment();
    const text = String(segment?.text || "").trim();
    const index = findSegmentIndex(sentence, text, 0);
    if (index < 0) {
      fragment.appendChild(document.createTextNode(sentence));
      return fragment;
    }

    if (index > 0) {
      fragment.appendChild(document.createTextNode(sentence.slice(0, index)));
    }

    const originalText = sentence.slice(index, index + text.length);
    const role = normalizeElement(segment.syntacticComponent);
    const label = normalizeLabel(String(segment.label || ""), elementLabel(role));
    const children = Array.isArray(segment.children) ? segment.children : [];
    const part = document.createElement("span");
    part.className = `${PART_CLASS} egc-element-${role} egc-wrapper-part${depth > 0 ? " egc-nested-part" : ""} egc-has-nested`;
    part.dataset.roleLabel = label;
    part.dataset.translation = String(segment.translation || "");
    part.dataset.egcDetail = [part.dataset.roleLabel, segment.translation, segment.reason].filter(Boolean).join("：");
    part.classList.add("egc-nested-collapsed");
    part.dataset.egcNestedKey = `nested-${++nestedSegmentIdCounter}`;
    part.setAttribute("role", "button");
    part.setAttribute("tabindex", "0");
    part.setAttribute("aria-expanded", "false");
    part.title = "点击查看这一层的内部分析";
    part.__egcNestedSegment = {
      text: originalText,
      role,
      label,
      translation: String(segment.translation || ""),
      note: String(segment.reason || ""),
      children
    };
    part.appendChild(document.createTextNode(originalText));
    if (label) part.appendChild(buildPartLabel(label));
    fragment.appendChild(part);

    const cursor = index + text.length;
    if (cursor < sentence.length) {
      fragment.appendChild(document.createTextNode(sentence.slice(cursor)));
    }
    return fragment;
  }

  function textsCoverSameMaterial(left, right) {
    return normalizeComparableSegmentText(left) === normalizeComparableSegmentText(right);
  }

  function childrenCoverEnoughMaterial(children, sentence) {
    const childText = children.map((child) => child.text).join(" ");
    const childMaterial = normalizeComparableSegmentText(childText);
    const sentenceMaterial = normalizeComparableSegmentText(sentence);
    if (!childMaterial || !sentenceMaterial) return false;
    return sentenceMaterial.includes(childMaterial) && childMaterial.length / sentenceMaterial.length >= 0.8;
  }

  function normalizeComparableSegmentText(text) {
    return normalizeSpaces(text)
      .toLowerCase()
      .replace(/[\s\p{P}\p{S}]+/gu, "");
  }

  function buildPartLabel(label) {
    const element = document.createElement("span");
    element.className = PART_LABEL_CLASS;
    element.setAttribute("aria-hidden", "true");
    element.textContent = label;
    return element;
  }

  function toggleNestedAnalysis(part) {
    const segment = part.__egcNestedSegment;
    if (!segment?.children?.length) return;

    const sentenceNode = part.closest(`.${SENTENCE_CLASS}.egc-annotated`);
    const owner = sentenceNode || findNestedPanelOwner(part);
    if (!owner?.isConnected) return;

    const existing = findNestedAnalysisPanel(owner);
    if (existing?.dataset.egcNestedKey === part.dataset.egcNestedKey) {
      removeNestedAnalysisPanel(owner);
      return;
    }

    removeNestedAnalysisPanel(owner);
    clearNestedActiveParts(owner);

    part.classList.add("egc-nested-active");
    part.setAttribute("aria-expanded", "true");

    const panel = buildNestedAnalysisPanel(owner, part, segment);
    const anchor = findSentenceTranslation(owner) || owner;
    anchor.insertAdjacentElement("afterend", panel);
    schedulePartLabelLayout(panel);
  }

  function buildNestedAnalysisPanel(owner, part, segment) {
    const ownerId = ensureSentenceTranslationId(owner);
    const panel = document.createElement("span");
    panel.className = NESTED_PANEL_CLASS;
    panel.dataset.egcNestedFor = ownerId;
    panel.dataset.egcNestedKey = part.dataset.egcNestedKey || "";
    panel.dataset.egcOwnerTranslationAnchor = ensureTranslationAnchorId(findTranslationAnchor(owner));

    const head = document.createElement("span");
    head.className = "egc-nested-analysis-head";

    const title = document.createElement("span");
    title.className = "egc-nested-analysis-title";
    title.textContent = `${segment.label || elementLabel(segment.syntacticComponent)}内部分析`;
    head.appendChild(title);

    const close = document.createElement("button");
    close.type = "button";
    close.className = "egc-nested-analysis-close";
    close.setAttribute("aria-label", "关闭内部分析");
    close.textContent = "×";
    close.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      removeNestedAnalysisPanel(owner);
    });
    head.appendChild(close);
    panel.appendChild(head);

    const sentence = document.createElement("span");
    sentence.className = "egc-nested-analysis-sentence";
    sentence.appendChild(buildSegmentedSentence(segment.text, segment.children, 1, false));
    panel.appendChild(sentence);

    const detailText = [segment.translation, segment.reason].filter(Boolean).join("；");
    if (detailText) {
      const detail = document.createElement("span");
      detail.className = "egc-nested-analysis-detail";
      detail.textContent = detailText;
      panel.appendChild(detail);
    }

    return panel;
  }

  function findNestedPanelOwner(element) {
    const panel = element.closest?.(`.${NESTED_PANEL_CLASS}`);
    const ownerId = panel?.dataset?.egcNestedFor;
    if (!ownerId) return null;
    return findSentenceByTranslationId(ownerId);
  }

  function findNestedAnalysisPanel(sentenceNode) {
    const id = sentenceNode?.dataset?.egcTranslationId;
    if (!id) return null;
    for (const panel of document.querySelectorAll(`.${NESTED_PANEL_CLASS}[data-egc-nested-for]`)) {
      if (panel.dataset.egcNestedFor === id) return panel;
    }
    return null;
  }

  function removeNestedAnalysisPanel(sentenceNode) {
    const panel = findNestedAnalysisPanel(sentenceNode);
    if (panel) panel.remove();
    clearNestedActiveParts(sentenceNode);
  }

  function clearNestedActiveParts(root) {
    if (!root?.isConnected) return;
    const ownerId = root.dataset?.egcTranslationId;
    const roots = [root];
    if (ownerId) {
      for (const panel of document.querySelectorAll(`.${NESTED_PANEL_CLASS}[data-egc-nested-for]`)) {
        if (panel.dataset.egcNestedFor === ownerId) roots.push(panel);
      }
    }

    for (const item of roots) {
      for (const part of item.querySelectorAll?.(`.${PART_CLASS}.egc-nested-active`) || []) {
        part.classList.remove("egc-nested-active");
        part.setAttribute("aria-expanded", "false");
      }
    }
  }

  function isPunctuationOnlySegment(text) {
    const value = String(text || "").trim();
    return Boolean(value) && !/[A-Za-z0-9\u4e00-\u9fff]/.test(value);
  }

  function scheduleAnnotatedLabelLayout() {
    if (!enabled) return;
    for (const sentenceNode of document.querySelectorAll(`.${SENTENCE_CLASS}.egc-annotated`)) {
      schedulePartLabelLayout(sentenceNode);
    }
    for (const panel of document.querySelectorAll(`.${NESTED_PANEL_CLASS}`)) {
      schedulePartLabelLayout(panel);
    }
  }

  function schedulePartLabelLayout(sentenceNode) {
    if (!sentenceNode?.isConnected) return;
    pendingLabelLayout.add(sentenceNode);
    if (labelLayoutFrame) return;

    labelLayoutFrame = requestAnimationFrame(() => {
      labelLayoutFrame = 0;
      const sentences = Array.from(pendingLabelLayout);
      pendingLabelLayout.clear();
      for (const item of sentences) {
        layoutPartLabels(item);
      }
    });
  }

  function layoutPartLabels(sentenceNode) {
    if (!sentenceNode?.isConnected) return;

    const items = collectPartLabelLayoutItems(sentenceNode);
    if (!items.length) {
      sentenceNode.style.removeProperty("--egc-label-stack-space");
      return;
    }

    const groups = groupLabelItemsByLine(items);
    let maxLane = 0;

    for (const group of groups) {
      const laneRights = [];
      for (const item of group.items.sort((left, right) => left.labelLeft - right.labelLeft)) {
        let lane = 0;
        while (laneRights[lane] != null && item.labelLeft < laneRights[lane] + LABEL_COLLISION_GAP_PX) {
          lane += 1;
        }

        laneRights[lane] = item.labelRight;
        item.label.style.setProperty("--egc-label-lane-offset", `${lane * LABEL_LINE_STEP_EM}em`);
        item.label.style.setProperty("--egc-label-shift", `${item.labelShift}px`);
        maxLane = Math.max(maxLane, lane);
      }
    }

    // Always reserve space for at least one label row so that labels on one
    // line of a wrapped sentence don't overlap with text on the next line.
    sentenceNode.style.setProperty("--egc-label-stack-space", `${Math.max(0, maxLane * LABEL_LINE_STEP_EM)}em`);
  }

  function collectPartLabelLayoutItems(sentenceNode) {
    const viewportWidth = window.innerWidth || document.documentElement.clientWidth || 0;
    const viewportPadding = LABEL_COLLISION_GAP_PX;
    const parts = Array.from(sentenceNode.querySelectorAll(`.${PART_CLASS}`));
    const items = [];

    for (const part of parts) {
      const label = part.querySelector(`:scope > .${PART_LABEL_CLASS}`);
      if (!label) continue;

      label.style.setProperty("--egc-label-lane-offset", "0em");
      label.style.setProperty("--egc-label-shift", "0px");

      const partRect = part.getBoundingClientRect();
      if (!partRect.width && !partRect.height) continue;

      const labelWidth = label.offsetWidth;
      const center = partRect.left + partRect.width / 2;
      let labelLeft = center - labelWidth / 2;
      let labelRight = center + labelWidth / 2;
      let labelShift = 0;

      if (viewportWidth > 0) {
        if (labelLeft < viewportPadding) {
          labelShift = viewportPadding - labelLeft;
        } else if (labelRight > viewportWidth - viewportPadding) {
          labelShift = viewportWidth - viewportPadding - labelRight;
        }
        labelLeft += labelShift;
        labelRight += labelShift;
      }

      items.push({
        label,
        labelLeft,
        labelRight,
        labelShift,
        lineCenter: partRect.top + partRect.height / 2,
        lineTolerance: Math.max(4, partRect.height * 0.5)
      });
    }

    return items;
  }

  function groupLabelItemsByLine(items) {
    const groups = [];
    for (const item of items.sort((left, right) => left.lineCenter - right.lineCenter || left.labelLeft - right.labelLeft)) {
      let group = groups.find((candidate) => Math.abs(candidate.lineCenter - item.lineCenter) <= item.lineTolerance);
      if (!group) {
        group = { lineCenter: item.lineCenter, items: [] };
        groups.push(group);
      }
      group.items.push(item);
      group.lineCenter = (group.lineCenter * (group.items.length - 1) + item.lineCenter) / group.items.length;
    }
    return groups;
  }

  function findSegmentIndex(sentence, segmentText, cursor) {
    const direct = sentence.indexOf(segmentText, cursor);
    if (direct >= 0) return direct;

    const pattern = segmentText
      .trim()
      .split(/\s+/)
      .filter(Boolean)
      .map(escapeRegExp)
      .join("\\s+");
    if (pattern) {
      const match = sentence.slice(cursor).match(new RegExp(pattern, "i"));
      if (match) return cursor + match.index;
    }
    return -1;
  }

  function escapeRegExp(text) {
    return String(text).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }

  function buildTranslationText(result) {
    const parts = [];
    if (result?.translation) {
      parts.push(`译文：${result.translation}`);
    }
    if (Array.isArray(result?.notes) && result.notes.length) {
      parts.push(`说明：${result.notes.join("；")}`);
    }
    return parts.join("  ");
  }

  function buildLearningCardData(sentence, result = {}) {
    const segments = normalizeLearningSegments(result.segments);
    return {
      sentence: normalizeSpaces(result.sentence || sentence || ""),
      translation: normalizeSpaces(result.translation || ""),
      fallback: Boolean(result.fallback),
      segments,
      sentenceAnalysis: normalizeSentenceLearningAnalysis(result.sentenceAnalysis || result.learningAnalysis || result.analysisCard, segments),
      notes: normalizeLearningList(result.notes, 4),
      words: normalizeLearningWords(result.words || result.vocabulary || result.keyWords || result.importantWords),
      phrases: normalizeLearningPhrases(result.phrases, segments),
      examples: normalizeLearningExamples(result.examples)
    };
  }

  function normalizeLearningSegments(value, depth = 0) {
    return (Array.isArray(value) ? value : [])
      .map((segment) => ({
        text: normalizeSpaces(segment?.text || ""),
        syntacticComponent: normalizeElement(segment?.syntacticComponent),
        label: normalizeSpaces(segment?.label || elementLabel(normalizeElement(segment?.syntacticComponent))),
        translation: normalizeSpaces(segment?.translation || ""),
        note: normalizeSpaces(segment?.note || ""),
        children: depth >= 3 ? [] : normalizeLearningSegments(segment?.children, depth + 1)
      }))
      .filter((segment) => segment.text && segment.syntacticComponent !== "unknown" && !isPunctuationOnlySegment(segment.text))
      .slice(0, 10);
  }

  function normalizeLearningPhrases(value, segments = []) {
    const phrases = (Array.isArray(value) ? value : [])
      .map((phrase) => {
        if (typeof phrase === "string") {
          return { text: normalizeSpaces(phrase), translation: "", note: "" };
        }
        return {
          text: normalizeSpaces(phrase?.text || phrase?.phrase || phrase?.expression || ""),
          translation: normalizeSpaces(phrase?.translation || phrase?.meaning || ""),
          note: normalizeSpaces(phrase?.note || phrase?.explanation || phrase?.usage || "")
        };
      })
      .filter((phrase) => phrase.text);

    if (phrases.length) return phrases.slice(0, 4);

    return segments
      .filter((segment) => countEnglishWords(segment.text) > 1 && (segment.translation || segment.reason))
      .map((segment) => ({
        text: segment.text,
        translation: segment.translation,
        note: segment.reason || `${segment.label}成分`
      }))
      .slice(0, 4);
  }

  function normalizeLearningWords(value) {
    return (Array.isArray(value) ? value : [])
      .map((word) => {
        if (typeof word === "string") {
          return { text: normalizeSpaces(word), translation: "", partOfSpeech: "", note: "" };
        }
        const noteRaw = word?.note || word?.explanation || word?.usage;
        const note =
          typeof noteRaw === "object" && noteRaw !== null && !Array.isArray(noteRaw)
            ? noteRaw
            : normalizeSpaces(String(noteRaw || ""));
        return {
          text: normalizeSpaces(word?.text || word?.word || word?.term || word?.vocabulary || ""),
          translation: normalizeSpaces(word?.translation || word?.meaning || word?.definition || ""),
          partOfSpeech: normalizeSpaces(word?.partOfSpeech || word?.pos || word?.type || ""),
          level: word?.level || "",
          note
        };
      })
      .filter((word) => word.text);
  }

  function normalizeLearningExamples(value) {
    return (Array.isArray(value) ? value : [])
      .map((example) => {
        if (typeof example === "string") {
          return { english: normalizeSpaces(example), translation: "" };
        }
        return {
          english: normalizeSpaces(example?.english || example?.sentence || example?.example || ""),
          translation: normalizeSpaces(example?.translation || example?.meaning || "")
        };
      })
      .filter((example) => example.english)
      .slice(0, 3);
  }

  function normalizeSentenceLearningAnalysis(value, segments = []) {
    const source = value && typeof value === "object" ? value : {};
    const normalized = {
      skeleton: normalizeSpaces(source.skeleton || source.mainStructure || source.mainClause || ""),
      paraphrase: normalizeSpaces(source.paraphrase || source.plainMeaning || source.plainChinese || source.rephrase || ""),
      tone: normalizeSpaces(source.tone || source.register || source.pragmatics || source.context || source.impliedContext || ""),
      structure: normalizeAnalysisRows(source.structure || source.layers || source.hierarchy, 5),
      readingPath: normalizeLearningList(source.readingPath || source.readingSteps || source.howToRead, 4),
      learningPoints: normalizeLearningList(source.learningPoints || source.keyPoints || source.commonPitfalls, 4)
    };

    return normalized;
  }

  function normalizeAnalysisRows(value, limit) {
    return (Array.isArray(value) ? value : [])
      .map((item) => {
        if (typeof item === "string") {
          return { label: "", text: normalizeSpaces(item), note: "" };
        }
        return {
          label: normalizeSpaces(item?.label || item?.type || item?.name || ""),
          text: normalizeSpaces(item?.text || item?.content || item?.phrase || ""),
          note: normalizeSpaces(item?.note || item?.explanation || item?.syntacticComponent || "")
        };
      })
      .filter((item) => item.text || item.note)
      .slice(0, limit);
  }

  function hasSentenceAnalysisContent(analysis) {
    return Boolean(
      analysis?.skeleton
      || analysis?.paraphrase
      || analysis?.tone
      || analysis?.structure?.length
      || analysis?.readingPath?.length
      || analysis?.learningPoints?.length
    );
  }

  function normalizeLearningList(value, limit) {
    return (Array.isArray(value) ? value : [])
      .map((item) => normalizeSpaces(item || ""))
      .filter(Boolean)
      .slice(0, limit);
  }

  function filterRedundantLearningItems(items, referenceTexts, limit = 4) {
    const references = (Array.isArray(referenceTexts) ? referenceTexts : [])
      .map((item) => normalizeSpaces(item))
      .filter(Boolean);
    const result = [];

    for (const item of Array.isArray(items) ? items : []) {
      const text = normalizeSpaces(item);
      if (!text) continue;
      if (references.some((reference) => isSimilarLearningText(text, reference))) continue;
      if (result.some((accepted) => isSimilarLearningText(text, accepted))) continue;
      result.push(text);
      references.push(text);
      if (result.length >= limit) break;
    }

    return result;
  }

  function filterRedundantLearningObjects(items, referenceTexts, limit = 5) {
    const references = (Array.isArray(referenceTexts) ? referenceTexts : [])
      .map((item) => normalizeSpaces(item))
      .filter(Boolean);
    const result = [];

    for (const item of Array.isArray(items) ? items : []) {
      const text = normalizeSpaces(item?.text || item?.word || "");
      if (!text) continue;
      const details = [item.translation, typeof item.note === "string" ? item.note : ""].filter(Boolean);
      if (details.some((value) => references.some((reference) => isSimilarLearningText(value, reference)))) continue;
      if (result.some((accepted) => isSimilarLearningText(text, accepted.text))) continue;
      result.push(item);
      references.push(text, ...details);
      if (result.length >= limit) break;
    }

    return result;
  }

  function isSimilarLearningText(left, right) {
    const leftText = normalizeComparableLearningText(left);
    const rightText = normalizeComparableLearningText(right);
    if (!leftText || !rightText) return false;
    if (leftText === rightText) return true;
    const shorter = leftText.length <= rightText.length ? leftText : rightText;
    const longer = leftText.length > rightText.length ? leftText : rightText;
    if (shorter.length >= 8 && longer.includes(shorter)) return true;

    const leftTokens = tokenizeComparableLearningText(leftText);
    const rightTokens = tokenizeComparableLearningText(rightText);
    if (!leftTokens.length || !rightTokens.length) return false;
    const rightSet = new Set(rightTokens);
    const overlap = leftTokens.filter((token) => rightSet.has(token)).length;
    return overlap / Math.min(leftTokens.length, rightTokens.length) >= 0.75;
  }

  function normalizeComparableLearningText(text) {
    return normalizeSpaces(text)
      .toLowerCase()
      .replace(/[“”"‘’'`()[\]{}<>]/g, "")
      .replace(/[，。！？；：、,.!?;:/\\|-]+/g, " ")
      .replace(/\s+/g, " ")
      .trim();
  }

  function tokenizeComparableLearningText(text) {
    return text.match(/[a-z0-9]+|[\u4e00-\u9fff]/g) || [];
  }

  function showTranslationTooltip(sentenceNode, event) {
    const data = getSentenceLearningCardData(sentenceNode);
    if (!hasLearningCardContent(data)) {
      hideTranslationTooltip();
      return;
    }

    const tooltip = ensureTranslationTooltip();
    if (!tooltip) return;

    translationTooltipSentence = sentenceNode;
    renderLearningTooltip(tooltip, data);
    resetTranslationTooltipScroll(tooltip);
    tooltip.classList.add("egc-visible");
    positionTranslationTooltip(event, sentenceNode);
    if (tooltipTheme) applyTooltipTheme(tooltip, tooltipTheme);
  }

  function resetTranslationTooltipScroll(tooltip) {
    if (!tooltip) return;
    tooltip.scrollTop = 0;
    tooltip.scrollLeft = 0;
  }

  function ensureTranslationTooltip() {
    if (translationTooltip?.isConnected) return translationTooltip;
    if (!document.body) return null;

    translationTooltip = document.createElement("div");
    translationTooltip.className = TRANSLATION_TOOLTIP_CLASS;
    translationTooltip.setAttribute("role", "tooltip");
    translationTooltip.setAttribute("aria-hidden", "true");
    translationTooltip.addEventListener("pointerenter", () => {
      clearTooltipHideTimer();
    });
    translationTooltip.addEventListener("pointerleave", (event) => {
      if (translationTooltipSentence?.contains(event.relatedTarget)) return;
      if (translationTooltip?._themePanel?.classList.contains("egc-open")) return;
      hideTranslationTooltip();
    });
    translationTooltip.addEventListener("wheel", stopTooltipScrollPropagation, { passive: true });
    translationTooltip.addEventListener("touchmove", stopTooltipScrollPropagation, { passive: true });

    // Theme panel (not appended to DOM yet — will be inserted by renderLearningTooltip)
    const themePanel = document.createElement("div");
    themePanel.className = "egc-theme-panel";
    themePanel.addEventListener("pointerenter", () => clearTooltipHideTimer());

    // Content wrapper
    const contentWrapper = document.createElement("div");
    contentWrapper.className = "egc-tooltip-content";

    translationTooltip.appendChild(contentWrapper);
    translationTooltip._themePanel = themePanel;
    translationTooltip._contentWrapper = contentWrapper;

    // Build theme controls and load saved theme
    buildThemePanelContent(themePanel, translationTooltip);
    loadTooltipTheme().then(theme => applyTooltipTheme(translationTooltip, theme));

    document.body.appendChild(translationTooltip);
    return translationTooltip;
  }

  function stopTooltipScrollPropagation(event) {
    event.stopPropagation();
  }

  function isScrollableTooltip() {
    return Boolean(translationTooltip && translationTooltip.scrollHeight > translationTooltip.clientHeight + 1);
  }

  function positionTranslationTooltip(event, sentenceNode) {
    const tooltip = translationTooltip;
    if (!tooltip?.classList.contains("egc-visible")) return;

    const vv = window.visualViewport;
    const viewportWidth = vv ? vv.width : (window.innerWidth || document.documentElement.clientWidth || 0);
    const viewportHeight = vv ? vv.height : (window.innerHeight || document.documentElement.clientHeight || 0);
    const visualOffsetY = vv ? vv.offsetTop : 0;
    const visualOffsetX = vv ? vv.offsetLeft : 0;
    const margin = TOOLTIP_VIEWPORT_MARGIN_PX;
    const offset = TOOLTIP_OFFSET_PX;
    const sentenceRect = sentenceNode.getBoundingClientRect();

    // Width: more space below → narrower; less space → wider (to reduce vertical scroll)
    const availableBelow = visualOffsetY + viewportHeight - sentenceRect.bottom - offset - margin;
    const narrowWidth = 440;
    const wideWidth = Math.min(820, viewportWidth - 16);
    const widthRatio = Math.min(1, Math.max(0, 1 - (availableBelow - 200) / 500));
    const desiredWidth = Math.round(narrowWidth + widthRatio * (wideWidth - narrowWidth));
    tooltip.style.width = `${Math.round(Math.min(desiredWidth, viewportWidth - 16))}px`;

    tooltip.style.left = "0px";
    tooltip.style.top = "0px";
    const tooltipRect = tooltip.getBoundingClientRect();

    const cursorX = event?.clientX ?? sentenceRect.left + sentenceRect.width / 2;

    // Horizontal: center on cursor X, clamped to visual viewport
    let left = visualOffsetX + clamp(cursorX - visualOffsetX - tooltipRect.width / 2, margin, viewportWidth - tooltipRect.width - margin);

    // Always below the sentence
    let top = sentenceRect.bottom + offset;

    // If tooltip would overflow viewport bottom, try placing above the sentence
    const tooltipHeight = tooltipRect.height;
    const overflowBottom = top + tooltipHeight - visualOffsetY - viewportHeight + margin;
    if (overflowBottom > 0) {
      const availableAbove = sentenceRect.top - visualOffsetY - margin;
      if (availableAbove >= tooltipHeight) {
        top = sentenceRect.top - tooltipHeight - offset;
      } else {
        // Clamp to viewport — user can scroll within the tooltip
        top = Math.max(visualOffsetY + margin, visualOffsetY + viewportHeight - tooltipHeight - margin);
      }
    }

    tooltip.style.left = `${left}px`;
    tooltip.style.top = `${top}px`;
  }

  function hideTranslationTooltip() {
    clearTooltipHideTimer();
    translationTooltipSentence = null;
    if (translationTooltip) {
      translationTooltip.classList.remove("egc-visible");
      translationTooltip.style.width = "";
    }
  }

  function speak(text, button, lang = "en-US") {
    stopSpeech();
    if (!text || typeof speechSynthesis === "undefined") return;

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = lang;
    utterance.rate = 0.88;

    speechActive = true;
    utterance.onstart = () => {
      button?.classList.add("egc-speaking");
    };
    utterance.onend = () => {
      speechActive = false;
      button?.classList.remove("egc-speaking");
    };
    utterance.onerror = () => {
      speechActive = false;
      button?.classList.remove("egc-speaking");
    };

    speechSynthesis.speak(utterance);
  }

  function stopSpeech() {
    if (typeof speechSynthesis === "undefined") return;
    speechSynthesis.cancel();
    speechActive = false;
    for (const button of document.querySelectorAll(".egc-speaking")) {
      button.classList.remove("egc-speaking");
    }
  }

  function buildSpeakGroup(text) {
    const group = document.createElement("span");
    group.className = "egc-speak-group";

    const uk = document.createElement("button");
    uk.type = "button";
    uk.className = "egc-speak-button";
    uk.setAttribute("aria-label", "英式发音");
    uk.textContent = "UK";
    uk.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      speak(text, uk, "en-GB");
    });

    const us = document.createElement("button");
    us.type = "button";
    us.className = "egc-speak-button";
    us.setAttribute("aria-label", "美式发音");
    us.textContent = "US";
    us.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      speak(text, us, "en-US");
    });

    group.appendChild(uk);
    group.appendChild(us);
    return group;
  }

  function getSentenceTranslationText(sentenceNode) {
    const translation = findSentenceTranslation(sentenceNode);
    return extractNaturalTranslation(translation?.textContent || "");
  }

  function getSentenceLearningCardData(sentenceNode) {
    const parsed = parseLearningCardData(sentenceNode.dataset.egcLearningCard);
    if (parsed) return parsed;
    return {
      sentence: normalizeSpaces(sentenceNode.dataset.egcOriginal || sentenceNode.textContent || ""),
      translation: getSentenceTranslationText(sentenceNode),
      fallback: false,
      segments: [],
      sentenceAnalysis: normalizeSentenceLearningAnalysis(null, []),
      notes: [],
      words: [],
      phrases: [],
      examples: []
    };
  }

  function parseLearningCardData(value) {
    if (!value) return null;
    try {
      const parsed = JSON.parse(value);
      if (!parsed || typeof parsed !== "object") return null;
      return {
        sentence: normalizeSpaces(parsed.sentence || ""),
        translation: normalizeSpaces(parsed.translation || ""),
        fallback: Boolean(parsed.fallback),
        segments: normalizeLearningSegments(parsed.segments),
        sentenceAnalysis: normalizeSentenceLearningAnalysis(parsed.sentenceAnalysis || parsed.learningAnalysis || parsed.analysisCard, normalizeLearningSegments(parsed.segments)),
        notes: normalizeLearningList(parsed.notes, 4),
        words: normalizeLearningWords(parsed.words || parsed.vocabulary || parsed.keyWords || parsed.importantWords),
        phrases: normalizeLearningPhrases(parsed.phrases, normalizeLearningSegments(parsed.segments)),
        examples: normalizeLearningExamples(parsed.examples)
      };
    } catch {
      return null;
    }
  }

  function hasLearningCardContent(data) {
    return Boolean(data?.translation || hasSentenceAnalysisContent(data?.sentenceAnalysis) || data?.segments?.length || data?.notes?.length || data?.words?.length || data?.phrases?.length || data?.examples?.length);
  }

  function renderLearningTooltip(tooltip, data) {
    const wrapper = tooltip._contentWrapper || tooltip;
    wrapper.textContent = "";
    const display = buildLearningDisplayProfile(data);
    appendContinueChatButton(wrapper, data);
    // Theme panel always goes right after the chat row, before content sections
    if (tooltip._themePanel) wrapper.appendChild(tooltip._themePanel);
    appendMeaningSection(wrapper, data, display);
    appendWordSection(wrapper, display.words);
    appendPhraseSection(wrapper, data.phrases);
    if (display.showStructure) appendStructureSection(wrapper, data.sentenceAnalysis);
    appendTooltipListSection(wrapper, "补充说明", display.notes);
    appendExampleSection(wrapper, data.examples);
  }

  // ── 浮窗主题 ─────────────────────────────────

  const TOOLTIP_THEME_KEY = "tooltipThemeSettings";

  const THEME_PRESETS = [
    { id: "dark",   label: "深色", color: "#12141f" },
    { id: "strong", label: "极夜", color: "#080a12" },
    { id: "green",  label: "墨绿", color: "#1a2e28" },
    { id: "blue",   label: "藏蓝", color: "#1a2235" },
    { id: "warm",   label: "暖灰", color: "#2d261c" }
  ];

  function getDefaultTooltipTheme() {
    return { preset: "dark", opacity: 0.56, blur: 1.5 };
  }

  function hexToRgba(hex, alpha) {
    const num = parseInt(hex.slice(1), 16);
    return `rgba(${num >> 16}, ${(num >> 8) & 0xff}, ${num & 0xff}, ${alpha})`;
  }

  function darkenHex(hex, amount) {
    const num = parseInt(hex.slice(1), 16);
    const r = Math.max((num >> 16) - amount, 0);
    const g = Math.max(((num >> 8) & 0xff) - amount, 0);
    const b = Math.max((num & 0xff) - amount, 0);
    return "#" + ((r << 16) | (g << 8) | b).toString(16).padStart(6, "0");
  }

  async function loadTooltipTheme() {
    try {
      const result = await chrome.storage.local.get(TOOLTIP_THEME_KEY);
      tooltipTheme = result[TOOLTIP_THEME_KEY] || getDefaultTooltipTheme();
    } catch {
      tooltipTheme = getDefaultTooltipTheme();
    }
    return tooltipTheme;
  }

  async function saveTooltipTheme(theme) {
    tooltipTheme = theme;
    try {
      await chrome.storage.local.set({ [TOOLTIP_THEME_KEY]: theme });
    } catch { /* content script storage may fail in some contexts */ }
  }

  function applyTooltipTheme(tooltip, theme) {
    if (!tooltip) return;
    const preset = THEME_PRESETS.find(p => p.id === theme.preset) || THEME_PRESETS[0];
    const topColor = hexToRgba(preset.color, theme.opacity);
    const bottomColor = hexToRgba(darkenHex(preset.color, 8), theme.opacity);
    tooltip.style.background = `linear-gradient(180deg, ${topColor}, ${bottomColor})`;
    const blur = Math.max(0, theme.blur);
    const filter = blur > 0 ? `blur(${blur}px) saturate(0.95)` : "none";
    tooltip.style.backdropFilter = filter;
    tooltip.style.webkitBackdropFilter = filter;
  }

  function buildThemePanelContent(panel, tooltip) {
    const current = tooltipTheme || getDefaultTooltipTheme();

    // Presets
    const presetsLabel = document.createElement("div");
    presetsLabel.className = "egc-theme-label";
    presetsLabel.textContent = "背景色";
    panel.appendChild(presetsLabel);

    const presetsRow = document.createElement("div");
    presetsRow.className = "egc-theme-presets";

    for (const p of THEME_PRESETS) {
      const dot = document.createElement("div");
      dot.className = "egc-theme-preset" + (p.id === current.preset ? " egc-active" : "");
      dot.style.background = p.color;
      dot.title = p.label;
      dot.dataset.presetId = p.id;
      dot.addEventListener("click", (e) => {
        e.stopPropagation();
        updatePreset(p.id);
      });
      presetsRow.appendChild(dot);
    }

    panel.appendChild(presetsRow);

    // --- Opacity slider ---
    const opacityRow = document.createElement("div");
    opacityRow.className = "egc-theme-row";
    const opacityLabel = document.createElement("label");
    opacityLabel.textContent = "透明度";
    const opacityInput = document.createElement("input");
    opacityInput.type = "range";
    opacityInput.min = "0.3";
    opacityInput.max = "1";
    opacityInput.step = "0.01";
    opacityInput.value = String(current.opacity);
    const opacityVal = document.createElement("span");
    opacityVal.className = "egc-theme-value";
    opacityVal.textContent = current.opacity.toFixed(2);
    opacityRow.append(opacityLabel, opacityInput, opacityVal);
    panel.appendChild(opacityRow);
    opacityInput.addEventListener("input", (e) => {
      e.stopPropagation();
      const val = parseFloat(e.target.value);
      opacityVal.textContent = val.toFixed(2);
      const theme = { ...(tooltipTheme || getDefaultTooltipTheme()), opacity: val };
      applyTooltipTheme(tooltip, theme);
    });
    opacityInput.addEventListener("change", (e) => {
      e.stopPropagation();
      const theme = { ...(tooltipTheme || getDefaultTooltipTheme()), opacity: parseFloat(e.target.value) };
      saveTooltipTheme(theme);
    });

    // --- Blur slider ---
    const blurRow = document.createElement("div");
    blurRow.className = "egc-theme-row";
    const blurLabel = document.createElement("label");
    blurLabel.textContent = "模糊";
    const blurInput = document.createElement("input");
    blurInput.type = "range";
    blurInput.min = "0";
    blurInput.max = "20";
    blurInput.step = "0.5";
    blurInput.value = String(current.blur);
    const blurVal = document.createElement("span");
    blurVal.className = "egc-theme-value";
    blurVal.textContent = current.blur.toFixed(1) + "px";
    blurRow.append(blurLabel, blurInput, blurVal);
    panel.appendChild(blurRow);
    blurInput.addEventListener("input", (e) => {
      e.stopPropagation();
      const val = parseFloat(e.target.value);
      blurVal.textContent = val.toFixed(1) + "px";
      const theme = { ...(tooltipTheme || getDefaultTooltipTheme()), blur: val };
      applyTooltipTheme(tooltip, theme);
    });
    blurInput.addEventListener("change", (e) => {
      e.stopPropagation();
      const theme = { ...(tooltipTheme || getDefaultTooltipTheme()), blur: parseFloat(e.target.value) };
      saveTooltipTheme(theme);
    });

    function updatePreset(presetId) {
      const theme = { ...(tooltipTheme || getDefaultTooltipTheme()), preset: presetId };
      applyTooltipTheme(tooltip, theme);
      saveTooltipTheme(theme);
      presetsRow.querySelectorAll(".egc-theme-preset").forEach(d => d.classList.remove("egc-active"));
      const active = presetsRow.querySelector(`[data-preset-id="${presetId}"]`);
      if (active) active.classList.add("egc-active");
    }
  }

  function formatWordNote(note) {
    if (!note) return "";
    if (typeof note === "string") return ` — ${note}`;
    if (typeof note !== "object" || Array.isArray(note)) return "";
    const parts = [];
    const labels = { synonym: "近义辨析", collocation: "常见搭配", etymology: "词源" };
    for (const key of ["collocation", "synonym", "etymology"]) {
      const val = note[key];
      if (val && typeof val === "string") {
        parts.push(`${labels[key] || key}：${val}`);
      }
    }
    return parts.length ? ` — ${parts.join("；")}` : "";
  }

  function formatAnalysisAsMarkdown(data) {
    const lines = [];
    if (data.translation) lines.push(`**译文：**${data.translation}`);
    const sa = data.sentenceAnalysis;
    if (sa?.paraphrase) lines.push(`\n**白话：**${sa.paraphrase}`);
    if (sa?.skeleton) lines.push(`\n**主干：**${sa.skeleton}`);
    if (sa?.tone) lines.push(`\n**语气：**${sa.tone}`);
    if (Array.isArray(sa?.learningPoints) && sa.learningPoints.length) {
      lines.push(`\n**易错点：**`);
      for (const pt of sa.learningPoints.slice(0, 4)) {
        lines.push(`- ${pt}`);
      }
    }
    if (Array.isArray(sa?.structure) && sa.structure.length) {
      for (const row of sa.structure.slice(0, 4)) {
        lines.push(`\n**${row.label || "结构"}：**${row.text}`);
      }
    }
    if (Array.isArray(data.words) && data.words.length) {
      lines.push(`\n**重点单词：**`);
      for (const w of data.words.slice(0, 4)) {
        const levelTag = w.level ? ` [${w.level}]` : "";
        const posTag = w.partOfSpeech ? ` · ${w.partOfSpeech}` : "";
        const noteText = formatWordNote(w.note);
        lines.push(`- **${w.text}**${posTag}${levelTag} — ${w.translation}${noteText}`);
      }
    }
    if (Array.isArray(data.examples) && data.examples.length) {
      lines.push(`\n**例句：**`);
      for (const ex of data.examples.slice(0, 2)) {
        lines.push(`- ${ex.english}`);
        if (ex.translation) lines.push(`  ${ex.translation}`);
      }
    }
    return lines.join("\n");
  }

  function appendContinueChatButton(parent, data) {
    const row = document.createElement("div");
    row.className = "egc-tooltip-chat-row";

    const btn = document.createElement("button");
    btn.className = "egc-tooltip-chat-btn";
    btn.textContent = "💬 继续追问";
    btn.addEventListener("click", (event) => {
      event.stopPropagation();
      btn.disabled = true;
      btn.textContent = "打开中…";
      const md = formatAnalysisAsMarkdown(data);
      const s = window.screen;
      const sw = s?.availWidth, sh = s?.availHeight, sx = s?.availLeft || 0, sy = s?.availTop || 0;
      globalThis.chrome?.runtime?.sendMessage({
        action: "openPanelWithAnalysis",
        payload: {
          sentence: data.sentence || "",
          analysis: md,
          analysisData: data,
          sourceUrl: location.href,
          pageTitle: document.title,
          screenAvailWidth: sw || 1920,
          screenAvailHeight: sh || 1080,
          screenLeft: sx,
          screenTop: sy
        }
      }, () => {
        btn.disabled = false;
        btn.textContent = "💬 继续追问";
      });
    });

    const paletteBtn = document.createElement("button");
    paletteBtn.type = "button";
    paletteBtn.className = "egc-tooltip-header-btn";
    paletteBtn.textContent = "🎨";
    paletteBtn.title = "主题设置";
    paletteBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      translationTooltip?._themePanel?.classList.toggle("egc-open");
    });

    row.append(btn, paletteBtn);
    parent.appendChild(row);
  }

  function buildLearningDisplayProfile(data) {
    const analysis = data?.sentenceAnalysis || {};
    const flatSegments = flattenLearningSegments(data?.segments || []);
    const topLevelSegments = Array.isArray(data?.segments) ? data.segments : [];
    const hasNestedSegments = flatSegments.some((segment) => segment.depth > 0);
    const sentenceWordCount = countEnglishWords(data?.sentence || "");
    const hasStructureLayers = (analysis.structure || []).length > 1;
    const isComplex = hasNestedSegments || topLevelSegments.length >= 5 || sentenceWordCount >= 10 || hasStructureLayers;
    const meaningTexts = [data?.translation];
    const phraseTexts = (data?.phrases || []).flatMap((phrase) => [phrase.text, phrase.translation, phrase.note]);
    const filteredByLevel = Array.isArray(wordLevels)
      ? (data?.words || []).filter((w) => !w.level || wordLevels.includes(w.level))
      : (data?.words || []);
    const words = filterRedundantLearningObjects(filteredByLevel, [], 99);
    const wordTexts = words.flatMap((word) => [word.text, word.translation, word.note]);

    const showParaphrase = Boolean(
      analysis.paraphrase
      && !isSimilarLearningText(analysis.paraphrase, data?.translation)
    );
    if (showParaphrase) meaningTexts.push(analysis.paraphrase);

    const showSkeleton = Boolean(
      analysis.skeleton
      && isComplex
      && !isSimilarLearningText(analysis.skeleton, data?.sentence)
      && !meaningTexts.some((text) => isSimilarLearningText(analysis.skeleton, text))
    );
    if (showSkeleton) meaningTexts.push(analysis.skeleton);

    const showReadingPath = Boolean(isComplex && analysis.readingPath?.length);
    const showStructure = Boolean(isComplex && analysis.structure?.length);
    const showSegments = Boolean(
      hasNestedSegments
      || topLevelSegments.length >= 5
      || (!analysis.structure?.length && topLevelSegments.length)
    );
    const learningPoints = filterRedundantLearningItems(analysis.learningPoints || [], [
      ...meaningTexts,
      analysis.tone,
      ...wordTexts,
      ...phraseTexts
    ]);

    return {
      isComplex,
      showParaphrase,
      showSkeleton,
      showReadingPath,
      showStructure,
      showSegments,
      words,
      learningPoints,
      notes: filterRedundantLearningItems(data?.notes || [], [
        ...meaningTexts,
        analysis.tone,
        ...wordTexts,
        ...learningPoints,
        ...phraseTexts
      ])
    };
  }

  function buildTooltipTranslationText(data) {
    if (data?.translation) return data.translation;
    if (data?.fallback) return "分析不完整，暂未生成译文。";
    return "模型未返回译文。";
  }

  function buildCompactTranslationText(data) {
    if (data?.translation) return data.translation;
    if (data?.fallback) return "分析不完整，暂未生成译文。";
    return "";
  }

  function appendTooltipSection(parent, title, body) {
    if (!body) return;
    const section = document.createElement("section");
    section.className = "egc-tooltip-section";
    section.appendChild(buildTooltipTitle(title));
    const paragraph = document.createElement("p");
    paragraph.className = "egc-tooltip-text";
    paragraph.textContent = body;
    section.appendChild(paragraph);
    parent.appendChild(section);
  }

  function appendMeaningSection(parent, data, display) {
    const analysis = data?.sentenceAnalysis || {};
    if (!data?.translation && !hasSentenceAnalysisContent(analysis)) return;
    const section = document.createElement("section");
    section.className = "egc-tooltip-section egc-tooltip-priority-section";

    if (data?.sentence) {
      const row = buildTooltipRow("原文", data.sentence, "");
      const textEl = row.querySelector(".egc-tooltip-row-text");
      if (textEl) textEl.appendChild(buildSpeakGroup(data.sentence));
      section.appendChild(row);
    }
    appendTooltipRowIfText(section, "译文", buildCompactTranslationText(data), "");
    if (display.showParaphrase) {
      section.appendChild(buildTooltipRow("白话理解", analysis.paraphrase, ""));
    }
    if (display.showSkeleton) {
      section.appendChild(buildTooltipRow("主干", analysis.skeleton, ""));
    }
    if (analysis.tone) {
      section.appendChild(buildTooltipRow("语气/语境", analysis.tone, ""));
    }

    if (display.showReadingPath) {
      appendInlineTooltipList(section, "阅读顺序", analysis.readingPath, true);
    }
    appendInlineTooltipList(section, "学习重点", display.learningPoints, false);
    parent.appendChild(section);
  }

  function appendTooltipRowIfText(parent, label, text, detail) {
    if (!text) return;
    parent.appendChild(buildTooltipRow(label, text, detail));
  }

  function appendStructureSection(parent, analysis) {
    if (!analysis?.structure?.length) return;
    const section = document.createElement("section");
    section.className = "egc-tooltip-section";
    section.appendChild(buildTooltipTitle("结构层级"));

    for (const row of analysis.structure.slice(0, 5)) {
      section.appendChild(buildTooltipRow(row.label || "结构", row.text, row.note));
    }
    parent.appendChild(section);
  }

  function appendInlineTooltipList(parent, label, items, ordered) {
    if (!items?.length) return;
    const wrapper = document.createElement("div");
    wrapper.className = "egc-tooltip-subsection";
    wrapper.appendChild(buildTooltipTitle(label));
    const list = document.createElement(ordered ? "ol" : "ul");
    list.className = "egc-tooltip-list";
    for (const item of items.slice(0, 4)) {
      const listItem = document.createElement("li");
      listItem.textContent = item;
      list.appendChild(listItem);
    }
    wrapper.appendChild(list);
    parent.appendChild(wrapper);
  }

  function appendSegmentSection(parent, segments) {
    if (!segments?.length) return;
    const section = document.createElement("section");
    section.className = "egc-tooltip-section";
    section.appendChild(buildTooltipTitle("成分明细"));
    for (const segment of flattenLearningSegments(segments).slice(0, 16)) {
      section.appendChild(buildTooltipSegmentCard(segment));
    }
    parent.appendChild(section);
  }

  function buildTooltipSegmentCard(segment) {
    const card = document.createElement("div");
    card.className = "egc-tooltip-segment-card";
    card.style.setProperty("--egc-tooltip-depth", String(segment.depth || 0));

    const head = document.createElement("div");
    head.className = "egc-tooltip-segment-head";

    const label = document.createElement("span");
    label.className = "egc-tooltip-segment-label";
    label.textContent = segment.label || elementLabel(segment.syntacticComponent);
    head.appendChild(label);

    const text = document.createElement("span");
    text.className = "egc-tooltip-segment-text";
    text.textContent = segment.text;
    head.appendChild(text);
    card.appendChild(head);

    const detailText = [segment.translation, segment.reason].filter(Boolean).join("；");
    if (detailText) {
      const detail = document.createElement("div");
      detail.className = "egc-tooltip-segment-detail";
      detail.textContent = detailText;
      card.appendChild(detail);
    }

    return card;
  }

  function flattenLearningSegments(segments, depth = 0) {
    const rows = [];
    for (const segment of Array.isArray(segments) ? segments : []) {
      rows.push({ ...segment, depth });
      rows.push(...flattenLearningSegments(segment.children, depth + 1));
    }
    return rows;
  }

  function appendPhraseSection(parent, phrases) {
    if (!phrases?.length) return;
    const section = document.createElement("section");
    section.className = "egc-tooltip-section egc-tooltip-priority-section";
    section.appendChild(buildTooltipTitle("可复用表达"));
    for (const phrase of phrases.slice(0, 4)) {
      section.appendChild(buildTooltipRow(phrase.text, phrase.translation, phrase.note));
    }
    parent.appendChild(section);
  }

  function appendWordSection(parent, words) {
    if (!words?.length) return;
    const section = document.createElement("section");
    section.className = "egc-tooltip-section";
    section.appendChild(buildTooltipTitle("重点单词"));
    for (const word of words) {
      const label = [word.text, word.partOfSpeech].filter(Boolean).join(" · ");
      const row = buildTooltipRow(label, word.translation, word.note);
      row.classList.add("egc-word-row");
      if (word.text) {
        const labelElement = row.querySelector(".egc-tooltip-label");
        labelElement.textContent = "";
        const title = document.createElement("span");
        title.textContent = label;
        labelElement.appendChild(title);
        const actions = document.createElement("span");
        actions.className = "egc-word-actions";
        actions.appendChild(buildSpeakGroup(word.text));
        if (word.level) {
          const badge = document.createElement("span");
          badge.className = "egc-word-level-badge";
          badge.textContent = word.level;
          actions.appendChild(badge);
        }
        labelElement.appendChild(actions);
      }
      section.appendChild(row);
    }
    parent.appendChild(section);
  }

  function appendTooltipListSection(parent, title, items) {
    if (!items?.length) return;
    const section = document.createElement("section");
    section.className = "egc-tooltip-section";
    section.appendChild(buildTooltipTitle(title));
    const list = document.createElement("ul");
    list.className = "egc-tooltip-list";
    for (const item of items.slice(0, 4)) {
      const listItem = document.createElement("li");
      listItem.textContent = item;
      list.appendChild(listItem);
    }
    section.appendChild(list);
    parent.appendChild(section);
  }

  function appendExampleSection(parent, examples) {
    if (!examples?.length) return;
    const section = document.createElement("section");
    section.className = "egc-tooltip-section";
    section.appendChild(buildTooltipTitle("举例"));
    for (const example of examples.slice(0, 3)) {
      const row = buildTooltipRow("例句", example.english, example.translation);
      const textEl = row.querySelector(".egc-tooltip-row-text");
      if (textEl) textEl.appendChild(buildSpeakGroup(example.english));
      section.appendChild(row);
    }
    parent.appendChild(section);
  }

  function buildTooltipTitle(text) {
    const title = document.createElement("div");
    title.className = "egc-tooltip-title";
    title.textContent = text;
    return title;
  }

  function buildTooltipRow(label, text, detail) {
    const row = document.createElement("div");
    row.className = "egc-tooltip-row";

    const labelElement = document.createElement("span");
    labelElement.className = "egc-tooltip-label";
    labelElement.textContent = label;
    row.appendChild(labelElement);

    const body = document.createElement("span");
    body.className = "egc-tooltip-row-body";

    if (text) {
      const textEl = document.createElement("span");
      textEl.className = "egc-tooltip-row-text";
      textEl.textContent = text;
      body.appendChild(textEl);
    }

    if (detail) {
      const detailEl = document.createElement("span");
      detailEl.className = "egc-tooltip-row-detail";

      if (typeof detail === "object" && !Array.isArray(detail)) {
        const fields = [
          { key: "synonym", label: "近义辨析" },
          { key: "collocation", label: "常见搭配" },
          { key: "etymology", label: "词源" }
        ];
        for (const field of fields) {
          const value = detail[field.key];
          if (!value || typeof value !== "string") continue;
          const line = document.createElement("span");
          line.className = "egc-tooltip-detail-line";
          const labelEl = document.createElement("span");
          labelEl.className = "egc-tooltip-detail-label";
          labelEl.textContent = field.label;
          line.appendChild(labelEl);
          const contentEl = document.createElement("span");
          contentEl.className = "egc-tooltip-detail-content";
          contentEl.textContent = value;
          line.appendChild(contentEl);
          detailEl.appendChild(line);
        }
      } else {
        const text = String(detail);
        const parts = text.split(/(?=[①②③④])/);
        if (parts.length > 1) {
          for (const part of parts) {
            const trimmed = part.trim();
            if (!trimmed) continue;
            const colonIdx = trimmed.indexOf("：");
            const labelText = colonIdx > 0 ? trimmed.slice(0, colonIdx) : "";
            const contentText = colonIdx > 0 ? trimmed.slice(colonIdx + 1) : trimmed;
            const line = document.createElement("span");
            line.className = "egc-tooltip-detail-line";
            if (labelText) {
              const labelEl = document.createElement("span");
              labelEl.className = "egc-tooltip-detail-label";
              labelEl.textContent = labelText;
              line.appendChild(labelEl);
            }
            const contentEl = document.createElement("span");
            contentEl.className = "egc-tooltip-detail-content";
            contentEl.textContent = contentText;
            line.appendChild(contentEl);
            detailEl.appendChild(line);
          }
        } else {
          detailEl.textContent = text;
        }
      }
      body.appendChild(detailEl);
    }

    row.appendChild(body);
    return row;
  }

  function extractNaturalTranslation(text) {
    const normalized = normalizeSpaces(text);
    if (!normalized) return "";

    const translationPrefix = "译文：";
    const notePrefix = "说明：";
    if (normalized.startsWith(translationPrefix)) {
      const content = normalized.slice(translationPrefix.length);
      const noteIndex = content.indexOf(notePrefix);
      return normalizeSpaces(noteIndex >= 0 ? content.slice(0, noteIndex) : content);
    }
    return normalized;
  }

  function renderSentenceError(sentenceNode, error) {
    removeSentenceTranslation(sentenceNode);
    sentenceNode.removeAttribute("title");

    const translation = document.createElement("span");
    translation.className = `${TRANSLATION_CLASS} egc-error`;
    translation.textContent = `成分划分失败：${error?.message || String(error)}`;
    attachSentenceTranslation(sentenceNode, translation);
  }

  function attachSentenceTranslation(sentenceNode, translation) {
    const id = ensureSentenceTranslationId(sentenceNode);
    const anchor = findTranslationAnchor(sentenceNode);
    const anchorId = ensureTranslationAnchorId(anchor);
    translation.dataset.egcTranslationFor = id;
    translation.dataset.egcTranslationAnchor = anchorId;
    translation.setAttribute("aria-hidden", "true");
    translation.classList.toggle("egc-hidden", sentenceNode.classList.contains("egc-collapsed"));
    insertTranslationInSentenceOrder(anchor, sentenceNode, translation);
  }

  function insertTranslationInSentenceOrder(anchor, sentenceNode, translation) {
    const anchorId = anchor.dataset.egcTranslationAnchorId;
    let insertAfter = anchor;

    for (const existing of document.querySelectorAll(`.${TRANSLATION_CLASS}[data-egc-translation-anchor]`)) {
      if (existing.dataset.egcTranslationAnchor !== anchorId) continue;

      const existingSentence = findSentenceByTranslationId(existing.dataset.egcTranslationFor);
      if (existingSentence && precedes(sentenceNode, existingSentence)) {
        existing.before(translation);
        return;
      }
      insertAfter = findNestedAnalysisPanel(existingSentence) || existing;
    }

    insertAfter.insertAdjacentElement("afterend", translation);
  }

  function ensureSentenceTranslationId(sentenceNode) {
    if (!sentenceNode.dataset.egcTranslationId) {
      translationIdCounter += 1;
      sentenceNode.dataset.egcTranslationId = `egc-translation-${Date.now()}-${translationIdCounter}`;
    }
    return sentenceNode.dataset.egcTranslationId;
  }

  function ensureTranslationAnchorId(anchor) {
    if (!anchor.dataset.egcTranslationAnchorId) {
      translationAnchorIdCounter += 1;
      anchor.dataset.egcTranslationAnchorId = `egc-anchor-${Date.now()}-${translationAnchorIdCounter}`;
    }
    return anchor.dataset.egcTranslationAnchorId;
  }

  function findTranslationAnchor(sentenceNode) {
    if (sentenceNode.dataset.egcElement === "true") return sentenceNode;

    let anchor = sentenceNode;
    let current = sentenceNode.parentElement;
    while (current && current !== document.body && current !== document.documentElement) {
      if (!shouldLiftTranslationAnchor(current, anchor, sentenceNode)) break;
      anchor = current;
      current = current.parentElement;
    }
    return anchor;
  }

  function shouldLiftTranslationAnchor(element, anchor, sentenceNode) {
    const style = window.getComputedStyle(element);
    const display = style.display || "";
    if (display === "contents" || display.startsWith("inline")) return true;
    if (hasClippingOverflow(style)) return true;

    const anchorIsDirectChild = anchor.parentElement === element;
    const anchorWasLifted = anchor !== sentenceNode;
    if (display.includes("flex")) {
      return !style.flexDirection.startsWith("column") && (anchorIsDirectChild || anchorWasLifted);
    }
    if (display.includes("grid")) return anchorIsDirectChild || anchorWasLifted;
    return false;
  }

  function hasClippingOverflow(style) {
    return [style.overflow, style.overflowX, style.overflowY].some((value) => {
      return value === "hidden" || value === "clip" || value === "scroll" || value === "auto";
    });
  }

  function findSentenceTranslation(sentenceNode) {
    const id = sentenceNode.dataset.egcTranslationId;
    if (!id) return null;
    for (const translation of document.querySelectorAll(`.${TRANSLATION_CLASS}[data-egc-translation-for]`)) {
      if (translation.dataset.egcTranslationFor === id) return translation;
    }
    return null;
  }

  function findSentenceByTranslationId(id) {
    if (!id) return null;
    for (const sentence of document.querySelectorAll(`.${SENTENCE_CLASS}[data-egc-translation-id]`)) {
      if (sentence.dataset.egcTranslationId === id) return sentence;
    }
    return null;
  }

  function precedes(left, right) {
    return Boolean(left.compareDocumentPosition(right) & Node.DOCUMENT_POSITION_FOLLOWING);
  }

  function removeSentenceTranslation(sentenceNode) {
    removeNestedAnalysisPanel(sentenceNode);
    const translation = findSentenceTranslation(sentenceNode);
    translation?.remove();
  }

  function setSentenceTranslationCollapsed(sentenceNode, collapsed) {
    const translation = findSentenceTranslation(sentenceNode);
    const panel = findNestedAnalysisPanel(sentenceNode);
    translation?.classList.toggle("egc-hidden", Boolean(collapsed));
    panel?.classList.toggle("egc-hidden", Boolean(collapsed));
  }

  function unwrapAnnotations() {
    hideTranslationTooltip();
    pendingLabelLayout.clear();
    if (labelLayoutFrame) {
      cancelAnimationFrame(labelLayoutFrame);
      labelLayoutFrame = 0;
    }
    for (const translation of document.querySelectorAll(`.${TRANSLATION_CLASS}`)) {
      translation.remove();
    }
    for (const panel of document.querySelectorAll(`.${NESTED_PANEL_CLASS}`)) {
      panel.remove();
    }
    for (const element of document.querySelectorAll("[data-egc-translation-anchor-id]")) {
      delete element.dataset.egcTranslationAnchorId;
    }
    for (const sentence of document.querySelectorAll(`.${SENTENCE_CLASS}`)) {
      if (sentence.dataset.egcWrapper === "true") {
        sentence.replaceWith(document.createTextNode(sentence.dataset.egcOriginal || sentence.textContent || ""));
      } else {
        if (sentence.dataset.egcElement === "true" && sentence.dataset.egcOriginalHtml != null) {
          sentence.innerHTML = sentence.dataset.egcOriginalHtml;
        }
        sentence.classList.remove(SENTENCE_CLASS, "egc-loading", "egc-annotated", "egc-collapsed");
        sentence.style.removeProperty("--egc-label-stack-space");
        delete sentence.dataset.egcOriginal;
        delete sentence.dataset.egcOriginalHtml;
        delete sentence.dataset.egcElement;
        delete sentence.dataset.egcAnnotated;
        delete sentence.dataset.egcLoading;
        delete sentence.dataset.egcTranslationId;
        delete sentence.dataset.egcLearningCard;
        sentence.removeAttribute("title");
      }
    }
    document.body?.normalize();
    sentenceCount = 0;
  }

  const ELEMENT_MAP = new Map([
    ["subject", "subject"],
    ["predicate", "predicate"],
    ["object", "object"],
    ["predicative", "predicative"],
    ["directobject", "directObject"],
    ["indirectobject", "indirectObject"],
    ["objectcomplement", "objectComplement"],
    ["subjectcomplement", "subjectComplement"],
    ["attribute", "attribute"],
    ["adverbial", "adverbial"],
    ["appositive", "appositive"],
    ["parenthesis", "parenthesis"],
    ["formalsubject", "formalSubject"],
    ["formalobject", "formalObject"],
    ["cognateobject", "cognateObject"],
    ["vocative", "vocative"],
    ["conjunction", "conjunction"],
    ["nounphrase", "nounPhrase"],
    ["verbphrase", "verbPhrase"],
    ["prepositionalphrase", "prepositionalPhrase"],
    ["adjectivephrase", "adjectivePhrase"],
    ["adverbphrase", "adverbPhrase"],
    ["head", "head"],
    ["fragment", "fragment"],
  ]);
  const KNOWN_ELEMENTS = new Set(ELEMENT_MAP.values());

  function normalizeElement(value) {
    const text = String(value || "").trim().toLowerCase().replace(/[\s_-]+/g, "");
    return ELEMENT_MAP.get(text) || "unknown";
  }

  function elementLabel(role) {
    return {
      subject: "主语",
      predicate: "谓语",
      object: "宾语",
      predicative: "表语",
      directObject: "直接宾语",
      indirectObject: "间接宾语",
      objectComplement: "宾语补足语",
      subjectComplement: "主语补足语",
      attribute: "定语",
      adverbial: "状语",
      appositive: "同位语",
      parenthesis: "独立成分",
      formalSubject: "形式主语",
      formalObject: "形式宾语",
      cognateObject: "关联宾语",
      vocative: "呼语",
      conjunction: "连词",
      nounPhrase: "名词短语",
      verbPhrase: "动词短语",
      prepositionalPhrase: "介词短语",
      adjectivePhrase: "形容词短语",
      adverbPhrase: "副词短语",
      head: "中心词",
      fragment: "片段",
    }[role] || "";
  }

  function normalizeLabel(label, fallback) {
    const allowed = new Set(["主语","谓语","宾语","表语","直接宾语","间接宾语","宾语补足语","主语补足语","定语","状语","同位语","独立成分","形式主语","形式宾语","关联宾语","呼语","连词","名词短语","动词短语","介词短语","形容词短语","副词短语","中心词","片段"]);
    return allowed.has(label) ? label : (fallback || "");
  }

  function normalizeSpaces(text) {
    return String(text || "").replace(/\s+/g, " ").trim();
  }

  function normalizeTriggerMode(value) {
    return value === TRIGGER_CLICK ? TRIGGER_CLICK : TRIGGER_AUTO;
  }

  function normalizeBoundedInteger(value, fallback, limits) {
    if (value === "" || value == null) return fallback;
    const number = Math.floor(Number(value));
    if (!Number.isFinite(number)) return fallback;
    return Math.min(limits.max, Math.max(limits.min, number));
  }

  function clamp(value, min, max) {
    return Math.min(max, Math.max(min, value));
  }

  function addSafeEventListener(target, type, listener, options) {
    try {
      target?.addEventListener?.(type, listener, options);
    } catch {
      if (options && typeof options === "object") {
        target?.addEventListener?.(type, listener, Boolean(options.capture));
      }
    }
  }

  function delay(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  async function sendMessage(action, payload = {}) {
    const response = await chrome.runtime.sendMessage({ action, ...payload });
    if (!response?.ok) {
      var err = new Error(response?.error?.message || "扩展后台没有返回有效响应。");
      err.code = response?.error?.code || "";
      throw err;
    }
    return response.result;
  }

  function installStyles() {
    if (document.getElementById("egc-page-annotation-style")) return;
    const style = document.createElement("style");
    style.id = "egc-page-annotation-style";
    style.textContent = `
      .${ROOT_CLASS} .${SENTENCE_CLASS} {
        cursor: help;
        text-decoration-line: underline;
        text-decoration-style: dotted;
        text-decoration-color: rgba(92, 201, 176, 0.5);
        text-underline-offset: 0.18em;
      }

      .${ROOT_CLASS} .${SENTENCE_CLASS}:hover {
        background: rgba(23, 107, 92, 0.08);
      }

      .${ROOT_CLASS} .${SENTENCE_CLASS}.egc-loading {
        background: rgba(242, 180, 80, 0.2);
      }

      .${ROOT_CLASS} .${SENTENCE_CLASS}.egc-annotated {
        text-decoration: none;
        overflow-wrap: anywhere;
      }

      .${ROOT_CLASS} .${SENTENCE_CLASS}.egc-annotated > span:not(.${PART_CLASS}) {
        display: inline;
        padding-bottom: 1px;
        margin: 0 1px;
      }


      .${ROOT_CLASS} .${PART_CLASS} {
        position: relative;
        display: inline-block;
        max-width: 100%;
        margin: 0 0.03em calc(0.9em + var(--egc-label-stack-space, 0em));
        padding: 0 0.02em 0.08em;
        border-bottom: 2px solid currentColor;
        line-height: 1.15;
        white-space: normal;
        overflow-wrap: anywhere;
        word-break: normal;
        vertical-align: baseline;
      }

      .${ROOT_CLASS} .${PART_CLASS}.egc-has-nested {
        cursor: pointer;
        padding-bottom: 0.16em;
      }

      .${ROOT_CLASS} .${PART_CLASS}.egc-has-nested:focus-visible {
        outline: 2px solid currentColor;
        outline-offset: 0.12em;
        border-radius: 0.16em;
      }

      .${ROOT_CLASS} .${PART_CLASS}.egc-nested-active {
        background: color-mix(in srgb, currentColor 10%, transparent);
      }

      .${ROOT_CLASS} .${PART_CLASS}.egc-nested-part {
        border-bottom-width: 1px;
      }

      .${ROOT_CLASS} .${PART_CLASS}.egc-nested-collapsed > .egc-nested-part {
        display: none;
      }

      .${ROOT_CLASS} .${PART_LABEL_CLASS} {
        position: absolute;
        left: 50%;
        top: calc(100% + 0.22em);
        transform: translateX(-50%) translateX(var(--egc-label-shift, 0px)) translateY(var(--egc-label-lane-offset, 0em));
        white-space: nowrap;
        max-width: calc(100vw - 12px);
        overflow: hidden;
        text-overflow: ellipsis;
        font-size: 0.68em;
        line-height: 1;
        color: currentColor;
        opacity: 0.9;
        overscroll-behavior: contain;
        pointer-events: auto;
        user-select: none;
      }

      .${ROOT_CLASS} .${PART_CLASS}.egc-has-nested > .${PART_LABEL_CLASS}::after {
        content: " · 展开";
        color: #a0b8c8;
        font-size: 0.86em;
      }

      .${ROOT_CLASS} .${PART_CLASS}.egc-nested-active > .${PART_LABEL_CLASS}::after {
        content: " · 当前";
      }

      .${ROOT_CLASS} .egc-element-subject { color: #5ba0d8; }
      .${ROOT_CLASS} .egc-element-predicate { color: #d4709f; }
      .${ROOT_CLASS} .egc-element-object { color: #5aad5e; }
      .${ROOT_CLASS} .egc-element-complement { color: #a87ee6; }
      .${ROOT_CLASS} .egc-element-adverbial { color: #e08a30; }
      .${ROOT_CLASS} .egc-element-attribute { color: #30a8b8; }
      .${ROOT_CLASS} .egc-element-appositive { color: #ad8a30; }
      .${ROOT_CLASS} .egc-element-conjunction { color: #b8856a; }
      .${ROOT_CLASS} .egc-element-marker { color: #c97a7a; }
      .${ROOT_CLASS} .egc-element-other { color: #6ea8b0; }
      .${ROOT_CLASS} .egc-element-nounphrase { color: #5ba0d8; }
      .${ROOT_CLASS} .egc-element-verbphrase { color: #d4709f; }
      .${ROOT_CLASS} .egc-element-prepositionalphrase { color: #a87ee6; }
      .${ROOT_CLASS} .egc-element-adjectivephrase { color: #e08a30; }
      .${ROOT_CLASS} .egc-element-adverbphrase { color: #30a8b8; }
      .${ROOT_CLASS} .egc-element-head { color: #c97a7a; }
      .${ROOT_CLASS} .egc-element-fragment { color: #6ea8b0; }

      .${ROOT_CLASS} .${TRANSLATION_CLASS} {
        display: none;
        box-sizing: border-box;
        width: auto;
        max-width: min(720px, calc(100vw - 24px));
        margin: 0.25em 0 0.65em;
        padding: 0.45em 0.6em;
        border-left: 3px solid #176b5c;
        border-radius: 6px;
        background: rgba(92, 201, 176, 0.08);
        color: #d4dcee;
        font-size: 0.92em;
        line-height: 1.45;
        white-space: normal;
        overflow: visible;
        overflow-wrap: anywhere;
        word-break: break-word;
      }

      .${ROOT_CLASS} .${TRANSLATION_CLASS}.egc-hidden {
        display: none;
      }

      .${ROOT_CLASS} .${NESTED_PANEL_CLASS} {
        display: block;
        box-sizing: border-box;
        width: auto;
        max-width: min(760px, calc(100vw - 24px));
        margin: 0.35em 0 0.75em;
        padding: 0.62em 0.72em 0.32em;
        border: 1px solid rgba(74, 85, 104, 0.4);
        border-left: 3px solid #9aa4b8;
        border-radius: 7px;
        background: rgba(24, 27, 40, 0.98);
        color: #e8edf5;
        font: 14px/1.55 system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
        white-space: normal;
        overflow: visible;
        overflow-wrap: anywhere;
        word-break: break-word;
      }

      .${ROOT_CLASS} .${NESTED_PANEL_CLASS}.egc-hidden {
        display: none;
      }

      .${ROOT_CLASS} .egc-nested-analysis-head {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 0.7em;
        margin-bottom: 0.35em;
      }

      .${ROOT_CLASS} .egc-nested-analysis-title {
        min-width: 0;
        color: #c8d0e0;
        font-size: 0.88em;
        font-weight: 700;
      }

      .${ROOT_CLASS} .egc-nested-analysis-close {
        all: unset;
        box-sizing: border-box;
        flex: 0 0 auto;
        width: 1.7em;
        height: 1.7em;
        border-radius: 999px;
        color: #9aa4b8;
        cursor: pointer;
        font: 700 1em/1.7 system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
        text-align: center;
      }

      .${ROOT_CLASS} .egc-nested-analysis-close:hover,
      .${ROOT_CLASS} .egc-nested-analysis-close:focus-visible {
        background: rgba(154, 164, 184, 0.14);
        outline: none;
      }

      .${ROOT_CLASS} .egc-nested-analysis-detail {
        display: block;
        color: #9aa4b8;
        font-size: 0.9em;
      }

      .${ROOT_CLASS} .egc-nested-analysis-sentence {
        display: block;
        padding-bottom: calc(0.3em + var(--egc-label-stack-space, 0em));
        color: #d4dcee;
        line-height: 1.7;
      }

      .${ROOT_CLASS} .egc-nested-analysis-detail {
        margin-top: 0.2em;
      }

      .${ROOT_CLASS} .${TRANSLATION_CLASS}.egc-error {
        border-left-color: #f97066;
        background: rgba(249, 112, 102, 0.1);
        color: #f97066;
      }

      .${ROOT_CLASS} .${SENTENCE_CLASS}.egc-collapsed .${TRANSLATION_CLASS} {
        display: none;
      }

      .${TRANSLATION_TOOLTIP_CLASS} {
        position: fixed;
        z-index: 2147483647;
        display: none;
        box-sizing: border-box;
        width: min(820px, calc(100vw - 16px));
        max-height: min(72vh, 720px);
        overflow: auto;
        scrollbar-gutter: stable;
        padding: 0 0.85em 0.75em 0.85em;
        border: 1px solid rgba(148, 163, 184, 0.32);
        border-radius: 8px;
        background: linear-gradient(180deg, rgba(18, 20, 31, 0.56), rgba(24, 27, 40, 0.52));
        box-shadow: 0 18px 46px rgba(0, 0, 0, 0.5), inset 0 1px 0 rgba(255, 255, 255, 0.06);
        backdrop-filter: blur(1.5px) saturate(0.95);
        -webkit-backdrop-filter: blur(1.5px) saturate(0.95);
        will-change: transform;
        color: #ffffff;
        font: 14px/1.55 system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
        white-space: normal;
        overflow-wrap: anywhere;
        pointer-events: auto;
      }

      .${TRANSLATION_TOOLTIP_CLASS}.egc-visible {
        display: block;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-section + .egc-tooltip-section {
        margin-top: 0.65em;
        padding-top: 0.58em;
        border-top: 1px solid rgba(74, 85, 104, 0.35);
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-priority-section {
        padding: 0;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-title {
        margin-bottom: 0.28em;
        color: #5cc9b0;
        font-size: 0.86em;
        font-weight: 700;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-text {
        margin: 0;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-row {
        display: grid;
        grid-template-columns: max-content minmax(0, 1fr);
        gap: 0.45em;
        align-items: baseline;
        padding-left: calc(var(--egc-tooltip-depth, 0) * 1.1em);
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-row + .egc-tooltip-row {
        margin-top: 0.24em;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-row-body {
        display: flex;
        flex-direction: column;
        gap: 0.2em;
        min-width: 0;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-row-text {
        display: inline;
        color: #ffffff;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-row-text .egc-speak-group {
        margin-left: 0.25em;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-row-detail {
        display: flex;
        flex-direction: column;
        gap: 0.15em;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-detail-line {
        color: #ffffff;
        font-size: 0.92em;
        line-height: 1.45;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-detail-label {
        color: #f5a623;
        font-weight: 650;
        margin-right: 0.3em;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-detail-content {
        color: #ffffff;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-subsection {
        margin-top: 0.48em;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-subsection .egc-tooltip-title {
        margin-bottom: 0.22em;
        color: #5cc9b0;
        font-size: 0.82em;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-label {
        max-width: min(18em, 42vw);
        overflow: visible;
        color: #f5a623;
        font-weight: 650;
        overflow-wrap: anywhere;
        text-overflow: clip;
        white-space: normal;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-word-level-badge {
        display: inline-block;
        margin-left: 6px;
        padding: 0 5px;
        border-radius: 3px;
        background: #b8e6dc;
        color: #004d3a;
        font-size: 0.72em;
        font-weight: 650;
        line-height: 1.5;
        vertical-align: middle;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-row-body {
        min-width: 0;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-word-row {
        display: grid;
        grid-template-columns: auto 1fr;
        gap: 0 12px;
        padding: 3px 0;
        align-items: start;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-word-left {
        display: flex;
        flex-direction: column;
        gap: 2px;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-word-row .egc-tooltip-label {
        display: flex;
        flex-direction: column;
        gap: 0.15em;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-word-actions {
        display: flex;
        align-items: center;
        gap: 3px;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-segment-card {
        margin-left: calc(var(--egc-tooltip-depth, 0) * 1em);
        padding: 0.18em 0 0.18em 0.65em;
        border-left: 2px solid rgba(92, 201, 176, 0.3);
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-segment-card + .egc-tooltip-segment-card {
        margin-top: 0.22em;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-segment-head {
        display: grid;
        grid-template-columns: max-content minmax(0, 1fr);
        gap: 0.5em;
        align-items: baseline;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-segment-label {
        color: #f5a623;
        font-size: 0.86em;
        font-weight: 700;
        white-space: nowrap;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-segment-text {
        min-width: 0;
        color: #e8edf5;
        font-weight: 650;
        overflow-wrap: anywhere;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-segment-detail {
        margin-top: 0.2em;
        color: #eceff4;
        font-size: 0.93em;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-list {
        margin: 0;
        padding-left: 1.25em;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-list li + li {
        margin-top: 0.18em;
      }

      .egc-speak-group {
        display: inline-flex;
        align-items: center;
        gap: 0.2em;
        margin-left: 0.35em;
        vertical-align: middle;
      }

      .egc-speak-button {
        all: unset;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-width: 1.65em;
        height: 1.4em;
        padding: 0 0.35em;
        border-radius: 4px;
        border: 1px solid rgba(0, 229, 255, 0.2);
        background: transparent;
        color: rgba(0, 229, 255, 0.7);
        cursor: pointer;
        font-size: 0.65em;
        font-weight: 700;
        line-height: 1;
        letter-spacing: 0.04em;
        transition: background 0.15s, border-color 0.15s, color 0.15s;
      }

      .egc-speak-button:hover,
      .egc-speak-button:focus-visible {
        background: rgba(0, 229, 255, 0.1);
        border-color: rgba(0, 229, 255, 0.4);
        color: #00e5ff;
        outline: none;
      }

      .egc-speak-button:active {
        background: rgba(0, 229, 255, 0.18);
      }

      .egc-speak-button.egc-speaking {
        background: rgba(0, 229, 255, 0.15);
        border-color: rgba(0, 229, 255, 0.5);
        color: #00e5ff;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-chat-btn {
        display: block;
        width: auto;
        min-width: 130px;
        margin: 0 auto;
        padding: 5px 20px;
        font-size: 0.88em;
        font-weight: 600;
        letter-spacing: 0.01em;
        cursor: pointer;
        background: linear-gradient(135deg, #0d2137 0%, #1a3a5c 100%);
        color: #00e5ff;
        border: 1px solid rgba(0, 229, 255, 0.25);
        border-radius: 8px;
        text-align: center;
        transition: opacity 0.15s, background 0.15s, border-color 0.15s;
      }
      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-chat-btn:hover {
        background: linear-gradient(135deg, #0f2d4f 0%, #1f4a74 100%);
        border-color: rgba(0, 229, 255, 0.5);
      }
      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-chat-btn:active {
        background: linear-gradient(135deg, #081a2d 0%, #122c47 100%);
      }
      .egc-quota-banner {
        all: initial;
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        z-index: 2147483647;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 12px;
        padding: 12px 20px;
        background: #fffbeb;
        border-bottom: 1px solid #fde68a;
        box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        font: 14px/1.5 system-ui, -apple-system, sans-serif;
        color: #92400e;
      }
      .egc-quota-banner span {
        all: initial;
        font-family: system-ui, -apple-system, sans-serif;
        font-size: 14px;
        color: #92400e;
      }
      .egc-quota-banner a {
        all: initial;
        cursor: pointer;
        font-family: system-ui, -apple-system, sans-serif;
        font-size: 14px;
        font-weight: 600;
        color: #2563eb;
        text-decoration: underline;
      }
      .egc-quota-banner a:hover {
        color: #1d4ed8;
      }
      .egc-quota-banner .egc-quota-close {
        all: initial;
        cursor: pointer;
        font-family: system-ui, -apple-system, sans-serif;
        font-size: 18px;
        color: #92400e;
        opacity: 0.6;
        margin-left: 8px;
      }
      .egc-quota-banner .egc-quota-close:hover {
        opacity: 1;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-chat-btn:disabled {
        opacity: 0.5;
        cursor: default;
      }

      /* ── 浮窗主题控制 ──────────────────────── */

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-chat-row {
        position: relative;
        margin-bottom: 6px;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-header-btn {
        all: unset;
        position: absolute;
        right: 0;
        top: 50%;
        transform: translateY(-50%);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 30px;
        height: 30px;
        border-radius: 6px;
        background: rgba(255, 255, 255, 0.1);
        color: #ffffff;
        font-size: 15px;
        line-height: 1;
        cursor: pointer;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-theme-panel {
        display: none;
        padding: 8px 10px;
        margin-bottom: 6px;
        border-radius: 6px;
        background: rgba(0, 0, 0, 0.2);
      }
      .${TRANSLATION_TOOLTIP_CLASS} .egc-theme-panel.egc-open {
        display: block;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-theme-label {
        display: block;
        color: rgba(255, 255, 255, 0.55);
        font-size: 0.7em;
        margin-bottom: 4px;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-theme-presets {
        display: flex;
        gap: 6px;
        margin-bottom: 8px;
        align-items: center;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-theme-preset {
        width: 24px;
        height: 24px;
        border-radius: 50%;
        border: 2px solid transparent;
        cursor: pointer;
        transition: border-color 0.15s, transform 0.15s;
        box-sizing: border-box;
      }
      .${TRANSLATION_TOOLTIP_CLASS} .egc-theme-preset:hover {
        transform: scale(1.18);
      }
      .${TRANSLATION_TOOLTIP_CLASS} .egc-theme-preset.egc-active {
        border-color: #ffffff;
        transform: scale(1.12);
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-theme-row {
        display: flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 5px;
      }
      .${TRANSLATION_TOOLTIP_CLASS} .egc-theme-row:last-child {
        margin-bottom: 0;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-theme-row label {
        color: rgba(255, 255, 255, 0.6);
        font-size: 0.72em;
        min-width: 3em;
        flex-shrink: 0;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-theme-row input[type="range"] {
        -webkit-appearance: none;
        appearance: none;
        flex: 1;
        height: 4px;
        border-radius: 2px;
        background: rgba(255, 255, 255, 0.2);
        outline: none;
        cursor: pointer;
        min-width: 0;
      }
      .${TRANSLATION_TOOLTIP_CLASS} .egc-theme-row input[type="range"]::-webkit-slider-thumb {
        -webkit-appearance: none;
        appearance: none;
        width: 13px;
        height: 13px;
        border-radius: 50%;
        background: #ffffff;
        border: 0;
        cursor: pointer;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-theme-row .egc-theme-value {
        color: rgba(255, 255, 255, 0.55);
        font-size: 0.68em;
        min-width: 2.8em;
        text-align: right;
        font-variant-numeric: tabular-nums;
      }
`;
    document.documentElement.appendChild(style);
  }

  function showQuotaBanner(msg) {
    if (document.querySelector(".egc-quota-banner")) return;
    var banner = document.createElement("div");
    banner.className = "egc-quota-banner";
    banner.innerHTML =
      '<span>' + (msg || '免费额度已用完') + '</span>' +
      '<a href="https://giiiiiithub.github.io/BeyondTranslationSite" target="_blank" rel="noopener noreferrer">获取 Token →</a>' +
      '<span class="egc-quota-close">&times;</span>';
    banner.querySelector(".egc-quota-close").addEventListener("click", function () {
      banner.remove();
    });
    document.documentElement.appendChild(banner);
  }
})();
