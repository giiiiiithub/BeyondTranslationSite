﻿(function () {
  console.log("[BT] page-annotation-content loaded");
  const SCRIPT_VERSION = "2026-06-05-global-fallback-v43";
  if (window.__englishGrammarPageAnnotationVersion === SCRIPT_VERSION) return;
  window.__englishGrammarPageAnnotationVersion = SCRIPT_VERSION;

  const ROOT_CLASS = "egc-page-annotation";
  const SENTENCE_CLASS = "egc-sentence";
  const PART_CLASS = "egc-part";
  const PART_LABEL_CLASS = "egc-part-label";
  const TRANSLATION_CLASS = "egc-translation";
  const NESTED_PANEL_CLASS = "egc-nested-analysis";
  const TRANSLATION_TOOLTIP_CLASS = "egc-translation-tooltip";
  const HIDE_UL_CLASS = "egc-hide-underline";
  const MAX_SENTENCES_PER_SCAN = 180;
  const MIN_SENTENCE_LENGTH = 5;
  const TRIGGER_CLICK = "click";
  const TRIGGER_AUTO = "auto";
  const TOOLTIP_OFFSET_PX = 12;
  const TOOLTIP_VIEWPORT_MARGIN_PX = 28;

  let enabled = false;
  let triggerMode = TRIGGER_AUTO;
  let scanning = false;
  let scanTimer = 0;
  let observer = null;
  let sentenceCount = 0;
  let wordLevels = null;
  let translationOnly = false;
  let showTone = true;
  let showSegmentation = true;
  let translationIdCounter = 0;
  let translationTooltip = null;
  let translationTooltipSentence = null;
  let tooltipHideTimer = 0;
  let tooltipTheme = null;
  let speechActive = false;

  // Store sentence analysis in a Map instead of wrapping text in spans.
  // Key = TextNode, values = SentenceEntry[]
  // SentenceEntry: { text, start, end, analysis, loading }
  const textNodeSentences = new Map();
  const elementSentenceEntries = new Map();

  // Text-content-based fallback — matches sentence by text from caretRangeFromPoint.
  // Handles cases where all DOM references (text nodes, parent elements, attributes)
  // have been invalidated by framework re-renders (React, web components, etc.).
  const textToAnalysis = new Map();
  const textToPending = new Set();   // texts currently in-flight to background
  const textToFailed = new Set();    // texts that failed (quota, etc.) — no retry
  let noDomBatchSize = 5;            // from settings, default 5
  let batchFlushTimer = 0;          // timer handle for batch flush

  installStyles();
  addSafeEventListener(document, "click", handleSentenceClick, true);
  addSafeEventListener(document, "mouseup", handleSentenceMouseUp, true);
  addSafeEventListener(document, "click", handleDocumentClick, false);
  addSafeEventListener(document, "pointerover", handleTranslationTooltipPointerOver, true);
  addSafeEventListener(document, "pointerout", handleTranslationTooltipPointerOut, true);
  addSafeEventListener(document, "pointermove", handleTranslationTooltipPointerMove, true);
  addSafeEventListener(document, "wheel", handleTranslationTooltipWheel, { capture: true, passive: false });
  addSafeEventListener(window, "scroll", handleViewportScroll, true);
  addSafeEventListener(window, "resize", handleViewportResize, { passive: true });
  addSafeEventListener(document, "visibilitychange", () => {
    if (!document.hidden && noDomPending.length) {
      clearTimeout(batchFlushTimer);
      batchFlushTimer = 0;
      noDomFlushBatches();
    }
  });
  globalThis.chrome?.runtime?.onMessage?.addListener?.(handleRuntimeMessage);
  init().catch(() => {});

  async function init() {
    console.log("[BT] init() called");
    warmUpSpeech();
    await loadTooltipTheme();
    const settings = await sendMessage("getSettingsSummary").catch(() => null);
    console.log("[BT] init() got settings:", settings ? "OK" : "NULL");
    applySettings(settings || {});
  }

  function warmUpSpeech() {
    if (typeof speechSynthesis === "undefined") return;
    const utterance = new SpeechSynthesisUtterance("");
    utterance.volume = 0;
    utterance.rate = 2;
    speechSynthesis.speak(utterance);
  }

  function handleRuntimeMessage(message) {
    if (message?.type !== "pageAnnotationSettingsChanged") return;
    init().catch(() => {});
  }

  function applySettings(settings) {
    console.log("[BT] applySettings enabled=" + settings.pageAnnotationEnabledForSite);
    triggerMode = normalizeTriggerMode(settings.pageAnnotationTrigger);
    wordLevels = Array.isArray(settings.pageAnnotationWordLevels) ? settings.pageAnnotationWordLevels : null;
    translationOnly = settings.pageAnnotationTranslationOnly !== false;
    showTone = settings.pageAnnotationTone !== false;
    showSegmentation = settings.pageAnnotationSegmentation !== false;
    noDomBatchSize = settings.pageAnnotationBatchSize || 5;
    setEnabled(settings.pageAnnotationEnabledForSite === true);
    // 设置变更（如额度恢复）时清除失败缓存，允许重试
    textToFailed.clear();
    if (enabled && triggerMode !== TRIGGER_AUTO) {
      noDomPending.length = 0;
      textToPending.clear();
    }
  }

  function setEnabled(value) {
    const next = Boolean(value);
    if (enabled === next) return;
    enabled = next;
    document.documentElement.classList.toggle(ROOT_CLASS, enabled);

    if (enabled) {
      scheduleScan(50);
      startObserver();
    } else {
      hideTranslationTooltip();
      stopObserver();
      unwrapAnnotations();
    }
  }

  function startObserver() {
    if (observer || !document.body) return;
    observer = new MutationObserver(() => scheduleScan(600));
    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }

  function stopObserver() {
    if (!observer) return;
    observer.disconnect();
    observer = null;
  }

  function handleViewportResize() {
      hideTranslationTooltip();
  }

  // Force re-scan after scrolling stops — catches content loaded by
  // infinite-scroll / virtual scrollers (Reddit, Twitter, etc.).
  let scrollScanTimer = 0;
  var _lastPointerX = 0;
  var _lastPointerY = 0;
  function handleViewportScroll() {
    // If pointer is still over the tooltip's bounding area (site overlays
    // like zephr-anchor can intercept wheel events causing page scroll),
    // don't hide — the user is still interacting with the tooltip.
    if (translationTooltip?.classList.contains("egc-visible")) {
      var rect = translationTooltip.getBoundingClientRect();
      if (_lastPointerX >= rect.left && _lastPointerX <= rect.right &&
          _lastPointerY >= rect.top && _lastPointerY <= rect.bottom) {
        return;
      }
    }
    console.log("[BT] viewportScroll hide");
    hideTranslationTooltip();
    clearTimeout(scrollScanTimer);
    scrollScanTimer = setTimeout(() => {
      if (enabled) scheduleScan(100);
    }, 250);
  }

  let _lastScanWallTime = 0;

  function scheduleScan(delayMs) {
    if (!enabled) return;
    clearTimeout(scanTimer);
    scanTimer = setTimeout(() => {
      scanTimer = 0;
      scanPage();
    }, delayMs);
    // Max-wait: if mutations keep deferring the scan (e.g. Reddit virtual
    // scroller fires continuous DOM changes), force-run after 3 s.
    if (_lastScanWallTime && Date.now() - _lastScanWallTime > 3000) {
      clearTimeout(scanTimer);
      scanTimer = 0;
      scanPage();
    }
  }

  function scanPage() {
    if (!enabled || scanning || !document.body) return;
    scanning = true;
    sentenceCount = 0;
    _lastScanWallTime = Date.now();

    var accepted = 0;
    var rejected = 0;
    try {
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
        acceptNode: (node) => {
          if (sentenceCount >= MAX_SENTENCES_PER_SCAN) { rejected++; return NodeFilter.FILTER_REJECT; }
          if (!isProcessableText(node.nodeValue || "")) { rejected++; return NodeFilter.FILTER_REJECT; }
          if (!isProcessableParent(node.parentElement)) { rejected++; return NodeFilter.FILTER_REJECT; }
          accepted++;
          return NodeFilter.FILTER_ACCEPT;
        }
      });

      const nodes = [];
      while (walker.nextNode() && sentenceCount < MAX_SENTENCES_PER_SCAN) {
        nodes.push(walker.currentNode);
      }
      console.log("[BT] scanPage: accepted=" + accepted + " rejected=" + rejected + " nodes=" + nodes.length + " bodyChildren=" + document.body.children.length);
      // Group adjacent text nodes by block parent so sentences spanning
      // multiple DOM text nodes (e.g. <p>text <em>word</em>, more text</p>)
      // are split correctly rather than treated as separate fragments.
      var groups = groupTextNodesByBlock(nodes);
      for (var gi = 0; gi < groups.length; gi++) {
        processTextNodeGroup(groups[gi]);
      }
    } finally {
      scanning = false;
    }
  }

  function annotateTextNode(node) {
    if (!node.parentNode || !isProcessableParent(node.parentElement)) return;
    recordTextNodeSentences(node);
  }

  function recordTextNodeSentences(node) {
    const text = node.nodeValue || "";
    // If text node was previously analyzed with different content (e.g. after
    // DOM recycling by a virtual scroller), clear old entries and re-analyze.
    if (textNodeSentences.has(node)) {
      var prev = textNodeSentences.get(node);
      if (prev._sourceText === text) return;
      // Text changed — unlink node-level tracking but keep text-level analysis
      // cache so the same sentence on another node doesn't re-trigger API calls.
      textNodeSentences.delete(node);
    }
    // Consistent with scanPage: skip text inside interactive/form elements.
    // The scan path already filters these out; on-demand analysis must too,
    // otherwise clicking a button would trigger ad-hoc analysis and intercept
    // the button's native behavior via handleSentenceClick.
    if (!isProcessableParent(node.parentElement)) return;

    // Text node must have at least 4 English words to be worth analyzing.
    // Below that threshold, skip entirely — the whole text node is too short.
    if (countEnglishWords(text) < 4) return;

    const pieces = splitIntoSentencePieces(text);
    if (!pieces.some(p => p.isSentence)) return;

    let cursor = 0;
    const entries = [];
    for (const piece of pieces) {
      if (!piece.text) continue;
      if (!piece.isSentence || sentenceCount >= MAX_SENTENCES_PER_SCAN) {
        cursor += piece.text.length;
        continue;
      }

      const idx = text.indexOf(piece.text, cursor);
      if (idx < 0) {
        cursor += piece.text.length;
        continue;
      }

      entries.push({
        text: piece.text,
        start: idx,
        end: idx + piece.text.length,
        node,
        parentNode: node.parentElement,
        analysis: null,
        loading: false
      });
      sentenceCount += 1;
      cursor = idx + piece.text.length;
    }

    if (!entries.length) return;
    const existing = textNodeSentences.get(node) || [];
    const merged = [...existing, ...entries];
    merged._sourceText = text;
    textNodeSentences.set(node, merged);

    // Index by parent element for robustness against DOM text node replacement
    for (const entry of entries) {
      if (entry.parentNode) {
        var elEntries = elementSentenceEntries.get(entry.parentNode);
        if (!elEntries) {
          elEntries = [];
          elementSentenceEntries.set(entry.parentNode, elEntries);
        }
        elEntries.push(entry);
      }
    }

    for (const entry of entries) {
      noDomEnqueue(entry);
    }
  }

  // Group consecutive text nodes by their block-level parent so that
  // sentences spanning multiple DOM text nodes are split correctly.
  function groupTextNodesByBlock(nodes) {
    var groups = [];
    var current = [];
    var currentBlock = null;
    for (var i = 0; i < nodes.length; i++) {
      var block = getBlockAncestor(nodes[i]);
      if (block !== currentBlock && current.length) {
        groups.push(current);
        current = [];
      }
      currentBlock = block;
      current.push(nodes[i]);
    }
    if (current.length) groups.push(current);
    return groups;
  }

  function getBlockAncestor(node) {
    var el = node.parentElement;
    while (el) {
      if (el === document.body) return el;
      var tag = el.tagName;
      if (tag === "P" || tag === "DIV" || tag === "SECTION" || tag === "ARTICLE" ||
          tag === "LI" || tag === "BLOCKQUOTE" || tag === "TD" || tag === "TH" ||
          tag === "H1" || tag === "H2" || tag === "H3" || tag === "H4" || tag === "H5" || tag === "H6") {
        return el;
      }
      var disp = window.getComputedStyle(el).display;
      if (disp !== "inline" && !disp.startsWith("inline-")) return el;
      el = el.parentElement;
    }
    return document.body;
  }

  // Process a group of text nodes sharing the same block parent.
  // Concatenates their text, splits into sentences, and creates entries
  // mapped to each contributing text node with correct offsets.
  function processTextNodeGroup(group) {
    if (!group.length) return;

    // Build cumulative offset map for text nodes in the group
    var totalLen = 0;
    var nodeOffsets = [];
    for (var i = 0; i < group.length; i++) {
      var len = (group[i].nodeValue || "").length;
      if (!len) continue;
      nodeOffsets.push({ node: group[i], start: totalLen, end: totalLen + len });
      totalLen += len;
    }
    if (!nodeOffsets.length) return;

    var fullText = nodeOffsets.map(function (o) { return o.node.nodeValue || ""; }).join("");
    if (countEnglishWords(fullText) < 4) return;

    var pieces = splitIntoSentencePieces(fullText);
    if (!pieces.some(function (p) { return p.isSentence; })) return;

    var cursor = 0;
    for (var pi = 0; pi < pieces.length; pi++) {
      var piece = pieces[pi];
      if (!piece.text) continue;
      if (!piece.isSentence || sentenceCount >= MAX_SENTENCES_PER_SCAN) {
        cursor += piece.text.length;
        continue;
      }

      var idx = fullText.indexOf(piece.text, cursor);
      if (idx < 0) {
        cursor += piece.text.length;
        continue;
      }
      var pieceEnd = idx + piece.text.length;

      // Create entries for every text node that overlaps this sentence
      for (var ni = 0; ni < nodeOffsets.length; ni++) {
        var no = nodeOffsets[ni];
        if (no.start >= pieceEnd) break;
        if (no.end <= idx) continue;

        var overlapStart = Math.max(idx, no.start);
        var overlapEnd = Math.min(pieceEnd, no.end);
        var relStart = overlapStart - no.start;
        var relEnd = overlapEnd - no.start;

        var entry = {
          text: piece.text,
          start: relStart,
          end: relEnd,
          node: no.node,
          parentNode: no.node.parentElement,
          analysis: null,
          loading: false
        };
        storeSentenceEntry(entry);
      }
      sentenceCount += 1;
      cursor = idx + piece.text.length;
    }
  }

  // Store a sentence entry in indexes and enqueue for analysis.
  function storeSentenceEntry(entry) {
    // Index by text node for click targeting
    var existing = textNodeSentences.get(entry.node) || [];
    existing.push(entry);
    existing._sourceText = entry.node.nodeValue || "";
    textNodeSentences.set(entry.node, existing);

    // Index by parent element as fallback
    if (entry.parentNode) {
      var elEntries = elementSentenceEntries.get(entry.parentNode);
      if (!elEntries) {
        elEntries = [];
        elementSentenceEntries.set(entry.parentNode, elEntries);
      }
      elEntries.push(entry);
    }

    noDomEnqueue(entry);
  }

  // ── No-DOM analysis path (batch) ──────────────────
  const noDomPending = [];
  const BATCH_FLUSH_DELAY = 60;      // ms to collect entries before dispatching
  const BATCH_GROUP_SIZE = 5;         // send this many chunks concurrently before waiting

  // Track ALL entries sharing the same sentence text so that when the API
  // returns, every text node for that sentence gets the result, not just the
  // first one that was enqueued.
  var textToEntries = new Map();

  function noDomEnqueue(entry) {
    if (!entry.text) return;
    // Index every entry by text so later propagation reaches all text nodes
    var shared = textToEntries.get(entry.text);
    if (!shared) { shared = []; textToEntries.set(entry.text, shared); }
    shared.push(entry);

    if (entry.analysis) return;
    if (textToAnalysis.has(entry.text)) {
      entry.analysis = textToAnalysis.get(entry.text);
      return;
    }
    if (entry.loading) return;
    if (textToPending.has(entry.text)) return;
    if (textToFailed.has(entry.text)) return;
    textToPending.add(entry.text);
    entry.loading = true;
    noDomPending.push(entry);
    scheduleBatchFlush();
  }

  function scheduleBatchFlush() {
    if (batchFlushTimer) return;
    batchFlushTimer = setTimeout(noDomFlushBatches, BATCH_FLUSH_DELAY);
  }

  let noDomProcessing = false;

  function noDomFlushBatches() {
    batchFlushTimer = 0;
    if (document.hidden) return;
    if (noDomProcessing || !noDomPending.length) return;

    // Collect up to BATCH_GROUP_SIZE chunks as one group
    const group = [];
    for (let i = 0; i < BATCH_GROUP_SIZE && noDomPending.length; i++) {
      const batch = noDomPending.splice(0, noDomBatchSize);
      if (!batch.length) break;
      group.push(batch);
    }
    if (!group.length) return;

    noDomProcessing = true;
    Promise.all(group.map(batch => noDomAnalyzeBatch(batch)))
      .finally(() => {
        noDomProcessing = false;
        if (noDomPending.length) noDomFlushBatches();
      });
  }

  async function noDomAnalyzeBatch(entries) {
    const texts = entries.map(e => e.text);
    try {
      const results = await sendMessage("annotateSentences", { sentences: texts });
      if (!Array.isArray(results)) return;
      for (let i = 0; i < entries.length; i++) {
        const entry = entries[i];
        const result = results[i];
        if (!result) { entry.loading = false; continue; }
        const card = buildLearningCardData(entry.text, result);
        propagateAnalysisToText(entry.text, card);
        textToPending.delete(entry.text);
      }
    } catch (error) {
      // Don't retry failed texts on subsequent scans (quota exhaustion, etc.),
      // but still reset their loading state so the UI isn't stuck waiting.
      for (const entry of entries) {
        propagateAnalysisToText(entry.text, null, { loading: false });
        textToFailed.add(entry.text);
        textToPending.delete(entry.text);
      }
    }
  }

  function propagateAnalysisToText(text, card, extra) {
    if (!text) return;
    if (card) textToAnalysis.set(text, card);
    var allEntries = textToEntries.get(text);
    if (!allEntries) return;
    for (var ei = 0; ei < allEntries.length; ei++) {
      var e = allEntries[ei];
      if (card) e.analysis = card;
      if (extra) Object.assign(e, extra);
      e.loading = false;
    }
  }

  // Detect transparent overlay elements (e.g. Reddit's absolute-positioned <a>)
  // that intercept pointer events but have no visible content of their own.
  function isOverlayBlocker(el) {
    if (el.nodeType !== 1) return false;
    const tag = el.tagName?.toLowerCase();
    if (tag === 'body' || tag === 'html') return false;
    const style = window.getComputedStyle(el);
    if (style.position !== 'absolute' && style.position !== 'fixed') return false;
    const hasDirectText = Array.from(el.childNodes).some(
      n => n.nodeType === 3 && n.nodeValue?.trim().length > 0
    );
    if (hasDirectText) return false;
    if (tag === 'a') return true;
    const rect = el.getBoundingClientRect();
    return rect.width > 50 && rect.height > 50;
  }

    function findAnalysisData(event) {
    const x = event.clientX, y = event.clientY;
    // Temporarily disable transparent overlays so caretRangeFromPoint
    // reaches the actual text node behind them.
    const disabledEls = [];
    try {
      if (typeof document.elementFromPoint === "function") {
        for (let attempt = 0; attempt < 10; attempt++) {
          const topEl = document.elementFromPoint(x, y);
          if (!topEl || topEl === document.documentElement || topEl === document.body || topEl === document) break;
          if (!isOverlayBlocker(topEl)) break;
          topEl.style.pointerEvents = 'none';
          disabledEls.push(topEl);
        }
      }

      if (document.caretRangeFromPoint) {
        const range = document.caretRangeFromPoint(x, y);
        if (!range) { console.log("[BT] findAnalysisData: null range"); return null; }
        let node = range.startContainer;
        console.log("[BT] findAnalysisData: range.nodeType=" + node.nodeType + " tag=" + (node.tagName||"#text") + " off=" + range.startOffset);

        // When caretRangeFromPoint returns an element (e.g. Reddit overlay <a>),
        // try elementsFromPoint to find the text node behind it, then use
        // offset-based matching (the most precise method).
        if (node.nodeType !== 3 && typeof document.elementsFromPoint === "function") {
          var tnResult = findTextNodeInElementsFromPoint(event);
          if (tnResult) {
            if (!textNodeSentences.has(tnResult.node)) { recordTextNodeSentences(tnResult.node); }
            var entries = textNodeSentences.get(tnResult.node);
            if (entries) {
              for (var ei = 0; ei < entries.length; ei++) {
                var entry = entries[ei];
                if (tnResult.offset >= entry.start && tnResult.offset <= entry.end) {
                  if (entry.analysis) {
                    return { node: entry.parentNode, data: entry.analysis, entry };
                  }
                  return { node: entry.parentNode, data: null, entry, pending: true };
                }
              }
            }
          }
          // No text node found behind overlay — let fallbacks handle it
          return null;
        }

        while (node && node !== document) {
          if (node.nodeType === 3) {
            if (!textNodeSentences.has(node)) { recordTextNodeSentences(node); }
            const entries = textNodeSentences.get(node);
            if (entries) {
              const offset = range.startOffset;
              for (const entry of entries) {
                if (offset >= entry.start && offset <= entry.end) {
                  if (entry.analysis) {
                    return { node: entry.parentNode, data: entry.analysis, entry };
                  }
                  return { node: entry.parentNode, data: null, entry, pending: true };
                }
              }
            }
          }
          if (node.nodeType === 11) {
            node = node.host;
            continue;
          }
          node = node.parentNode;
        }
      }
      return null;
    } finally {
      for (const el of disabledEls) el.style.pointerEvents = '';
    }
  }
  // Final fallback: match by sentence text from caretRangeFromPoint.
  // Works when all DOM references (text nodes, parent elements, data attributes)
  // have been invalidated by framework re-renders. Uses the text content at the
  // click position to look up the analysis data.
  function findAnalysisDataByText(event) {
    if (!document.caretRangeFromPoint || !textToAnalysis.size) return null;
    const range = document.caretRangeFromPoint(event.clientX, event.clientY);
    if (!range) {
      // caretRangeFromPoint returned null — try elementsFromPoint
      return findAnalysisByElementsFromPoint(event);
    }
    let clickNode = range.startContainer;

    // If caretRangeFromPoint returns an element (e.g. Reddit's transparent overlay <a>),
    // try elementsFromPoint to find the actual text behind it.
    if (clickNode.nodeType !== 3) {
      const textInfo = findAnalysisByElementsFromPoint(event);
      if (textInfo) return textInfo;

      // Last resort: walk the element subtree for text content
      const clickText = (clickNode.textContent || "").trim();
      if (clickText) {
        // Sort by length descending so longer (more specific) matches win
        // when one sentence is a substring of another.
        const _sortedEl = [...textToAnalysis.entries()].sort((a, b) => b[0].length - a[0].length);
        for (const [sentenceText, card] of _sortedEl) {
          if (clickText.includes(sentenceText)) {
            console.log("[BT] findAnalysisDataByText: textContent match for '" + sentenceText.slice(0, 40) + "'");
            return { node: clickNode, data: card, entry: null };
          }
        }
      }
      return null;
    }

    const clickText = clickNode.nodeValue || "";
    if (!clickText) return null;
    const offset = range.startOffset;

    const _sortedTn = [...textToAnalysis.entries()].sort((a, b) => b[0].length - a[0].length);
    for (const [sentenceText, card] of _sortedTn) {
      const idx = clickText.indexOf(sentenceText);
      if (idx >= 0 && offset >= idx && offset <= idx + sentenceText.length) {
        return { node: clickNode.parentElement, data: card, entry: null };
      }
    }
    return null;
  }

  // Use elementsFromPoint to find text behind transparent overlays
  // (e.g. Reddit's <a class="absolute inset-0">).
  function findAnalysisByElementsFromPoint(event) {
    if (typeof document.elementsFromPoint !== "function" || !textToAnalysis.size) return null;
    const allAt = document.elementsFromPoint(event.clientX, event.clientY);
    console.log("[BT] findAnalysisByElementsFromPoint: " + allAt.length + " elements");
    // Build sorted array once (longest first — more specific matches win)
    const _sortedAll = [...textToAnalysis.entries()].sort((a, b) => b[0].length - a[0].length);
    for (let ei = 0; ei < allAt.length; ei++) {
      const el = allAt[ei];
      // Skip the overlay itself and the document/body/html
      if (el === document.documentElement || el === document.body || el === document) continue;

      const elText = (el.textContent || "").trim();
      if (!elText) continue;

      // First: try text node walker for precise per-node matching
      // (element-level matching against elText is unreliable when the element
      // contains multiple sentences — a longer sentence in a different part of
      // the element would match before the shorter one the user actually clicked.)
      try {
        const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
        while (walker.nextNode()) {
          const tnText = (walker.currentNode.nodeValue || "").trim();
          if (!tnText) continue;
          for (const [sentenceText, card] of _sortedAll) {
            if (tnText.includes(sentenceText)) {
              console.log("[BT] findAnalysisByElementsFromPoint: textNode match '" + sentenceText.slice(0, 40) + "'");
              return { node: walker.currentNode.parentElement, data: card, entry: null };
            }
          }
        }
      } catch (_) {}

      // Fallback: element-level text matching
      for (const [sentenceText, card] of _sortedAll) {
        if (elText.includes(sentenceText)) {
          console.log("[BT] findAnalysisByElementsFromPoint: element fallback '" + sentenceText.slice(0, 40) + "' in " + el.tagName);
          return { node: el, data: card, entry: null };
        }
      }
    }
    return null;
  }

  function extractInlinePrefixFromNode(node) {
    if (node.nodeType === Node.TEXT_NODE) {
      const value = (node.nodeValue || "").trim();
      if (!value || value.length > 15) return null;
      if (!isSentenceSuffixText(value)) return { element: node, elText: value };
      return null;
    }
    if (node.nodeType !== Node.ELEMENT_NODE) return null;

    const el = node;
    if (el.matches?.("img,video,audio,canvas,iframe,svg,script,style,input,textarea,select,button")) return null;
    if (el.closest?.(`.${SENTENCE_CLASS}, .${TRANSLATION_CLASS}, .${PART_CLASS}`)) return null;

    const style = window.getComputedStyle(el);
    if (style.display === "none" || style.visibility === "hidden") return null;

    // Reject if the element itself or its children contain interactive UI controls
    // (buttons, inputs, etc.) — these are page chrome, not sentence prefixes.
    if (el.matches?.("button, [role='button'], input, select, textarea") ||
        el.querySelector?.("button, input, select, textarea, [role='button'], [contenteditable]")) return null;

    // Strategy: find the best inline content to collect

    // 1. If this IS an <a>, use its text directly
    if (el.tagName === "A") {
      const text = (el.textContent || "").trim();
      if (text && text.length <= 30) return { element: el, elText: text };
      return null;
    }

    // 2. If element contains an <a>, use that instead of the wrapper
    const anchor = el.querySelector("a");
    if (anchor) {
      const text = (anchor.textContent || "").trim();
      if (text && text.length <= 30) return { element: anchor, elText: text };
      return null; // <a> too long — don't collect the wrapper either
    }

    // 3. For inline/span elements with short text, use directly
    if (style.display.startsWith("inline") || el.tagName === "SPAN") {
      const text = (el.textContent || "").trim();
      if (text && text.length <= 30) return { element: el, elText: text };
      return null;
    }

    // 4. For flex/grid containers, try first child
    if (style.display === "flex" || style.display === "grid") {
      if (el.children.length > 0) return extractInlinePrefixFromNode(el.children[0]);
      const text = (el.textContent || "").trim();
      if (text && text.length <= 30) return { element: el, elText: text };
      return null;
    }

    // 5. Fallback: any element whose text looks like a mention/hashtag/short label
    const text = (el.textContent || "").trim();
    if (text && text.length <= 20 && /^[@#\w][\w'-]*$/.test(text)) {
      return { element: el, elText: text };
    }

    return null;
  }

  function isContentBoundary(el) {
    if (el.nodeType !== Node.ELEMENT_NODE) return false;
    if (el.closest?.(`.${SENTENCE_CLASS}, .${TRANSLATION_CLASS}, .${PART_CLASS}`)) return true;
    // Contains interactive/non-text elements: structural boundary
    if (el.querySelector("img, video, audio, canvas, iframe, button, input, select, textarea, [role='button'], [contenteditable]")) return true;
    const elStyle = window.getComputedStyle(el);
    const disp = elStyle.display;
    // Inline elements are always part of the text flow
    if (disp === "inline" || disp.startsWith("inline-")) return false;
    // Block-level element with short text might be a prefix container
    const text = (el.textContent || "").trim();
    if (text.length <= 30) return false;
    // Contains block-level children with substantial text: composite section
    for (const child of el.children) {
      const childStyle = window.getComputedStyle(child);
      if (childStyle.display === "block" || childStyle.display === "flex" || childStyle.display === "grid") {
        if ((child.textContent || "").trim().length > 15) return true;
      }
    }
    return false;
  }

  function splitIntoSentencePieces(text) {
    const pieces = [];
    const segmenter = createSentenceSegmenter();

    if (segmenter) {
      let cursor = 0;
      for (const item of segmenter.segment(text)) {
        if (item.index > cursor) {
          pieces.push({ text: text.slice(cursor, item.index), isSentence: false });
        }
        pieces.push({
          text: item.segment,
          isSentence: isCandidateSentence(item.segment)
        });
        cursor = item.index + item.segment.length;
      }
      if (cursor < text.length) {
        pieces.push({ text: text.slice(cursor), isSentence: false });
      }
      return pieces;
    }

    const pattern = /[^.!?。！？]+[.!?]+(?:["')\]]+)?\s*|[^.!?。！？]+$/g;
    let cursor = 0;
    let match;
    while ((match = pattern.exec(text))) {
      if (match.index > cursor) {
        pieces.push({ text: text.slice(cursor, match.index), isSentence: false });
      }
      pieces.push({
        text: match[0],
        isSentence: isCandidateSentence(match[0])
      });
      cursor = match.index + match[0].length;
    }
    if (cursor < text.length) {
      pieces.push({ text: text.slice(cursor), isSentence: false });
    }
    return pieces;
  }

  function createSentenceSegmenter() {
    try {
      if (typeof Intl?.Segmenter !== "function") return null;
      return new Intl.Segmenter("en", { granularity: "sentence" });
    } catch {
      return null;
    }
  }

  function isProcessableText(text) {
    return /[A-Za-z]/.test(text);
  }

  function isCandidateSentence(text) {
    const normalized = normalizeSpaces(text);
    if (normalized.length < MIN_SENTENCE_LENGTH) return false;
    return countEnglishWords(normalized) >= 1;
  }

  function countEnglishWords(text) {
    return (String(text || "").match(/[@#]?[A-Za-z][A-Za-z'-]*/g) || []).length;
  }

  function isProcessableParent(element) {
    if (!element) return false;
    if (element.closest(`.${SENTENCE_CLASS}, .${TRANSLATION_CLASS}, .${PART_CLASS}, .${NESTED_PANEL_CLASS}, .${TRANSLATION_TOOLTIP_CLASS}`)) return false;
    if (
      element.closest(
        "script, style, noscript, template, svg, canvas, math, pre, code, kbd, samp, textarea, input, select, option, button, [contenteditable]:not([contenteditable='false']), [role='button'], [aria-hidden='true']"
      )
    ) {
      return false;
    }

    const style = window.getComputedStyle(element);
    if (style.display === "none" || style.visibility === "hidden") return false;
    return true;
  }

  function sentenceContainsPoint(sentenceNode, event) {
    if (!sentenceNode?.isConnected) return false;
    const target = event.target;
    if (target && (target === sentenceNode || sentenceNode.contains(target))) return true;
    if (document.caretRangeFromPoint) {
      const range = document.caretRangeFromPoint(event.clientX, event.clientY);
      if (!range) return false;
      let node = range.startContainer;
      while (node && node !== document) {
        if (node === sentenceNode) return true;
        node = node.parentNode;
      }
    }
    return false;
  }

  
  // Helper: when caretRangeFromPoint returns an element (overlay) instead of a
  // text node, use elementsFromPoint to find the text node behind the overlay.
  function findTextNodeInElementsFromPoint(event) {
    if (typeof document.elementsFromPoint !== "function") return null;
    const allAt = document.elementsFromPoint(event.clientX, event.clientY);
    for (let ei = 0; ei < allAt.length; ei++) {
      const el = allAt[ei];
      if (el === document.documentElement || el === document.body || el === document) continue;
      const elText = (el.textContent || "").trim();
      if (!elText) continue;

      try {
        const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
        while (walker.nextNode()) {
          const tn = walker.currentNode;
          const tnText = tn.nodeValue || "";
          if (!tnText.trim()) continue;

          // Check click position against this text node's bounding rects
          const range = document.createRange();
          range.selectNodeContents(tn);
          const rects = range.getClientRects();
          for (let ri = 0; ri < rects.length; ri++) {
            if (event.clientX >= rects[ri].left && event.clientX <= rects[ri].right &&
                event.clientY >= rects[ri].top && event.clientY <= rects[ri].bottom) {
              const caretRange = document.caretRangeFromPoint(event.clientX, event.clientY);
              if (caretRange && caretRange.startContainer === tn) {
                return { node: tn, offset: caretRange.startOffset };
              }
              // caretRangeFromPoint returned something else — fallback to offset 0
              return { node: tn, offset: 0 };
            }
          }
        }
      } catch (_) {}
    }
    return null;
  }

function handleSentenceClick(event) {
    if (!enabled) return;
    if (window.getSelection()?.toString().trim()) return;

    const info = findAnalysisData(event);
    if (info?.data) {
      event.preventDefault();
      event.stopPropagation();
      showTranslationTooltip(info.node, event, info.data);
      return;
    }
    // Analysis still in-flight — show placeholder and wait for result.
    // Must prevent default here too — otherwise the overlay <a> navigates
    // before the LLM response arrives.
    if (info?.pending && info.entry) {
      console.log("[BT] handleSentenceClick: path1 pending entry, text='" + (info.entry.text || "").slice(0, 40) + "' loading=" + info.entry.loading);
      event.preventDefault();
      event.stopPropagation();
      showPendingTooltip(info.node, event, info.entry);
      return;
    }
    console.log("[BT] handleSentenceClick: path1 findAnalysisData FAILED");

    // Fallback 1: match by sentence text from caret position — most precise on
    // Reddit where overlay <a> elements intercept clicks. Uses textToAnalysis
    // (text-keyed, no overwrite) so it always returns the card for the actual
    // clicked text, not the last-analyzed sentence on the same parent element.
    const textInfo = findAnalysisDataByText(event);
    if (textInfo?.data) {
      console.log("[BT] handleSentenceClick: path2 textmatch SUCCESS");
      event.preventDefault();
      event.stopPropagation();
      showTranslationTooltip(textInfo.node, event, textInfo.data);
      return;
    }
    console.log("[BT] handleSentenceClick: path2 textmatch FAILED");
  }

  function handleSentenceMouseUp(event) {
    if (!enabled) return;
    const selection = window.getSelection();
    const text = selection?.toString().trim();
    if (!text) return;

    // Don't interfere with interactions inside our own tooltip
    if (event.target?.closest?.(`.${TRANSLATION_TOOLTIP_CLASS}`)) return;

    const info = findAnalysisData(event);
    if (info?.data) {
      event.preventDefault();
      event.stopPropagation();
      showTranslationTooltip(info.node, event, info.data);
      selection.removeAllRanges();
      return;
    }

    // Fallback 1: match by sentence text from caret position
    const textInfo = findAnalysisDataByText(event);
    if (textInfo?.data) {
      event.preventDefault();
      event.stopPropagation();
      showTranslationTooltip(textInfo.node, event, textInfo.data);
      selection.removeAllRanges();
      return;
    }
  }


  function handleTranslationTooltipPointerOver(event) {
    // click-only mode — tooltip is shown on left-click, not hover
  }

  function handleTranslationTooltipPointerOut(event) {
    if (!translationTooltip?.classList.contains("egc-visible")) return;
    const related = event.relatedTarget;
    if (related && (translationTooltip.contains(related) || (translationTooltipSentence?.contains(related)))) return;
    if (!related) console.log("[BT] pointerout: relatedTarget=null target=", event.target, " tooltip=", translationTooltip);
    scheduleTooltipHide();
  }

  function handleTranslationTooltipPointerMove(event) {
    _lastPointerX = event.clientX;
    _lastPointerY = event.clientY;
    if (!translationTooltip?.classList.contains("egc-visible")) return;
    const target = event.target;
    if (target && translationTooltip.contains(target)) {
      clearTooltipHideTimer();
      return;
    }
    // 光标水平离开浮窗边界 → 不再靠原文文字保活
    const tooltipRect = translationTooltip.getBoundingClientRect();
    if (event.clientX < tooltipRect.left || event.clientX > tooltipRect.right) {
      scheduleTooltipHide(80);
      return;
    }
    if (translationTooltipSentence?.isConnected && sentenceContainsPoint(translationTooltipSentence, event)) {
      clearTooltipHideTimer();
    } else {
      scheduleTooltipHide(80);
    }
  }

  function handleDocumentClick(event) {
    if (!translationTooltip?.classList.contains("egc-visible")) return;
    if (translationTooltip.contains(event.target)) return;
    console.log("[BT] docClick hide: target=", event.target);
    hideTranslationTooltip();
  }

  function scheduleTooltipHide(delay = 280) {
    clearTooltipHideTimer();
    tooltipHideTimer = setTimeout(() => {
      console.log("[BT] hide timer fired, delay=" + delay);
      hideTranslationTooltip();
    }, delay);
  }

  function clearTooltipHideTimer() {
    if (tooltipHideTimer) console.log("[BT] clearTooltipHideTimer");
    clearTimeout(tooltipHideTimer);
    tooltipHideTimer = 0;
  }

  function handleTranslationTooltipWheel(event) {
    if (!translationTooltip?.classList.contains("egc-visible")) return;
    if (!translationTooltipSentence?.isConnected) return;

    const overTooltip = event.target === translationTooltip || translationTooltip.contains(event.target);
    const overSentence = translationTooltipSentence.contains(event.target);
    // Use elementsFromPoint to detect the tooltip even when an overlay
    // element (e.g. zephr-anchor paywall) sits above it in z-order.
    const atTooltipPos = !overTooltip && !overSentence &&
      document.elementsFromPoint(event.clientX, event.clientY)
        .some(function (el) { return el === translationTooltip || translationTooltip.contains(el); });
    if (!overTooltip && !overSentence && !atTooltipPos) return;
    if (!isScrollableTooltip()) return;

    event.preventDefault();
    event.stopPropagation();
    translationTooltip.scrollTop += event.deltaY;
    translationTooltip.scrollLeft += event.deltaX;
  }

  function handleTranslationTooltipScroll(event) {
    if (translationTooltip && (event.target === translationTooltip || translationTooltip.contains(event.target))) {
      return;
    }
    hideTranslationTooltip();
  }


  function isPunctuationOnlySegment(text) {
    const value = String(text || "").trim();
    return Boolean(value) && !/[A-Za-z0-9\u4e00-\u9fff]/.test(value);
  }


  function findSegmentIndex(sentence, segmentText, cursor) {
    const direct = sentence.indexOf(segmentText, cursor);
    if (direct >= 0) return direct;

    const pattern = segmentText
      .trim()
      .split(/\s+/)
      .filter(Boolean)
      .map(escapeRegExp)
      .join("\\s+");
    if (pattern) {
      const match = sentence.slice(cursor).match(new RegExp(pattern, "i"));
      if (match) return cursor + match.index;
    }
    return -1;
  }

  function escapeRegExp(text) {
    return String(text).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }

  function buildTranslationText(result) {
    const parts = [];
    if (result?.translation) {
      parts.push(`译文：${result.translation}`);
    }
    if (Array.isArray(result?.notes) && result.notes.length) {
      parts.push(`说明：${result.notes.join("；")}`);
    }
    return parts.join("  ");
  }

  function buildLearningCardData(sentence, result = {}) {
    const segments = normalizeLearningSegments(result.segments);
    return {
      sentence: normalizeSpaces(result.sentence || sentence || ""),
      translation: normalizeSpaces(result.translation || ""),
      fallback: Boolean(result.fallback),
      translationOnly: result.translationOnly === true || translationOnly,
      segments,
      segmentation: buildSegmentationFromSegments(segments),
      sentenceAnalysis: normalizeSentenceLearningAnalysis(result.sentenceAnalysis || result.learningAnalysis || result.analysisCard, segments),
      notes: normalizeLearningList(result.notes, 4),
      words: normalizeLearningWords(result.words || result.vocabulary || result.keyWords || result.importantWords),
      phrases: normalizeLearningPhrases(result.phrases, segments),
      examples: normalizeLearningExamples(result.examples)
    };
  }

  function normalizeLearningSegments(value, depth = 0) {
    return (Array.isArray(value) ? value : [])
      .map((segment) => ({
        text: normalizeSpaces(segment?.text || ""),
        syntacticComponent: normalizeElement(segment?.syntacticComponent),
        label: normalizeSpaces(segment?.label || elementLabel(normalizeElement(segment?.syntacticComponent))),
        translation: normalizeSpaces(segment?.translation || ""),
        note: normalizeSpaces(segment?.note || ""),
        children: depth >= 3 ? [] : normalizeLearningSegments(segment?.children, depth + 1)
      }))
      .filter((segment) => segment.text && segment.syntacticComponent !== "unknown" && !isPunctuationOnlySegment(segment.text))
      .slice(0, 10);
  }

  function normalizeLearningPhrases(value, segments = []) {
    const phrases = (Array.isArray(value) ? value : [])
      .map((phrase) => {
        if (typeof phrase === "string") {
          return { text: normalizeSpaces(phrase), translation: "", note: "" };
        }
        return {
          text: normalizeSpaces(phrase?.text || phrase?.phrase || phrase?.expression || ""),
          translation: normalizeSpaces(phrase?.translation || phrase?.meaning || ""),
          note: normalizeSpaces(phrase?.note || phrase?.explanation || phrase?.usage || "")
        };
      })
      .filter((phrase) => phrase.text);

    if (phrases.length) return phrases.slice(0, 4);

    return segments
      .filter((segment) => countEnglishWords(segment.text) > 1 && (segment.translation || segment.reason))
      .map((segment) => ({
        text: segment.text,
        translation: segment.translation,
        note: segment.reason || ""
      }))
      .slice(0, 4);
  }

  function normalizeLearningWords(value) {
    return (Array.isArray(value) ? value : [])
      .map((word) => {
        if (typeof word === "string") {
          return { text: normalizeSpaces(word), translation: "", partOfSpeech: "", note: "" };
        }
        const noteRaw = word?.note || word?.explanation || word?.usage;
        const note =
          typeof noteRaw === "object" && noteRaw !== null && !Array.isArray(noteRaw)
            ? noteRaw
            : normalizeSpaces(String(noteRaw || ""));
        return {
          text: normalizeSpaces(word?.text || word?.word || word?.term || word?.vocabulary || ""),
          translation: normalizeSpaces(word?.translation || word?.meaning || word?.definition || ""),
          partOfSpeech: normalizeSpaces(word?.partOfSpeech || word?.pos || word?.type || ""),
          level: word?.level || "",
          note
        };
      })
      .filter((word) => word.text);
  }

  function normalizeLearningExamples(value) {
    return (Array.isArray(value) ? value : [])
      .map((example) => {
        if (typeof example === "string") {
          return { english: normalizeSpaces(example), translation: "" };
        }
        return {
          english: normalizeSpaces(example?.english || example?.sentence || example?.example || ""),
          translation: normalizeSpaces(example?.translation || example?.meaning || "")
        };
      })
      .filter((example) => example.english)
      .slice(0, 3);
  }

  function buildSegmentationFromSegments(segments) {
    if (!Array.isArray(segments) || !segments.length) return null;
    return segments.slice(0, 8).map(function (s) {
      return { text: s.text, label: s.label || "", translation: s.translation || "" };
    });
  }

  function normalizeSentenceLearningAnalysis(value, segments = []) {
    const source = value && typeof value === "object" ? value : {};
    const normalized = {
      skeleton: normalizeSpaces(source.skeleton || source.mainStructure || source.mainClause || ""),
      paraphrase: normalizeSpaces(source.paraphrase || source.plainMeaning || source.plainChinese || source.rephrase || ""),
      tone: normalizeSpaces(source.tone || source.register || source.pragmatics || source.context || source.impliedContext || ""),
      structure: normalizeAnalysisRows(source.structure || source.layers || source.hierarchy, 5),
      readingPath: normalizeLearningList(source.readingPath || source.readingSteps || source.howToRead, 4),
      learningPoints: normalizeLearningList(source.learningPoints || source.keyPoints || source.commonPitfalls, 4)
    };

    return normalized;
  }

  function normalizeAnalysisRows(value, limit) {
    return (Array.isArray(value) ? value : [])
      .map((item) => {
        if (typeof item === "string") {
          return { label: "", text: normalizeSpaces(item), note: "" };
        }
        return {
          label: normalizeSpaces(item?.label || item?.type || item?.name || ""),
          text: normalizeSpaces(item?.text || item?.content || item?.phrase || ""),
          note: normalizeSpaces(item?.note || item?.explanation || item?.syntacticComponent || "")
        };
      })
      .filter((item) => item.text || item.note)
      .slice(0, limit);
  }

  function hasSentenceAnalysisContent(analysis) {
    return Boolean(
      analysis?.skeleton
      || analysis?.paraphrase
      || analysis?.tone
      || analysis?.structure?.length
      || analysis?.readingPath?.length
      || analysis?.learningPoints?.length
    );
  }

  function normalizeLearningList(value, limit) {
    return (Array.isArray(value) ? value : [])
      .map((item) => normalizeSpaces(item || ""))
      .filter(Boolean)
      .slice(0, limit);
  }

  function filterRedundantLearningItems(items, referenceTexts, limit = 4) {
    const references = (Array.isArray(referenceTexts) ? referenceTexts : [])
      .map((item) => normalizeSpaces(item))
      .filter(Boolean);
    const result = [];

    for (const item of Array.isArray(items) ? items : []) {
      const text = normalizeSpaces(item);
      if (!text) continue;
      if (references.some((reference) => isSimilarLearningText(text, reference))) continue;
      if (result.some((accepted) => isSimilarLearningText(text, accepted))) continue;
      result.push(text);
      references.push(text);
      if (result.length >= limit) break;
    }

    return result;
  }

  function filterRedundantLearningObjects(items, referenceTexts, limit = 5) {
    const references = (Array.isArray(referenceTexts) ? referenceTexts : [])
      .map((item) => normalizeSpaces(item))
      .filter(Boolean);
    const result = [];

    for (const item of Array.isArray(items) ? items : []) {
      const text = normalizeSpaces(item?.text || item?.word || "");
      if (!text) continue;
      const details = [item.translation, typeof item.note === "string" ? item.note : ""].filter(Boolean);
      if (details.some((value) => references.some((reference) => isSimilarLearningText(value, reference)))) continue;
      if (result.some((accepted) => isSimilarLearningText(text, accepted.text))) continue;
      result.push(item);
      references.push(text, ...details);
      if (result.length >= limit) break;
    }

    return result;
  }

  function isSimilarLearningText(left, right) {
    const leftText = normalizeComparableLearningText(left);
    const rightText = normalizeComparableLearningText(right);
    if (!leftText || !rightText) return false;
    if (leftText === rightText) return true;
    const shorter = leftText.length <= rightText.length ? leftText : rightText;
    const longer = leftText.length > rightText.length ? leftText : rightText;
    if (shorter.length >= 8 && longer.includes(shorter)) return true;

    const leftTokens = tokenizeComparableLearningText(leftText);
    const rightTokens = tokenizeComparableLearningText(rightText);
    if (!leftTokens.length || !rightTokens.length) return false;
    const rightSet = new Set(rightTokens);
    const overlap = leftTokens.filter((token) => rightSet.has(token)).length;
    return overlap / Math.min(leftTokens.length, rightTokens.length) >= 0.75;
  }

  function normalizeComparableLearningText(text) {
    return normalizeSpaces(text)
      .toLowerCase()
      .replace(/[“”"‘’'`()[\]{}<>]/g, "")
      .replace(/[，。！？；：、,.!?;:/\\|-]+/g, " ")
      .replace(/\s+/g, " ")
      .trim();
  }

  function tokenizeComparableLearningText(text) {
    return text.match(/[a-z0-9]+|[\u4e00-\u9fff]/g) || [];
  }

  // Show a "分析中…" placeholder while the API call is in-flight.
  // When the entry's analysis completes, transition to the full tooltip.
  function showPendingTooltip(sentenceNode, event, entry) {
    const tooltip = ensureTranslationTooltip();
    if (!tooltip) return;

    translationTooltipSentence = sentenceNode;
    tooltip._contentWrapper.textContent = "分析中…";
    tooltip._contentWrapper.style.cssText = "padding:8px 16px;font-size:14px;white-space:nowrap;";
    tooltip.classList.add("egc-visible");
    positionTranslationTooltip(event, sentenceNode);

    // Poll for completion; analysis data is set by noDomAnalyzeSentence
    var pollTimer = setInterval(function () {
      if (entry.analysis) {
        clearInterval(pollTimer);
        tooltip._contentWrapper.style.cssText = "";
        showTranslationTooltip(sentenceNode, event, entry.analysis);
      } else if (!entry.loading && !entry.analysis) {
        // Loading finished but no result — analysis failed, hide
        clearInterval(pollTimer);
        hideTranslationTooltip();
      }
    }, 400);
    // Store so hide can clean up
    tooltip._pendingPoll = pollTimer;
  }

  function showTranslationTooltip(sentenceNode, event, data) {
    if (!data || !hasLearningCardContent(data)) {
      hideTranslationTooltip();
      return;
    }

    const tooltip = ensureTranslationTooltip();
    if (!tooltip) return;

    translationTooltipSentence = sentenceNode;
    renderLearningTooltip(tooltip, data);
    resetTranslationTooltipScroll(tooltip);
    tooltip.classList.add("egc-visible");
    positionTranslationTooltip(event, sentenceNode);
    if (tooltipTheme) applyTooltipTheme(tooltip, tooltipTheme);
  }

  function resetTranslationTooltipScroll(tooltip) {
    if (!tooltip) return;
    tooltip.scrollTop = 0;
    tooltip.scrollLeft = 0;
  }

  function ensureTranslationTooltip() {
    if (translationTooltip?.isConnected) return translationTooltip;
    if (!document.body) return null;

    translationTooltip = document.createElement("div");
    translationTooltip.className = TRANSLATION_TOOLTIP_CLASS;
    translationTooltip.setAttribute("role", "tooltip");
    translationTooltip.setAttribute("aria-hidden", "true");
    translationTooltip.addEventListener("pointerenter", () => {
      clearTooltipHideTimer();
    });
    translationTooltip.addEventListener("pointerleave", (event) => {
      if (translationTooltipSentence?.contains(event.relatedTarget)) return;
      if (translationTooltip?._themePanel?.classList.contains("egc-open")) return;
      console.log("[BT] pointerleave: relatedTarget=", event.relatedTarget);
      scheduleTooltipHide();
    });
    translationTooltip.addEventListener("wheel", stopTooltipScrollPropagation, { passive: true });
    translationTooltip.addEventListener("touchmove", stopTooltipScrollPropagation, { passive: true });
    translationTooltip.addEventListener("scroll", clearTooltipHideTimer, { passive: true });

    // Theme panel (not appended to DOM yet — will be inserted by renderLearningTooltip)
    const themePanel = document.createElement("div");
    themePanel.className = "egc-theme-panel";
    themePanel.addEventListener("pointerenter", () => clearTooltipHideTimer());

    // Content wrapper
    const contentWrapper = document.createElement("div");
    contentWrapper.className = "egc-tooltip-content";

    translationTooltip.appendChild(contentWrapper);
    translationTooltip._themePanel = themePanel;
    translationTooltip._contentWrapper = contentWrapper;

    // Build theme controls and load saved theme
    buildThemePanelContent(themePanel, translationTooltip);
    loadTooltipTheme().then(theme => applyTooltipTheme(translationTooltip, theme));

    document.body.appendChild(translationTooltip);
    return translationTooltip;
  }

  function stopTooltipScrollPropagation(event) {
    event.stopPropagation();
  }

  function isScrollableTooltip() {
    return Boolean(translationTooltip && translationTooltip.scrollHeight > translationTooltip.clientHeight + 1);
  }

  function positionTranslationTooltip(event, sentenceNode) {
    const tooltip = translationTooltip;
    if (!tooltip?.classList.contains("egc-visible")) return;

    const vv = window.visualViewport;
    const viewportWidth = vv ? vv.width : (window.innerWidth || document.documentElement.clientWidth || 0);
    const viewportHeight = vv ? vv.height : (window.innerHeight || document.documentElement.clientHeight || 0);
    const visualOffsetY = vv ? vv.offsetTop : 0;
    const visualOffsetX = vv ? vv.offsetLeft : 0;
    const margin = TOOLTIP_VIEWPORT_MARGIN_PX;
    const offset = TOOLTIP_OFFSET_PX;
    const cursorX = event?.clientX ?? 0;
    const cursorY = event?.clientY ?? 0;

    // Width: more space below → narrower; less space → wider (to reduce vertical scroll)
    const availableBelow = visualOffsetY + viewportHeight - cursorY - offset - margin;
    const narrowWidth = 440;
    const wideWidth = Math.min(820, viewportWidth - 16);
    const widthRatio = Math.min(1, Math.max(0, 1 - (availableBelow - 200) / 500));
    const desiredWidth = Math.round(narrowWidth + widthRatio * (wideWidth - narrowWidth));
    tooltip.style.width = `${Math.round(Math.min(desiredWidth, viewportWidth - 16))}px`;

    tooltip.style.left = "0px";
    tooltip.style.top = "0px";
    const tooltipRect = tooltip.getBoundingClientRect();

    // Horizontal: center on cursor X, clamped to visual viewport
    let left = visualOffsetX + clamp(cursorX - visualOffsetX - tooltipRect.width / 2, margin, viewportWidth - tooltipRect.width - margin);

    
    // Vertical: below the cursor, or above if would overflow viewport
    let top = cursorY + offset;
    // If tooltip would overflow viewport bottom, try placing above the sentence
    const tooltipHeight = tooltipRect.height;
    const overflowBottom = top + tooltipHeight - visualOffsetY - viewportHeight + margin;
    if (overflowBottom > 0) {
      const availableAbove = cursorY - visualOffsetY - margin;
      if (availableAbove >= tooltipHeight) {
        top = cursorY - tooltipHeight - offset;
      } else {
        // Clamp to viewport — user can scroll within the tooltip
        top = Math.max(visualOffsetY + margin, visualOffsetY + viewportHeight - tooltipHeight - margin);
      }
    }

    tooltip.style.left = `${left}px`;
    tooltip.style.top = `${top}px`;
  }

  function hideTranslationTooltip() {
    clearTooltipHideTimer();
    translationTooltipSentence = null;
    if (translationTooltip) {
      clearInterval(translationTooltip._pendingPoll);
      translationTooltip._pendingPoll = 0;
      translationTooltip.classList.remove("egc-visible");
      translationTooltip.style.width = "";
    }
  }

  function speak(text, button, lang = "en-US") {
    stopSpeech();
    if (!text || typeof speechSynthesis === "undefined") return;

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = lang;
    utterance.rate = 0.88;

    speechActive = true;
    utterance.onstart = () => {
      button?.classList.add("egc-speaking");
    };
    utterance.onend = () => {
      speechActive = false;
      button?.classList.remove("egc-speaking");
    };
    utterance.onerror = () => {
      speechActive = false;
      button?.classList.remove("egc-speaking");
    };

    speechSynthesis.speak(utterance);
  }

  function stopSpeech() {
    if (typeof speechSynthesis === "undefined") return;
    speechSynthesis.cancel();
    speechActive = false;
    for (const button of document.querySelectorAll(".egc-speaking")) {
      button.classList.remove("egc-speaking");
    }
  }

  function buildSpeakGroup(text) {
    const group = document.createElement("span");
    group.className = "egc-speak-group";

    const uk = document.createElement("button");
    uk.type = "button";
    uk.className = "egc-speak-button";
    uk.setAttribute("aria-label", "英式发音");
    uk.textContent = "UK";
    uk.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      speak(text, uk, "en-GB");
    });

    const us = document.createElement("button");
    us.type = "button";
    us.className = "egc-speak-button";
    us.setAttribute("aria-label", "美式发音");
    us.textContent = "US";
    us.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      speak(text, us, "en-US");
    });

    group.appendChild(uk);
    group.appendChild(us);
    return group;
  }

  // getSentenceLearningCardData, getSentenceTranslationText, parseLearningCardData removed: dead after domMode removal.

  function hasLearningCardContent(data) {
    return Boolean(data?.translation || hasSentenceAnalysisContent(data?.sentenceAnalysis) || data?.segments?.length || data?.notes?.length || data?.words?.length || data?.phrases?.length || data?.examples?.length);
  }

  function renderLearningTooltip(tooltip, data) {
    const wrapper = tooltip._contentWrapper || tooltip;
    wrapper.textContent = "";
    wrapper.style.cssText = "";
    const display = buildLearningDisplayProfile(data);
    appendContinueChatButton(wrapper, data);
    // Theme panel always goes right after the chat row, before content sections
    if (tooltip._themePanel) wrapper.appendChild(tooltip._themePanel);
    appendMeaningSection(wrapper, data, display);
    if (!data.translationOnly) {
      if (showSegmentation) appendSegmentationSection(wrapper, data.segmentation);
      appendWordSection(wrapper, display.words);
      appendPhraseSection(wrapper, data.phrases);
      if (display.showStructure) appendStructureSection(wrapper, data.sentenceAnalysis);
      appendTooltipListSection(wrapper, "补充说明", display.notes);
      appendExampleSection(wrapper, data.examples);
    }
  }

  // ── 浮窗主题 ─────────────────────────────────

  const TOOLTIP_THEME_KEY = "tooltipThemeSettings";

  const THEME_PRESETS = [
    { id: "dark",   label: "深色", color: "#12141f" },
    { id: "strong", label: "极夜", color: "#080a12" },
    { id: "green",  label: "墨绿", color: "#1a2e28" },
    { id: "blue",   label: "藏蓝", color: "#1a2235" },
    { id: "warm",   label: "暖灰", color: "#2d261c" }
  ];

  function getDefaultTooltipTheme() {
    return { preset: "dark", opacity: 0.56, blur: 1.5 };
  }

  function hexToRgba(hex, alpha) {
    const num = parseInt(hex.slice(1), 16);
    return `rgba(${num >> 16}, ${(num >> 8) & 0xff}, ${num & 0xff}, ${alpha})`;
  }

  function darkenHex(hex, amount) {
    const num = parseInt(hex.slice(1), 16);
    const r = Math.max((num >> 16) - amount, 0);
    const g = Math.max(((num >> 8) & 0xff) - amount, 0);
    const b = Math.max((num & 0xff) - amount, 0);
    return "#" + ((r << 16) | (g << 8) | b).toString(16).padStart(6, "0");
  }

  async function loadTooltipTheme() {
    try {
      const result = await chrome.storage.local.get(TOOLTIP_THEME_KEY);
      tooltipTheme = result[TOOLTIP_THEME_KEY] || getDefaultTooltipTheme();
    } catch {
      tooltipTheme = getDefaultTooltipTheme();
    }
    return tooltipTheme;
  }

  async function saveTooltipTheme(theme) {
    tooltipTheme = theme;
    try {
      await chrome.storage.local.set({ [TOOLTIP_THEME_KEY]: theme });
    } catch { /* content script storage may fail in some contexts */ }
  }

  function applyTooltipTheme(tooltip, theme) {
    if (!tooltip) return;
    const preset = THEME_PRESETS.find(p => p.id === theme.preset) || THEME_PRESETS[0];
    const topColor = hexToRgba(preset.color, theme.opacity);
    const bottomColor = hexToRgba(darkenHex(preset.color, 8), theme.opacity);
    tooltip.style.background = `linear-gradient(180deg, ${topColor}, ${bottomColor})`;
    const blur = Math.max(0, theme.blur);
    const filter = blur > 0 ? `blur(${blur}px) saturate(0.95)` : "none";
    tooltip.style.backdropFilter = filter;
    tooltip.style.webkitBackdropFilter = filter;
  }

  function buildThemePanelContent(panel, tooltip) {
    const current = tooltipTheme || getDefaultTooltipTheme();

    // Presets
    const presetsLabel = document.createElement("div");
    presetsLabel.className = "egc-theme-label";
    presetsLabel.textContent = "背景色";
    panel.appendChild(presetsLabel);

    const presetsRow = document.createElement("div");
    presetsRow.className = "egc-theme-presets";

    for (const p of THEME_PRESETS) {
      const dot = document.createElement("div");
      dot.className = "egc-theme-preset" + (p.id === current.preset ? " egc-active" : "");
      dot.style.background = p.color;
      dot.title = p.label;
      dot.dataset.presetId = p.id;
      dot.addEventListener("click", (e) => {
        e.stopPropagation();
        updatePreset(p.id);
      });
      presetsRow.appendChild(dot);
    }

    panel.appendChild(presetsRow);

    // --- Opacity slider ---
    const opacityRow = document.createElement("div");
    opacityRow.className = "egc-theme-row";
    const opacityLabel = document.createElement("label");
    opacityLabel.textContent = "透明度";
    const opacityInput = document.createElement("input");
    opacityInput.type = "range";
    opacityInput.min = "0.3";
    opacityInput.max = "1";
    opacityInput.step = "0.01";
    opacityInput.value = String(current.opacity);
    const opacityVal = document.createElement("span");
    opacityVal.className = "egc-theme-value";
    opacityVal.textContent = current.opacity.toFixed(2);
    opacityRow.append(opacityLabel, opacityInput, opacityVal);
    panel.appendChild(opacityRow);
    opacityInput.addEventListener("input", (e) => {
      e.stopPropagation();
      const val = parseFloat(e.target.value);
      opacityVal.textContent = val.toFixed(2);
      const theme = { ...(tooltipTheme || getDefaultTooltipTheme()), opacity: val };
      applyTooltipTheme(tooltip, theme);
    });
    opacityInput.addEventListener("change", (e) => {
      e.stopPropagation();
      const theme = { ...(tooltipTheme || getDefaultTooltipTheme()), opacity: parseFloat(e.target.value) };
      saveTooltipTheme(theme);
    });

    // --- Blur slider ---
    const blurRow = document.createElement("div");
    blurRow.className = "egc-theme-row";
    const blurLabel = document.createElement("label");
    blurLabel.textContent = "模糊";
    const blurInput = document.createElement("input");
    blurInput.type = "range";
    blurInput.min = "0";
    blurInput.max = "20";
    blurInput.step = "0.5";
    blurInput.value = String(current.blur);
    const blurVal = document.createElement("span");
    blurVal.className = "egc-theme-value";
    blurVal.textContent = current.blur.toFixed(1) + "px";
    blurRow.append(blurLabel, blurInput, blurVal);
    panel.appendChild(blurRow);
    blurInput.addEventListener("input", (e) => {
      e.stopPropagation();
      const val = parseFloat(e.target.value);
      blurVal.textContent = val.toFixed(1) + "px";
      const theme = { ...(tooltipTheme || getDefaultTooltipTheme()), blur: val };
      applyTooltipTheme(tooltip, theme);
    });
    blurInput.addEventListener("change", (e) => {
      e.stopPropagation();
      const theme = { ...(tooltipTheme || getDefaultTooltipTheme()), blur: parseFloat(e.target.value) };
      saveTooltipTheme(theme);
    });

    function updatePreset(presetId) {
      const theme = { ...(tooltipTheme || getDefaultTooltipTheme()), preset: presetId };
      applyTooltipTheme(tooltip, theme);
      saveTooltipTheme(theme);
      presetsRow.querySelectorAll(".egc-theme-preset").forEach(d => d.classList.remove("egc-active"));
      const active = presetsRow.querySelector(`[data-preset-id="${presetId}"]`);
      if (active) active.classList.add("egc-active");
    }
  }

  function formatWordNote(note) {
    if (!note) return "";
    if (typeof note === "string") return ` — ${note}`;
    if (typeof note !== "object" || Array.isArray(note)) return "";
    const parts = [];
    const labels = { synonym: "近义辨析", collocation: "常见搭配", etymology: "词源" };
    for (const key of ["collocation", "synonym", "etymology"]) {
      const val = note[key];
      if (val && typeof val === "string") {
        parts.push(`${labels[key] || key}：${val}`);
      }
    }
    return parts.length ? ` — ${parts.join("；")}` : "";
  }

  function formatAnalysisAsMarkdown(data) {
    const lines = [];
    if (data.translation) lines.push(`**译文：**${data.translation}`);
    const sa = data.sentenceAnalysis;
    if (sa?.paraphrase) lines.push(`\n**白话：**${sa.paraphrase}`);
    if (sa?.skeleton) lines.push(`\n**主干：**${sa.skeleton}`);
    if (sa?.tone) lines.push(`\n**语气：**${sa.tone}`);
    if (Array.isArray(sa?.learningPoints) && sa.learningPoints.length) {
      lines.push(`\n**易错点：**`);
      for (const pt of sa.learningPoints.slice(0, 4)) {
        lines.push(`- ${pt}`);
      }
    }
    if (Array.isArray(sa?.structure) && sa.structure.length) {
      for (const row of sa.structure.slice(0, 4)) {
        lines.push(`\n**${row.label || "结构"}：**${row.text}`);
      }
    }
    if (Array.isArray(data.words) && data.words.length) {
      lines.push(`\n**重点单词：**`);
      for (const w of data.words.slice(0, 4)) {
        const levelTag = w.level ? ` [${w.level}]` : "";
        const posTag = w.partOfSpeech ? ` · ${w.partOfSpeech}` : "";
        const noteText = formatWordNote(w.note);
        lines.push(`- **${w.text}**${posTag}${levelTag} — ${w.translation}${noteText}`);
      }
    }
    if (Array.isArray(data.examples) && data.examples.length) {
      lines.push(`\n**例句：**`);
      for (const ex of data.examples.slice(0, 2)) {
        lines.push(`- ${ex.english}`);
        if (ex.translation) lines.push(`  ${ex.translation}`);
      }
    }
    return lines.join("\n");
  }

  function appendContinueChatButton(parent, data) {
    const row = document.createElement("div");
    row.className = "egc-tooltip-chat-row";

    const btn = document.createElement("button");
    btn.className = "egc-tooltip-chat-btn";
    btn.textContent = "💬 继续追问";
    btn.addEventListener("click", (event) => {
      event.stopPropagation();
      btn.disabled = true;
      btn.textContent = "打开中…";
      const md = formatAnalysisAsMarkdown(data);
      const s = window.screen;
      const sw = s?.availWidth, sh = s?.availHeight, sx = s?.availLeft || 0, sy = s?.availTop || 0;
      try {
        globalThis.chrome?.runtime?.sendMessage({
          action: "openPanelWithAnalysis",
          payload: {
            sentence: data.sentence || "",
            analysis: md,
            analysisData: data,
            sourceUrl: location.href,
            pageTitle: document.title,
            screenAvailWidth: sw || 1920,
            screenAvailHeight: sh || 1080,
            screenLeft: sx,
            screenTop: sy
          }
        }, () => {
          if (chrome.runtime.lastError?.message?.includes("Extension context invalidated")) {
            cleanupInjectedUI();
            return;
          }
          btn.disabled = false;
          btn.textContent = "💬 继续追问";
        });
      } catch (e) {
        if (e?.message?.includes("Extension context invalidated")) {
          cleanupInjectedUI();
          return;
        }
        btn.disabled = false;
        btn.textContent = "💬 继续追问";
      }
    });

    const paletteBtn = document.createElement("button");
    paletteBtn.type = "button";
    paletteBtn.className = "egc-tooltip-header-btn";
    paletteBtn.textContent = "🎨";
    paletteBtn.title = "主题设置";
    paletteBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      translationTooltip?._themePanel?.classList.toggle("egc-open");
    });

    row.append(btn, paletteBtn);
    parent.appendChild(row);
  }

  function buildLearningDisplayProfile(data) {
    if (data?.translationOnly) {
      return { isComplex: false, showParaphrase: false, showSkeleton: false, showReadingPath: false, showStructure: false, showSegments: false, words: [], learningPoints: [], notes: [] };
    }
    const analysis = data?.sentenceAnalysis || {};
    const flatSegments = flattenLearningSegments(data?.segments || []);
    const topLevelSegments = Array.isArray(data?.segments) ? data.segments : [];
    const hasNestedSegments = flatSegments.some((segment) => segment.depth > 0);
    const sentenceWordCount = countEnglishWords(data?.sentence || "");
    const hasStructureLayers = (analysis.structure || []).length > 1;
    const isComplex = hasNestedSegments || topLevelSegments.length >= 5 || sentenceWordCount >= 10 || hasStructureLayers;
    const meaningTexts = [data?.translation];
    const phraseTexts = (data?.phrases || []).flatMap((phrase) => [phrase.text, phrase.translation, phrase.note]);
    const filteredByLevel = Array.isArray(wordLevels)
      ? (data?.words || []).filter((w) => !w.level || wordLevels.includes(w.level))
      : (data?.words || []);
    const words = filterRedundantLearningObjects(filteredByLevel, [], 99);
    const wordTexts = words.flatMap((word) => [word.text, word.translation, word.note]);

    const showParaphrase = Boolean(
      analysis.paraphrase
      && !isSimilarLearningText(analysis.paraphrase, data?.translation)
    );
    if (showParaphrase) meaningTexts.push(analysis.paraphrase);

    const showSkeleton = Boolean(
      analysis.skeleton
      && isComplex
      && !isSimilarLearningText(analysis.skeleton, data?.sentence)
      && !meaningTexts.some((text) => isSimilarLearningText(analysis.skeleton, text))
    );
    if (showSkeleton) meaningTexts.push(analysis.skeleton);

    const showReadingPath = Boolean(isComplex && analysis.readingPath?.length);
    const showStructure = Boolean(analysis.structure?.length);
    const showSegments = Boolean(
      hasNestedSegments
      || topLevelSegments.length >= 5
      || (!analysis.structure?.length && topLevelSegments.length)
    );
    const learningPoints = filterRedundantLearningItems(analysis.learningPoints || [], [
      ...meaningTexts,
      analysis.tone,
      ...wordTexts,
      ...phraseTexts
    ]);

    return {
      isComplex,
      showParaphrase,
      showSkeleton,
      showReadingPath,
      showStructure,
      showSegments,
      words,
      learningPoints,
      notes: filterRedundantLearningItems(data?.notes || [], [
        ...meaningTexts,
        analysis.tone,
        ...wordTexts,
        ...learningPoints,
        ...phraseTexts
      ])
    };
  }

  function buildTooltipTranslationText(data) {
    if (data?.translation) return data.translation;
    if (data?.fallback) return "分析不完整，暂未生成译文。";
    return "模型未返回译文。";
  }

  function buildCompactTranslationText(data) {
    if (data?.translation) return data.translation;
    if (data?.fallback) return "分析不完整，暂未生成译文。";
    return "";
  }

  function appendTooltipSection(parent, title, body) {
    if (!body) return;
    const section = document.createElement("section");
    section.className = "egc-tooltip-section";
    section.appendChild(buildTooltipTitle(title));
    const paragraph = document.createElement("p");
    paragraph.className = "egc-tooltip-text";
    paragraph.textContent = body;
    section.appendChild(paragraph);
    parent.appendChild(section);
  }

  function appendMeaningSection(parent, data, display) {
    const analysis = data?.sentenceAnalysis || {};
    if (!data?.translation && !hasSentenceAnalysisContent(analysis)) return;
    const section = document.createElement("section");
    section.className = "egc-tooltip-section egc-tooltip-priority-section";

    if (data?.sentence) {
      const row = buildTooltipRow("原文", data.sentence, "");
      const textEl = row.querySelector(".egc-tooltip-row-text");
      if (textEl) textEl.appendChild(buildSpeakGroup(data.sentence));
      section.appendChild(row);
    }
    appendTooltipRowIfText(section, "译文", buildCompactTranslationText(data), "");
    if (display.showParaphrase) {
      section.appendChild(buildTooltipRow("白话理解", analysis.paraphrase, ""));
    }
    if (display.showSkeleton) {
      section.appendChild(buildTooltipRow("主干", analysis.skeleton, ""));
    }
    if (analysis.tone && showTone) {
      section.appendChild(buildTooltipRow("语气/语境", analysis.tone, ""));
    }

    if (display.showReadingPath) {
      appendInlineTooltipList(section, "阅读顺序", analysis.readingPath, true);
    }
    appendInlineTooltipList(section, "学习重点", display.learningPoints, false);
    parent.appendChild(section);
  }

  function appendTooltipRowIfText(parent, label, text, detail) {
    if (!text) return;
    parent.appendChild(buildTooltipRow(label, text, detail));
  }

  function appendSegmentationSection(parent, segmentation) {
    if (!segmentation?.length) return;
    const section = document.createElement("section");
    section.className = "egc-tooltip-section";
    section.appendChild(buildTooltipTitle("断句"));
    for (const seg of segmentation) {
      const row = document.createElement("div");
      row.className = "egc-tooltip-detail-line";
      const inner = document.createElement("div");
      inner.style.cssText = "min-width:0;overflow-wrap:anywhere;word-break:break-word";
      inner.textContent = seg.text + " → " + (seg.label ? "[" + seg.label + "] " : "") + seg.translation;
      row.appendChild(inner);
      section.appendChild(row);
    }
    parent.appendChild(section);
  }

  function appendStructureSection(parent, analysis) {
    if (!analysis?.structure?.length) return;
    const section = document.createElement("section");
    section.className = "egc-tooltip-section";
    section.appendChild(buildTooltipTitle("语法解析"));

    for (const row of analysis.structure.slice(0, 5)) {
      section.appendChild(buildTooltipRow(row.label || "结构", row.text, row.note));
    }
    parent.appendChild(section);
  }

  function appendInlineTooltipList(parent, label, items, ordered) {
    if (!items?.length) return;
    const wrapper = document.createElement("div");
    wrapper.className = "egc-tooltip-subsection";
    wrapper.appendChild(buildTooltipTitle(label));
    const list = document.createElement(ordered ? "ol" : "ul");
    list.className = "egc-tooltip-list";
    for (const item of items.slice(0, 4)) {
      const listItem = document.createElement("li");
      listItem.textContent = item;
      list.appendChild(listItem);
    }
    wrapper.appendChild(list);
    parent.appendChild(wrapper);
  }

  function appendSegmentSection(parent, segments) {
    if (!segments?.length) return;
    const section = document.createElement("section");
    section.className = "egc-tooltip-section";
    section.appendChild(buildTooltipTitle("成分明细"));
    for (const segment of flattenLearningSegments(segments).slice(0, 16)) {
      section.appendChild(buildTooltipSegmentCard(segment));
    }
    parent.appendChild(section);
  }

  function buildTooltipSegmentCard(segment) {
    const card = document.createElement("div");
    card.className = "egc-tooltip-segment-card";
    card.style.setProperty("--egc-tooltip-depth", String(segment.depth || 0));

    const head = document.createElement("div");
    head.className = "egc-tooltip-segment-head";

    const label = document.createElement("span");
    label.className = "egc-tooltip-segment-label";
    label.textContent = segment.label || elementLabel(segment.syntacticComponent);
    head.appendChild(label);

    const text = document.createElement("span");
    text.className = "egc-tooltip-segment-text";
    text.textContent = segment.text;
    head.appendChild(text);
    card.appendChild(head);

    const detailText = [segment.translation, segment.reason].filter(Boolean).join("；");
    if (detailText) {
      const detail = document.createElement("div");
      detail.className = "egc-tooltip-segment-detail";
      detail.textContent = detailText;
      card.appendChild(detail);
    }

    return card;
  }

  function flattenLearningSegments(segments, depth = 0) {
    const rows = [];
    for (const segment of Array.isArray(segments) ? segments : []) {
      rows.push({ ...segment, depth });
      rows.push(...flattenLearningSegments(segment.children, depth + 1));
    }
    return rows;
  }

  function appendPhraseSection(parent, phrases) {
    if (!phrases?.length) return;
    const section = document.createElement("section");
    section.className = "egc-tooltip-section egc-tooltip-priority-section";
    section.appendChild(buildTooltipTitle("可复用表达"));
    for (const phrase of phrases.slice(0, 4)) {
      section.appendChild(buildTooltipRow(phrase.text, phrase.translation, phrase.note));
    }
    parent.appendChild(section);
  }

  function appendWordSection(parent, words) {
    if (!words?.length) return;
    const section = document.createElement("section");
    section.className = "egc-tooltip-section";
    section.appendChild(buildTooltipTitle("重点单词"));
    for (const word of words) {
      const label = [word.text, word.partOfSpeech].filter(Boolean).join(" · ");
      const row = buildTooltipRow(label, word.translation, word.note);
      row.classList.add("egc-word-row");
      if (word.text) {
        const labelElement = row.querySelector(".egc-tooltip-label");
        labelElement.textContent = "";
        const title = document.createElement("span");
        title.textContent = label;
        labelElement.appendChild(title);
        const actions = document.createElement("span");
        actions.className = "egc-word-actions";
        actions.appendChild(buildSpeakGroup(word.text));
        if (word.level) {
          const badge = document.createElement("span");
          badge.className = "egc-word-level-badge";
          badge.textContent = word.level;
          actions.appendChild(badge);
        }
        labelElement.appendChild(actions);
      }
      section.appendChild(row);
    }
    parent.appendChild(section);
  }

  function appendTooltipListSection(parent, title, items) {
    if (!items?.length) return;
    const section = document.createElement("section");
    section.className = "egc-tooltip-section";
    section.appendChild(buildTooltipTitle(title));
    const list = document.createElement("ul");
    list.className = "egc-tooltip-list";
    for (const item of items.slice(0, 4)) {
      const listItem = document.createElement("li");
      listItem.textContent = item;
      list.appendChild(listItem);
    }
    section.appendChild(list);
    parent.appendChild(section);
  }

  function appendExampleSection(parent, examples) {
    if (!examples?.length) return;
    const section = document.createElement("section");
    section.className = "egc-tooltip-section";
    section.appendChild(buildTooltipTitle("举例"));
    for (const example of examples.slice(0, 3)) {
      const row = buildTooltipRow("例句", example.english, example.translation);
      const textEl = row.querySelector(".egc-tooltip-row-text");
      if (textEl) textEl.appendChild(buildSpeakGroup(example.english));
      section.appendChild(row);
    }
    parent.appendChild(section);
  }

  function buildTooltipTitle(text) {
    const title = document.createElement("div");
    title.className = "egc-tooltip-title";
    title.textContent = text;
    return title;
  }

  function buildTooltipRow(label, text, detail) {
    const row = document.createElement("div");
    row.className = "egc-tooltip-row";

    const labelElement = document.createElement("span");
    labelElement.className = "egc-tooltip-label";
    labelElement.textContent = label;
    row.appendChild(labelElement);

    const body = document.createElement("span");
    body.className = "egc-tooltip-row-body";

    if (text) {
      const textEl = document.createElement("span");
      textEl.className = "egc-tooltip-row-text";
      textEl.textContent = text;
      body.appendChild(textEl);
    }

    if (detail) {
      const detailEl = document.createElement("span");
      detailEl.className = "egc-tooltip-row-detail";

      if (typeof detail === "object" && !Array.isArray(detail)) {
        const fields = [
          { key: "synonym", label: "近义辨析" },
          { key: "collocation", label: "常见搭配" },
          { key: "etymology", label: "词源" }
        ];
        for (const field of fields) {
          const value = detail[field.key];
          if (!value || typeof value !== "string") continue;
          const line = document.createElement("span");
          line.className = "egc-tooltip-detail-line";
          const labelEl = document.createElement("span");
          labelEl.className = "egc-tooltip-detail-label";
          labelEl.textContent = field.label;
          line.appendChild(labelEl);
          const contentEl = document.createElement("span");
          contentEl.className = "egc-tooltip-detail-content";
          contentEl.textContent = value;
          line.appendChild(contentEl);
          detailEl.appendChild(line);
        }
      } else {
        const text = String(detail);
        const parts = text.split(/(?=[①②③④])/);
        if (parts.length > 1) {
          for (const part of parts) {
            const trimmed = part.trim();
            if (!trimmed) continue;
            const colonIdx = trimmed.indexOf("：");
            const labelText = colonIdx > 0 ? trimmed.slice(0, colonIdx) : "";
            const contentText = colonIdx > 0 ? trimmed.slice(colonIdx + 1) : trimmed;
            const line = document.createElement("span");
            line.className = "egc-tooltip-detail-line";
            if (labelText) {
              const labelEl = document.createElement("span");
              labelEl.className = "egc-tooltip-detail-label";
              labelEl.textContent = labelText;
              line.appendChild(labelEl);
            }
            const contentEl = document.createElement("span");
            contentEl.className = "egc-tooltip-detail-content";
            contentEl.textContent = contentText;
            line.appendChild(contentEl);
            detailEl.appendChild(line);
          }
        } else {
          detailEl.textContent = text;
        }
      }
      body.appendChild(detailEl);
    }

    row.appendChild(body);
    return row;
  }

  function unwrapAnnotations() {
    hideTranslationTooltip();
    textNodeSentences.clear();
    elementSentenceEntries.clear();
    textToAnalysis.clear();
    textToPending.clear();
    noDomPending.length = 0;
    sentenceCount = 0;
  }

  const ELEMENT_MAP = new Map([
    ["subject", "subject"],
    ["predicate", "predicate"],
    ["object", "object"],
    ["predicative", "predicative"],
    ["directobject", "directObject"],
    ["indirectobject", "indirectObject"],
    ["objectcomplement", "objectComplement"],
    ["subjectcomplement", "subjectComplement"],
    ["attribute", "attribute"],
    ["adverbial", "adverbial"],
    ["appositive", "appositive"],
    ["parenthesis", "parenthesis"],
    ["formalsubject", "formalSubject"],
    ["formalobject", "formalObject"],
    ["cognateobject", "cognateObject"],
    ["vocative", "vocative"],
    ["conjunction", "conjunction"],
    ["nounphrase", "nounPhrase"],
    ["verbphrase", "verbPhrase"],
    ["prepositionalphrase", "prepositionalPhrase"],
    ["adjectivephrase", "adjectivePhrase"],
    ["adverbphrase", "adverbPhrase"],
    ["head", "head"],
    ["fragment", "fragment"],
  ]);
  const KNOWN_ELEMENTS = new Set(ELEMENT_MAP.values());

  function normalizeElement(value) {
    const text = String(value || "").trim().toLowerCase().replace(/[\s_-]+/g, "");
    return ELEMENT_MAP.get(text) || "unknown";
  }

  function elementLabel(role) {
    return {
      subject: "主语",
      predicate: "谓语",
      object: "宾语",
      predicative: "表语",
      directObject: "直接宾语",
      indirectObject: "间接宾语",
      objectComplement: "宾语补足语",
      subjectComplement: "主语补足语",
      attribute: "定语",
      adverbial: "状语",
      appositive: "同位语",
      parenthesis: "独立成分",
      formalSubject: "形式主语",
      formalObject: "形式宾语",
      cognateObject: "关联宾语",
      vocative: "呼语",
      conjunction: "连词",
      nounPhrase: "名词短语",
      verbPhrase: "动词短语",
      prepositionalPhrase: "介词短语",
      adjectivePhrase: "形容词短语",
      adverbPhrase: "副词短语",
      head: "中心词",
      fragment: "片段",
    }[role] || "";
  }

  function normalizeLabel(label, fallback) {
    const allowed = new Set(["主语","谓语","宾语","表语","直接宾语","间接宾语","宾语补足语","主语补足语","定语","状语","同位语","独立成分","形式主语","形式宾语","关联宾语","呼语","连词","名词短语","动词短语","介词短语","形容词短语","副词短语","中心词","片段"]);
    return allowed.has(label) ? label : (fallback || "");
  }

  function normalizeSpaces(text) {
    return String(text || "").replace(/\s+/g, " ").trim();
  }

  function normalizeTriggerMode(value) {
    return value === TRIGGER_CLICK ? TRIGGER_CLICK : TRIGGER_AUTO;
  }

  function clamp(value, min, max) {
    return Math.min(max, Math.max(min, value));
  }

  function addSafeEventListener(target, type, listener, options) {
    try {
      target?.addEventListener?.(type, listener, options);
    } catch {
      if (options && typeof options === "object") {
        target?.addEventListener?.(type, listener, Boolean(options.capture));
      }
    }
  }

  async function sendMessage(action, payload = {}) {
    var error;
    try {
      const response = await chrome.runtime.sendMessage({ action, ...payload });
      if (!response?.ok) {
        error = new Error(response?.error?.message || "扩展后台没有返回有效响应。");
        error.code = response?.error?.code || "";
      } else {
        return response.result;
      }
    } catch (e) {
      error = e;
    }
    if (String(error?.message || "").includes("Extension context invalidated")) {
      cleanupInjectedUI();
    }
    throw error;
  }

  function cleanupInjectedUI() {
    if (translationTooltip) {
      translationTooltip.remove();
      translationTooltip = null;
      translationTooltipSentence = null;
    }
    document.getElementById("egc-page-annotation-style")?.remove();
    for (const el of document.querySelectorAll(".egc-sentence, .egc-translation, .egc-part, .egc-nested-panel")) {
      el.classList.remove("egc-sentence", "egc-translation", "egc-part", "egc-nested-panel");
      el.style.cursor = "";
      el.style.textDecorationLine = "";
      el.style.textDecorationStyle = "";
      el.style.textDecorationColor = "";
      el.style.textUnderlineOffset = "";
    }
    document.documentElement.classList.remove(ROOT_CLASS);
  }

  function installStyles() {
    if (document.getElementById("egc-page-annotation-style")) return;
    const style = document.createElement("style");
    style.id = "egc-page-annotation-style";
    style.textContent = `
      .${ROOT_CLASS} .${SENTENCE_CLASS} {
        cursor: help !important;
        text-decoration-line: underline;
        text-decoration-style: dotted;
        text-decoration-color: rgba(92, 201, 176, 0.5);
        text-underline-offset: 0.18em;
      }

      .${ROOT_CLASS} .${SENTENCE_CLASS}:hover {
        background: rgba(23, 107, 92, 0.08);
      }

      .${ROOT_CLASS} .${SENTENCE_CLASS}.egc-loading {
        background: rgba(242, 180, 80, 0.2);
      }

      .${ROOT_CLASS} .${SENTENCE_CLASS}.egc-annotated {
        text-decoration: none;
        overflow-wrap: anywhere;
      }

      .${ROOT_CLASS} .${SENTENCE_CLASS}.egc-annotated > span:not(.${PART_CLASS}) {
        display: inline;
        padding-bottom: 1px;
        margin: 0 1px;
      }


      .${ROOT_CLASS} .${PART_CLASS} {
        position: relative;
        display: inline-block;
        max-width: 100%;
        margin: 0 0.03em calc(0.9em + var(--egc-label-stack-space, 0em));
        padding: 0 0.02em 0.08em;
        border-bottom: 2px solid currentColor;
        line-height: 1.15;
        white-space: normal;
        overflow-wrap: anywhere;
        word-break: normal;
        vertical-align: baseline;
      }

      .${ROOT_CLASS} .${PART_CLASS}.egc-has-nested {
        cursor: pointer;
        padding-bottom: 0.16em;
      }

      .${ROOT_CLASS} .${PART_CLASS}.egc-has-nested:focus-visible {
        outline: 2px solid currentColor;
        outline-offset: 0.12em;
        border-radius: 0.16em;
      }

      .${ROOT_CLASS} .${PART_CLASS}.egc-nested-active {
        background: color-mix(in srgb, currentColor 10%, transparent);
      }

      .${ROOT_CLASS} .${PART_CLASS}.egc-nested-part {
        border-bottom-width: 1px;
      }

      /* Wrapper spans (annotateTextNode): display:contents avoids flex/gird/>* */
      .${ROOT_CLASS}.${HIDE_UL_CLASS} .${SENTENCE_CLASS}[data-egc-wrapper="true"] {
        display: contents !important;
        text-decoration: none !important;
        cursor: inherit !important;
      }
      .${ROOT_CLASS}.${HIDE_UL_CLASS} .${SENTENCE_CLASS}[data-egc-wrapper="true"]:hover {
        background: transparent !important;
      }
      .${ROOT_CLASS}.${HIDE_UL_CLASS} .${SENTENCE_CLASS}[data-egc-wrapper="true"].egc-loading {
        background: transparent !important;
      }
      /* Block-level sentences (annotateSentenceLikeElements): keep layout, rm decoration */
      .${ROOT_CLASS}.${HIDE_UL_CLASS} .${SENTENCE_CLASS}:not([data-egc-wrapper]) {
        text-decoration: none !important;
        cursor: inherit !important;
      }
      .${ROOT_CLASS}.${HIDE_UL_CLASS} .${SENTENCE_CLASS}:not([data-egc-wrapper]):hover {
        background: transparent !important;
      }
      .${ROOT_CLASS}.${HIDE_UL_CLASS} .${PART_CLASS} {
        display: contents !important;
        border-bottom: none !important;
        margin: 0 !important;
        padding: 0 !important;
      }
      .${ROOT_CLASS}.${HIDE_UL_CLASS} .${PART_LABEL_CLASS} {
        display: none !important;
      }
      .${ROOT_CLASS}.${HIDE_UL_CLASS} .${TRANSLATION_CLASS} {
        display: none !important;
      }
      .${ROOT_CLASS}.${HIDE_UL_CLASS} .${NESTED_PANEL_CLASS} {
        display: none !important;
      }
      /* Segmentation mode colored spans (no .egc-part, inline border-bottom) */
      .${ROOT_CLASS}.${HIDE_UL_CLASS} .${SENTENCE_CLASS} > span {
        border-bottom: none !important;
        cursor: inherit !important;
      }


      .${ROOT_CLASS} .${PART_CLASS}.egc-nested-collapsed > .egc-nested-part {
        display: none;
      }

      .${ROOT_CLASS} .${PART_LABEL_CLASS} {
        position: absolute;
        left: 50%;
        top: calc(100% + 0.22em);
        transform: translateX(-50%) translateX(var(--egc-label-shift, 0px)) translateY(var(--egc-label-lane-offset, 0em));
        white-space: nowrap;
        max-width: calc(100vw - 12px);
        overflow: hidden;
        text-overflow: ellipsis;
        font-size: 0.68em;
        line-height: 1;
        color: currentColor;
        opacity: 0.9;
        overscroll-behavior: contain;
        pointer-events: auto;
        user-select: none;
      }

      .${ROOT_CLASS} .${PART_CLASS}.egc-has-nested > .${PART_LABEL_CLASS}::after {
        content: " · 展开";
        color: #a0b8c8;
        font-size: 0.86em;
      }

      .${ROOT_CLASS} .${PART_CLASS}.egc-nested-active > .${PART_LABEL_CLASS}::after {
        content: " · 当前";
      }

      .${ROOT_CLASS} .egc-element-subject { color: #5ba0d8; }
      .${ROOT_CLASS} .egc-element-predicate { color: #d4709f; }
      .${ROOT_CLASS} .egc-element-object { color: #5aad5e; }
      .${ROOT_CLASS} .egc-element-complement { color: #a87ee6; }
      .${ROOT_CLASS} .egc-element-adverbial { color: #e08a30; }
      .${ROOT_CLASS} .egc-element-attribute { color: #30a8b8; }
      .${ROOT_CLASS} .egc-element-appositive { color: #ad8a30; }
      .${ROOT_CLASS} .egc-element-conjunction { color: #b8856a; }
      .${ROOT_CLASS} .egc-element-marker { color: #c97a7a; }
      .${ROOT_CLASS} .egc-element-other { color: #6ea8b0; }
      .${ROOT_CLASS} .egc-element-nounphrase { color: #5ba0d8; }
      .${ROOT_CLASS} .egc-element-verbphrase { color: #d4709f; }
      .${ROOT_CLASS} .egc-element-prepositionalphrase { color: #a87ee6; }
      .${ROOT_CLASS} .egc-element-adjectivephrase { color: #e08a30; }
      .${ROOT_CLASS} .egc-element-adverbphrase { color: #30a8b8; }
      .${ROOT_CLASS} .egc-element-head { color: #c97a7a; }
      .${ROOT_CLASS} .egc-element-fragment { color: #6ea8b0; }

      .${ROOT_CLASS} .${TRANSLATION_CLASS} {
        display: none;
        box-sizing: border-box;
        width: auto;
        max-width: min(720px, calc(100vw - 24px));
        margin: 0.25em 0 0.65em;
        padding: 0.45em 0.6em;
        border-left: 3px solid #176b5c;
        border-radius: 6px;
        background: rgba(92, 201, 176, 0.08);
        color: #d4dcee;
        font-size: 0.92em;
        line-height: 1.45;
        white-space: normal;
        overflow: visible;
        overflow-wrap: anywhere;
        word-break: break-word;
      }

      .${ROOT_CLASS} .${TRANSLATION_CLASS}.egc-hidden {
        display: none;
      }

      .${ROOT_CLASS} .${NESTED_PANEL_CLASS} {
        display: block;
        box-sizing: border-box;
        width: auto;
        max-width: min(760px, calc(100vw - 24px));
        margin: 0.35em 0 0.75em;
        padding: 0.62em 0.72em 0.32em;
        border: 1px solid rgba(74, 85, 104, 0.4);
        border-left: 3px solid #9aa4b8;
        border-radius: 7px;
        background: rgba(24, 27, 40, 0.98);
        color: #e8edf5;
        font: 14px/1.55 system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
        white-space: normal;
        overflow: visible;
        overflow-wrap: anywhere;
        word-break: break-word;
      }

      .${ROOT_CLASS} .${NESTED_PANEL_CLASS}.egc-hidden {
        display: none;
      }

      .${ROOT_CLASS} .egc-nested-analysis-head {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 0.7em;
        margin-bottom: 0.35em;
      }

      .${ROOT_CLASS} .egc-nested-analysis-title {
        min-width: 0;
        color: #c8d0e0;
        font-size: 0.88em;
        font-weight: 700;
      }

      .${ROOT_CLASS} .egc-nested-analysis-close {
        all: unset;
        box-sizing: border-box;
        flex: 0 0 auto;
        width: 1.7em;
        height: 1.7em;
        border-radius: 999px;
        color: #9aa4b8;
        cursor: pointer;
        font: 700 1em/1.7 system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
        text-align: center;
      }

      .${ROOT_CLASS} .egc-nested-analysis-close:hover,
      .${ROOT_CLASS} .egc-nested-analysis-close:focus-visible {
        background: rgba(154, 164, 184, 0.14);
        outline: none;
      }

      .${ROOT_CLASS} .egc-nested-analysis-detail {
        display: block;
        color: #9aa4b8;
        font-size: 0.9em;
      }

      .${ROOT_CLASS} .egc-nested-analysis-sentence {
        display: block;
        padding-bottom: calc(0.3em + var(--egc-label-stack-space, 0em));
        color: #d4dcee;
        line-height: 1.7;
      }

      .${ROOT_CLASS} .egc-nested-analysis-detail {
        margin-top: 0.2em;
      }

      .${ROOT_CLASS} .${TRANSLATION_CLASS}.egc-error {
        border-left-color: #f97066;
        background: rgba(249, 112, 102, 0.1);
        color: #f97066;
      }

      .${ROOT_CLASS} .${SENTENCE_CLASS}.egc-collapsed .${TRANSLATION_CLASS} {
        display: none;
      }

      .${TRANSLATION_TOOLTIP_CLASS} {
        position: fixed;
        z-index: 2147483647;
        display: none;
        box-sizing: border-box;
        width: min(820px, calc(100vw - 16px));
        max-height: min(72vh, 720px);
        overflow-y: auto;
        overflow-x: hidden;
        scrollbar-gutter: stable;
        padding: 0 0.85em 0.75em 0.85em;
        border: 1px solid rgba(148, 163, 184, 0.32);
        border-radius: 8px;
        background: linear-gradient(180deg, rgba(18, 20, 31, 0.56), rgba(24, 27, 40, 0.52));
        box-shadow: 0 18px 46px rgba(0, 0, 0, 0.5), inset 0 1px 0 rgba(255, 255, 255, 0.06);
        backdrop-filter: blur(1.5px) saturate(0.95);
        -webkit-backdrop-filter: blur(1.5px) saturate(0.95);
        will-change: transform;
        color: #ffffff;
        font: 14px/1.55 system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
        white-space: normal;
        overflow-wrap: anywhere;
        pointer-events: auto;
      }

      .${TRANSLATION_TOOLTIP_CLASS}.egc-visible {
        display: block;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-content {
        color: #fff;
      }
      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-list li,
      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-text,
      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-segment-text,
      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-segment-detail {
        color: #fff;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-section + .egc-tooltip-section {
        margin-top: 0.65em;
        padding-top: 0.58em;
        border-top: 1px solid rgba(74, 85, 104, 0.35);
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-priority-section {
        padding: 0;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-title {
        margin-bottom: 0.28em;
        color: #5cc9b0;
        font-size: 0.86em;
        font-weight: 700;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-text {
        margin: 0;
        overflow-wrap: anywhere;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-row {
        display: grid;
        grid-template-columns: max-content minmax(0, 1fr);
        gap: 0.45em;
        align-items: baseline;
        padding-left: calc(var(--egc-tooltip-depth, 0) * 1.1em);
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-row + .egc-tooltip-row {
        margin-top: 0.24em;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-row-body {
        display: flex;
        flex-direction: column;
        gap: 0.2em;
        min-width: 0;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-row-text {
        display: block;
        color: #ffffff;
        overflow-wrap: anywhere;
        white-space: normal;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-row-text .egc-speak-group {
        margin-left: 0.25em;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-row-detail {
        display: flex;
        flex-direction: column;
        gap: 0.15em;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-detail-line {
        color: #ffffff;
        font-size: 0.92em;
        line-height: 1.45;
        overflow-wrap: anywhere;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-detail-label {
        color: #f5a623;
        font-weight: 650;
        margin-right: 0.3em;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-detail-content {
        color: #ffffff;
        overflow-wrap: anywhere;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-subsection {
        margin-top: 0.48em;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-subsection .egc-tooltip-title {
        margin-bottom: 0.22em;
        color: #5cc9b0;
        font-size: 0.82em;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-label {
        max-width: min(18em, 42vw);
        overflow: visible;
        color: #f5a623;
        font-weight: 650;
        overflow-wrap: anywhere;
        text-overflow: clip;
        white-space: normal;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-word-level-badge {
        display: inline-block;
        margin-left: 6px;
        padding: 0 5px;
        border-radius: 3px;
        background: #b8e6dc;
        color: #004d3a;
        font-size: 0.72em;
        font-weight: 650;
        line-height: 1.5;
        vertical-align: middle;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-row-body {
        min-width: 0;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-word-row {
        display: grid;
        grid-template-columns: auto 1fr;
        gap: 0 12px;
        padding: 3px 0;
        align-items: start;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-word-left {
        display: flex;
        flex-direction: column;
        gap: 2px;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-word-row .egc-tooltip-label {
        display: flex;
        flex-direction: column;
        gap: 0.15em;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-word-actions {
        display: flex;
        align-items: center;
        gap: 3px;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-segment-card {
        margin-left: calc(var(--egc-tooltip-depth, 0) * 1em);
        padding: 0.18em 0 0.18em 0.65em;
        border-left: 2px solid rgba(92, 201, 176, 0.3);
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-segment-card + .egc-tooltip-segment-card {
        margin-top: 0.22em;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-segment-head {
        display: grid;
        grid-template-columns: max-content minmax(0, 1fr);
        gap: 0.5em;
        align-items: baseline;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-segment-label {
        color: #f5a623;
        font-size: 0.86em;
        font-weight: 700;
        white-space: nowrap;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-segment-text {
        min-width: 0;
        color: #e8edf5;
        font-weight: 650;
        overflow-wrap: anywhere;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-segment-detail {
        margin-top: 0.2em;
        color: #eceff4;
        font-size: 0.93em;
        overflow-wrap: anywhere;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-list {
        margin: 0;
        padding-left: 1.25em;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-list li + li {
        margin-top: 0.18em;
      }

      .egc-speak-group {
        display: inline-flex;
        align-items: center;
        gap: 0.2em;
        margin-left: 0.35em;
        vertical-align: middle;
      }

      .egc-speak-button {
        all: unset;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-width: 1.65em;
        height: 1.4em;
        padding: 0 0.35em;
        border-radius: 4px;
        border: 1px solid rgba(0, 229, 255, 0.2);
        background: transparent;
        color: rgba(0, 229, 255, 0.7);
        cursor: pointer;
        font-size: 0.65em;
        font-weight: 700;
        line-height: 1;
        letter-spacing: 0.04em;
        transition: background 0.15s, border-color 0.15s, color 0.15s;
      }

      .egc-speak-button:hover,
      .egc-speak-button:focus-visible {
        background: rgba(0, 229, 255, 0.1);
        border-color: rgba(0, 229, 255, 0.4);
        color: #00e5ff;
        outline: none;
      }

      .egc-speak-button:active {
        background: rgba(0, 229, 255, 0.18);
      }

      .egc-speak-button.egc-speaking {
        background: rgba(0, 229, 255, 0.15);
        border-color: rgba(0, 229, 255, 0.5);
        color: #00e5ff;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-chat-btn {
        display: block;
        width: auto;
        min-width: 130px;
        margin: 0 auto;
        padding: 5px 20px;
	        line-height: 1;
        font-size: 0.88em;
        font-weight: 600;
        letter-spacing: 0.01em;
        cursor: pointer;
        background: linear-gradient(135deg, #0d2137 0%, #1a3a5c 100%);
        color: #00e5ff;
        border: 1px solid rgba(0, 229, 255, 0.25);
        border-radius: 8px;
        text-align: center;
        transition: opacity 0.15s, background 0.15s, border-color 0.15s;
      }
      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-chat-btn:hover {
        background: linear-gradient(135deg, #0f2d4f 0%, #1f4a74 100%);
        border-color: rgba(0, 229, 255, 0.5);
      }
      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-chat-btn:active {
        background: linear-gradient(135deg, #081a2d 0%, #122c47 100%);
      }
      .egc-quota-banner {
        all: initial;
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        z-index: 2147483647;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 12px;
        padding: 12px 20px;
        background: #fffbeb;
        border-bottom: 1px solid #fde68a;
        box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        font: 14px/1.5 system-ui, -apple-system, sans-serif;
        color: #92400e;
      }
      .egc-quota-banner span {
        all: initial;
        font-family: system-ui, -apple-system, sans-serif;
        font-size: 14px;
        color: #92400e;
      }
      .egc-quota-banner a {
        all: initial;
        cursor: pointer;
        font-family: system-ui, -apple-system, sans-serif;
        font-size: 14px;
        font-weight: 600;
        color: #2563eb;
        text-decoration: underline;
      }
      .egc-quota-banner a:hover {
        color: #1d4ed8;
      }
      .egc-quota-banner .egc-quota-close {
        all: initial;
        cursor: pointer;
        font-family: system-ui, -apple-system, sans-serif;
        font-size: 18px;
        color: #92400e;
        opacity: 0.6;
        margin-left: 8px;
      }
      .egc-quota-banner .egc-quota-close:hover {
        opacity: 1;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-chat-btn:disabled {
        opacity: 0.5;
        cursor: default;
      }

      /* ── 浮窗主题控制 ──────────────────────── */

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-chat-row {
        position: relative;
	        margin-top: -3px;
        margin-bottom: 2px;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-tooltip-header-btn {
        all: unset;
        position: absolute;
        right: 0;
        top: 50%;
        transform: translateY(-50%);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 30px;
        height: 30px;
        border-radius: 6px;
        background: rgba(255, 255, 255, 0.1);
        color: #ffffff;
        font-size: 15px;
        line-height: 1;
        cursor: pointer;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-theme-panel {
        display: none;
        padding: 8px 10px;
        margin-bottom: 6px;
        border-radius: 6px;
        background: rgba(0, 0, 0, 0.2);
      }
      .${TRANSLATION_TOOLTIP_CLASS} .egc-theme-panel.egc-open {
        display: block;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-theme-label {
        display: block;
        color: rgba(255, 255, 255, 0.55);
        font-size: 0.7em;
        margin-bottom: 4px;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-theme-presets {
        display: flex;
        gap: 6px;
        margin-bottom: 8px;
        align-items: center;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-theme-preset {
        width: 24px;
        height: 24px;
        border-radius: 50%;
        border: 2px solid transparent;
        cursor: pointer;
        transition: border-color 0.15s, transform 0.15s;
        box-sizing: border-box;
      }
      .${TRANSLATION_TOOLTIP_CLASS} .egc-theme-preset:hover {
        transform: scale(1.18);
      }
      .${TRANSLATION_TOOLTIP_CLASS} .egc-theme-preset.egc-active {
        border-color: #ffffff;
        transform: scale(1.12);
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-theme-row {
        display: flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 5px;
      }
      .${TRANSLATION_TOOLTIP_CLASS} .egc-theme-row:last-child {
        margin-bottom: 0;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-theme-row label {
        color: rgba(255, 255, 255, 0.6);
        font-size: 0.72em;
        min-width: 3em;
        flex-shrink: 0;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-theme-row input[type="range"] {
        -webkit-appearance: none;
        appearance: none;
        flex: 1;
        height: 4px;
        border-radius: 2px;
        background: rgba(255, 255, 255, 0.2);
        outline: none;
        cursor: pointer;
        min-width: 0;
      }
      .${TRANSLATION_TOOLTIP_CLASS} .egc-theme-row input[type="range"]::-webkit-slider-thumb {
        -webkit-appearance: none;
        appearance: none;
        width: 13px;
        height: 13px;
        border-radius: 50%;
        background: #ffffff;
        border: 0;
        cursor: pointer;
      }

      .${TRANSLATION_TOOLTIP_CLASS} .egc-theme-row .egc-theme-value {
        color: rgba(255, 255, 255, 0.55);
        font-size: 0.68em;
        min-width: 2.8em;
        text-align: right;
        font-variant-numeric: tabular-nums;
      }
`;
    document.documentElement.appendChild(style);
  }

  function showQuotaBanner(msg) {
    if (document.querySelector(".egc-quota-banner")) return;
    var banner = document.createElement("div");
    banner.className = "egc-quota-banner";
    banner.innerHTML =
      '<span>' + (msg || '免费额度已用完') + '</span>' +
      '<a href="https://giiiiiithub.github.io/BeyondTranslationSite" target="_blank" rel="noopener noreferrer">获取 Token →</a>' +
      '<span class="egc-quota-close">&times;</span>';
    banner.querySelector(".egc-quota-close").addEventListener("click", function () {
      banner.remove();
    });
    document.documentElement.appendChild(banner);
  }
})();

