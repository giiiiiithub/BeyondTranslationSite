(function () {
  function renderMarkdown(target, source) {
    target.textContent = "";
    const blocks = parseBlocks(String(source || ""));
    for (const block of blocks) {
      target.appendChild(renderBlock(block));
    }
  }

  function parseBlocks(source) {
    const lines = source.replace(/\r\n?/g, "\n").split("\n");
    const blocks = [];
    let index = 0;

    while (index < lines.length) {
      const line = lines[index];

      if (!line.trim()) {
        index += 1;
        continue;
      }

      const fence = line.match(/^```([^\s`]*)\s*$/);
      if (fence) {
        const content = [];
        index += 1;
        while (index < lines.length && !/^```\s*$/.test(lines[index])) {
          content.push(lines[index]);
          index += 1;
        }
        if (index < lines.length) index += 1;
        blocks.push({ type: "code", language: fence[1], text: content.join("\n") });
        continue;
      }

      const heading = line.match(/^(#{1,6})\s+(.+)$/);
      if (heading) {
        blocks.push({ type: "heading", level: heading[1].length, text: heading[2].trim() });
        index += 1;
        continue;
      }

      const table = parseTable(lines, index);
      if (table) {
        blocks.push(table.block);
        index = table.nextIndex;
        continue;
      }

      if (/^[-*_]{3,}\s*$/.test(line.trim())) {
        blocks.push({ type: "rule" });
        index += 1;
        continue;
      }

      if (/^>\s?/.test(line)) {
        const items = [];
        while (index < lines.length && /^>\s?/.test(lines[index])) {
          items.push(lines[index].replace(/^>\s?/, ""));
          index += 1;
        }
        blocks.push({ type: "quote", text: items.join("\n") });
        continue;
      }

      const unordered = line.match(/^\s*([-*+])\s+(.+)$/);
      if (unordered) {
        const items = [];
        while (index < lines.length) {
          const item = lines[index].match(/^\s*([-*+])\s+(.+)$/);
          if (!item) break;
          items.push(item[2].trim());
          index += 1;
        }
        blocks.push({ type: "list", ordered: false, items });
        continue;
      }

      const ordered = line.match(/^\s*\d+[.)]\s+(.+)$/);
      if (ordered) {
        const items = [];
        while (index < lines.length) {
          const item = lines[index].match(/^\s*\d+[.)]\s+(.+)$/);
          if (!item) break;
          items.push(item[1].trim());
          index += 1;
        }
        blocks.push({ type: "list", ordered: true, items });
        continue;
      }

      const paragraph = [line.trim()];
      index += 1;
      while (index < lines.length && lines[index].trim() && !isBlockStart(lines, index)) {
        paragraph.push(lines[index].trim());
        index += 1;
      }
      blocks.push({ type: "paragraph", text: paragraph.join(" ") });
    }

    return blocks;
  }

  function renderBlock(block) {
    switch (block.type) {
      case "heading": {
        const heading = document.createElement(`h${block.level}`);
        appendInline(heading, block.text);
        return heading;
      }
      case "code": {
        const pre = document.createElement("pre");
        const code = document.createElement("code");
        if (block.language) code.dataset.language = block.language;
        code.textContent = block.text;
        pre.appendChild(code);
        return pre;
      }
      case "quote": {
        const quote = document.createElement("blockquote");
        const lines = block.text.split("\n");
        lines.forEach((line, index) => {
          if (index > 0) quote.appendChild(document.createElement("br"));
          appendInline(quote, line);
        });
        return quote;
      }
      case "list": {
        const list = document.createElement(block.ordered ? "ol" : "ul");
        for (const item of block.items) {
          const li = document.createElement("li");
          appendInline(li, item);
          list.appendChild(li);
        }
        return list;
      }
      case "table":
        return renderTable(block);
      case "rule":
        return document.createElement("hr");
      default: {
        const paragraph = document.createElement("p");
        appendInline(paragraph, block.text);
        return paragraph;
      }
    }
  }

  function parseTable(lines, startIndex) {
    if (startIndex + 1 >= lines.length) return null;

    const headerCells = splitTableRow(lines[startIndex]);
    const separatorCells = splitTableRow(lines[startIndex + 1]);
    if (!headerCells || !separatorCells || !isSeparatorRow(separatorCells)) return null;

    const rawRows = [];
    let nextIndex = startIndex + 2;
    while (nextIndex < lines.length && lines[nextIndex].trim()) {
      const cells = splitTableRow(lines[nextIndex]);
      if (!cells) break;
      rawRows.push(cells);
      nextIndex += 1;
    }

    const columnCount = Math.max(
      headerCells.length,
      separatorCells.length,
      ...rawRows.map((row) => row.length)
    );

    return {
      block: {
        type: "table",
        headers: normalizeCells(headerCells, columnCount),
        align: normalizeAlign(separatorCells, columnCount),
        rows: rawRows.map((row) => normalizeCells(row, columnCount))
      },
      nextIndex
    };
  }

  function splitTableRow(line) {
    if (!hasTableDelimiter(line)) return null;

    const cells = [];
    let cell = "";
    let codeFenceLength = 0;
    let sawDelimiter = false;

    for (let index = 0; index < line.length; index += 1) {
      const char = line[index];

      if (char === "`") {
        const runLength = countRun(line, index, "`");
        if (codeFenceLength === 0) {
          codeFenceLength = runLength;
        } else if (codeFenceLength === runLength) {
          codeFenceLength = 0;
        }
        cell += line.slice(index, index + runLength);
        index += runLength - 1;
        continue;
      }

      if (char === "\\" && line[index + 1] === "|") {
        cell += "|";
        index += 1;
        continue;
      }

      if (char === "|" && codeFenceLength === 0) {
        cells.push(cell.trim());
        cell = "";
        sawDelimiter = true;
        continue;
      }

      cell += char;
    }

    if (!sawDelimiter) return null;
    cells.push(cell.trim());

    if (cells[0] === "" && startsWithTablePipe(line)) {
      cells.shift();
    }

    if (cells[cells.length - 1] === "" && endsWithTablePipe(line)) {
      cells.pop();
    }

    return cells;
  }

  function hasTableDelimiter(line) {
    let codeFenceLength = 0;
    for (let index = 0; index < line.length; index += 1) {
      const char = line[index];

      if (char === "`") {
        const runLength = countRun(line, index, "`");
        if (codeFenceLength === 0) {
          codeFenceLength = runLength;
        } else if (codeFenceLength === runLength) {
          codeFenceLength = 0;
        }
        index += runLength - 1;
        continue;
      }

      if (char === "\\" && line[index + 1] === "|") {
        index += 1;
        continue;
      }

      if (char === "|" && codeFenceLength === 0) {
        return true;
      }
    }
    return false;
  }

  function startsWithTablePipe(line) {
    return line.trimStart().startsWith("|");
  }

  function endsWithTablePipe(line) {
    const trimmed = line.trimEnd();
    if (!trimmed.endsWith("|")) return false;
    return !endsWithEscapedPipe(trimmed);
  }

  function endsWithEscapedPipe(text) {
    let slashCount = 0;
    for (let index = text.length - 2; index >= 0 && text[index] === "\\"; index -= 1) {
      slashCount += 1;
    }
    return slashCount % 2 === 1;
  }

  function countRun(text, startIndex, char) {
    let index = startIndex;
    while (index < text.length && text[index] === char) {
      index += 1;
    }
    return index - startIndex;
  }

  function isSeparatorRow(cells) {
    return cells.length > 0 && cells.every((cell) => /^:?-{3,}:?$/.test(cell.trim()));
  }

  function normalizeCells(cells, columnCount) {
    const normalized = cells.slice(0, columnCount);
    while (normalized.length < columnCount) {
      normalized.push("");
    }
    return normalized;
  }

  function normalizeAlign(cells, columnCount) {
    return normalizeCells(cells, columnCount).map((cell) => {
      const value = cell.trim();
      const starts = value.startsWith(":");
      const ends = value.endsWith(":");
      if (starts && ends) return "center";
      if (ends) return "right";
      if (starts) return "left";
      return "";
    });
  }

  function renderTable(block) {
    const wrapper = document.createElement("div");
    wrapper.className = "table-scroll";

    const table = document.createElement("table");
    const thead = document.createElement("thead");
    const headerRow = document.createElement("tr");
    block.headers.forEach((cell, index) => {
      const th = document.createElement("th");
      applyAlignment(th, block.align[index]);
      appendInline(th, cell);
      headerRow.appendChild(th);
    });
    thead.appendChild(headerRow);
    table.appendChild(thead);

    const tbody = document.createElement("tbody");
    for (const row of block.rows) {
      const tr = document.createElement("tr");
      row.forEach((cell, index) => {
        const td = document.createElement("td");
        applyAlignment(td, block.align[index]);
        appendInline(td, cell);
        tr.appendChild(td);
      });
      tbody.appendChild(tr);
    }
    table.appendChild(tbody);
    wrapper.appendChild(table);
    return wrapper;
  }

  function applyAlignment(cell, alignment) {
    if (alignment) {
      cell.style.textAlign = alignment;
    }
  }

  function isBlockStart(lines, index) {
    const line = lines[index];
    return (
      /^(#{1,6})\s+/.test(line) ||
      /^```/.test(line) ||
      /^\s*([-*+])\s+/.test(line) ||
      /^\s*\d+[.)]\s+/.test(line) ||
      /^>\s?/.test(line) ||
      /^[-*_]{3,}\s*$/.test(line.trim()) ||
      parseTable(lines, index) !== null
    );
  }

  function appendInline(parent, text) {
    parent.appendChild(renderInline(String(text || "")));
  }

  function renderInline(text) {
    const fragment = document.createDocumentFragment();
    let rest = text;

    while (rest) {
      const token = nextToken(rest);
      if (!token) {
        fragment.appendChild(document.createTextNode(rest));
        break;
      }

      if (token.index > 0) {
        fragment.appendChild(document.createTextNode(rest.slice(0, token.index)));
      }

      fragment.appendChild(createInlineNode(token));
      rest = rest.slice(token.index + token.raw.length);
    }

    return fragment;
  }

  function nextToken(text) {
    const candidates = [
      matchToken(text, "code", /`([^`]+)`/),
      matchToken(text, "link", /\[([^\]]+)]\(([^)\s]+)\)/),
      matchToken(text, "bold", /(\*\*|__)([\s\S]+?)\1/),
      matchToken(text, "strike", /~~([\s\S]+?)~~/),
      matchToken(text, "italic", /(^|[^*_])([*_])([^*_\n]+)\2/)
    ].filter(Boolean);

    candidates.sort((left, right) => left.index - right.index || left.raw.length - right.raw.length);
    return candidates[0] || null;
  }

  function matchToken(text, type, pattern) {
    const match = pattern.exec(text);
    if (!match) return null;

    if (type === "italic") {
      return {
        type,
        index: match.index + match[1].length,
        raw: match[0].slice(match[1].length),
        text: match[3]
      };
    }

    return {
      type,
      index: match.index,
      raw: match[0],
      text: type === "bold" ? match[2] : match[1],
      href: type === "link" ? match[2] : ""
    };
  }

  function createInlineNode(token) {
    if (token.type === "code") {
      const code = document.createElement("code");
      code.textContent = token.text;
      return code;
    }

    if (token.type === "link") {
      const href = safeHref(token.href);
      if (!href) return document.createTextNode(token.raw);
      const anchor = document.createElement("a");
      anchor.href = href;
      anchor.target = "_blank";
      anchor.rel = "noreferrer";
      appendInline(anchor, token.text);
      return anchor;
    }

    const element = document.createElement(
      token.type === "bold" ? "strong" : token.type === "strike" ? "s" : "em"
    );
    appendInline(element, token.text);
    return element;
  }

  function safeHref(value) {
    try {
      const url = new URL(value);
      if (url.protocol === "http:" || url.protocol === "https:" || url.protocol === "mailto:") {
        return url.href;
      }
    } catch {
      return "";
    }
    return "";
  }

  window.MarkdownRenderer = { render: renderMarkdown };
})();
