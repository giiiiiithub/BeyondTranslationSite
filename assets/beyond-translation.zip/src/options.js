const form = document.getElementById("settingsForm");
const statusBox = document.getElementById("statusBox");
const siteRuleInput = document.getElementById("siteRuleInput");
const siteRulesList = document.getElementById("siteRulesList");
const siteRuleStatus = document.getElementById("siteRuleStatus");
const addSiteRuleButton = document.getElementById("addSiteRuleButton");
const fields = {
  pageAnnotationTrigger: document.getElementById("pageAnnotationTrigger"),
  pageAnnotationPrepositionFocus: document.getElementById("pageAnnotationPrepositionFocus"),
  pageAnnotationTranslationOnly: document.getElementById("pageAnnotationTranslationOnly"),
  pageAnnotationExamples: document.getElementById("pageAnnotationExamples"),
  pageAnnotationTone: document.getElementById("pageAnnotationTone"),
  pageAnnotationGrammarAnalysis: document.getElementById("pageAnnotationGrammarAnalysis"),
  pageAnnotationSegmentation: document.getElementById("pageAnnotationSegmentation"),
  pageAnnotationWordLevels: document.querySelectorAll('input[name="pageAnnotationWordLevels"]'),
};

let siteRules = [];
let declinedSiteRules = [];
let pendingDialog = null;

document.addEventListener("DOMContentLoaded", () => {
  init().catch(showError);
});

async function init() {
  form.addEventListener("submit", saveSettings);
  addSiteRuleButton.addEventListener("click", addSiteRuleFromForm);

  document.addEventListener("keydown", (event) => {
    if (event.ctrlKey && event.shiftKey && event.key === "D") {
      event.preventDefault();
      downloadBtLogs();
    }
  });

  await loadSettings();
  await handlePendingSiteEnable();
  loadUsageStats();
  setInterval(loadUsageStats, 300000);

  // Detect new pending domains when the options page is already open
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes.pendingSiteEnable?.newValue) {
      handlePendingSiteEnable().catch(console.error);
    }
  });
}

async function loadSettings() {
  const settings = await sendMessage("getSettings");
  writeForm(settings);
}

function writeForm(settings) {
  for (const [key, element] of Object.entries(fields)) {
    if (element instanceof NodeList) {
      if (key === "pageAnnotationWordLevels") {
        const selected = Array.isArray(settings[key]) ? settings[key] : [];
        for (const cb of element) {
          cb.checked = selected.includes(cb.value);
        }
      } else {
        for (const radio of element) {
          radio.checked = radio.value === settings[key];
        }
      }
    } else if (element.type === "checkbox") {
      element.checked = settings[key] !== false;
    } else {
      element.value = settings[key] ?? "";
    }
  }
  siteRules = normalizeSiteRules(settings.pageAnnotationSiteRules);
  declinedSiteRules = normalizeSiteRules(settings.pageAnnotationDeclinedSiteRules);
  renderSiteRules();
}

function readForm() {
  return {
    pageAnnotationTrigger: fields.pageAnnotationTrigger.value,
    pageAnnotationPrepositionFocus: fields.pageAnnotationPrepositionFocus.checked,
    pageAnnotationTranslationOnly: fields.pageAnnotationTranslationOnly.checked,
    pageAnnotationExamples: fields.pageAnnotationExamples.checked,
    pageAnnotationTone: fields.pageAnnotationTone.checked,
    pageAnnotationGrammarAnalysis: fields.pageAnnotationGrammarAnalysis.checked,
    pageAnnotationSegmentation: fields.pageAnnotationSegmentation.checked,
    pageAnnotationWordLevels: readCheckboxGroupValues(fields.pageAnnotationWordLevels),
    pageAnnotationSiteRules: siteRules,
    pageAnnotationDeclinedSiteRules: declinedSiteRules
  };
}

function addSiteRuleFromForm() {
  hideSiteRuleStatus();
  const scopeEl = document.getElementById("siteRuleScope");
  const scope = scopeEl?.value === "page" ? "page" : "domain";

  const pattern = scope === "page"
    ? normalizeSitePageUrl(siteRuleInput.value)
    : normalizeSiteDomain(siteRuleInput.value);

  if (!pattern) {
    showSiteRuleError(scope === "page" ? "请输入有效的网址。" : "请输入有效的网站域名。");
    return;
  }

  const origins = scope === "page"
    ? [getOriginWildcard(pattern)]
    : [`https://${pattern}/*`, `https://*.${pattern}/*`];

  chrome.permissions.request({ origins }).then((granted) => {
    if (!granted) {
      showSiteRuleError("授权被拒绝。");
      return;
    }

    const rule = { scope, pattern, addedAt: new Date().toISOString() };
    const key = buildSiteRuleKey(rule);
    siteRules = [rule, ...siteRules.filter((item) => buildSiteRuleKey(item) !== key)];
    declinedSiteRules = declinedSiteRules.filter((item) => buildSiteRuleKey(item) !== key);
    siteRuleInput.value = "";
    renderSiteRules();

    sendMessage("saveSiteRules", { siteRules, declinedSiteRules }).catch(showError);
  }).catch(showError);
}

function getOriginWildcard(url) {
  try { return new URL(url).origin + "/*"; } catch { return `https://${url}/*`; }
}

function removeSiteRuleFromList(event) {
  const button = event.target?.closest?.("[data-site-rule-key]");
  if (!button) return;

  const key = button.dataset.siteRuleKey;
  siteRules = siteRules.filter((rule) => buildSiteRuleKey(rule) !== key);
  renderSiteRules();

  sendMessage("saveSiteRules", { siteRules, declinedSiteRules }).catch(showError);
}

function renderSiteRules() {
  siteRulesList.textContent = "";
  if (!siteRules.length) {
    const empty = document.createElement("div");
    empty.className = "site-rules-empty";
    empty.textContent = "还没有启用任何网站。";
    siteRulesList.appendChild(empty);
    return;
  }

  for (const rule of siteRules) {
    const row = document.createElement("div");
    row.className = "site-rule-row";

    const text = document.createElement("div");
    text.className = "site-rule-text";
    const pattern = document.createElement("strong");
    pattern.textContent = rule.pattern;

    const scopeLabel = document.createElement("span");
    scopeLabel.className = "site-rule-scope";
    scopeLabel.textContent = rule.scope === "page" ? "仅本页" : "整个网站";
    scopeLabel.title = "点击切换范围";
    scopeLabel.addEventListener("click", () => toggleSiteRuleScope(rule));

    text.append(pattern, scopeLabel);

    const removeButton = document.createElement("button");
    removeButton.type = "button";
    removeButton.className = "secondary";
    removeButton.textContent = "移除";
    removeButton.dataset.siteRuleKey = buildSiteRuleKey(rule);

    row.append(text, removeButton);
    siteRulesList.appendChild(row);
  }
}

function toggleSiteRuleScope(rule) {
  const newScope = rule.scope === "page" ? "domain" : "page";
  let newPattern;
  if (newScope === "domain") {
    newPattern = normalizeSiteDomain(rule.pattern);
  } else {
    newPattern = normalizeSitePageUrl(rule.pattern);
  }
  if (!newPattern || newPattern === rule.pattern) return;

  const newKey = buildSiteRuleKey({ scope: newScope, pattern: newPattern });
  if (siteRules.some((r) => r !== rule && buildSiteRuleKey(r) === newKey)) return;

  rule.scope = newScope;
  rule.pattern = newPattern;
  renderSiteRules();
  sendMessage("saveSiteRules", { siteRules, declinedSiteRules }).catch(showError);
}

function normalizeSiteRules(value) {
  const seen = new Set();
  const rules = [];
  for (const item of Array.isArray(value) ? value : []) {
    const source = item && typeof item === "object" ? item : {};
    const scope = source.scope === "page" ? "page" : "domain";
    const rawPattern = source.pattern || source.host || source.domain || source.value;
    const pattern = scope === "page" ? normalizeSitePageUrl(rawPattern) : normalizeSiteDomain(rawPattern);
    if (!pattern) continue;

    const rule = { scope, pattern, addedAt: normalizeIsoDate(source.addedAt) };
    const key = buildSiteRuleKey(rule);
    if (seen.has(key)) continue;
    seen.add(key);
    rules.push(rule);
  }
  return rules;
}

function normalizeSiteDomain(value) {
  const text = String(value || "").trim();
  if (!text) return "";

  const withProtocol = /^[a-z][a-z0-9+.-]*:\/\//i.test(text) ? text : `https://${text}`;
  try {
    return getRegistrableDomain(normalizeHostname(new URL(withProtocol).hostname));
  } catch {
    const host = text
      .replace(/^[a-z][a-z0-9+.-]*:\/\//i, "")
      .split(/[/?#]/, 1)[0]
      .replace(/:\d+$/, "");
    return getRegistrableDomain(normalizeHostname(host));
  }
}

function normalizeSitePageUrl(value) {
  const text = String(value || "").trim();
  if (!text) return "";
  const withProtocol = /^[a-z][a-z0-9+.-]*:\/\//i.test(text) ? text : `https://${text}`;
  try {
    const url = new URL(withProtocol);
    if (!url.hostname) return "";
    return url.href.replace(/\/$/, "");
  } catch {
    return "";
  }
}

function normalizeHostname(value) {
  const host = String(value || "")
    .trim()
    .toLowerCase()
    .replace(/^\.+|\.+$/g, "");
  if (!host || /\s/.test(host)) return "";
  if (host === "localhost") return host;
  if (/^\d{1,3}(?:\.\d{1,3}){3}$/.test(host)) return host;
  if (!/^[a-z0-9.-]+$/.test(host)) return "";
  if (host.includes("..")) return "";
  const labels = host.split(".");
  if (labels.some((label) => !label || label.startsWith("-") || label.endsWith("-"))) return "";
  return host;
}

function getRegistrableDomain(host) {
  const normalizedHost = normalizeHostname(host);
  if (!normalizedHost || isIpAddress(normalizedHost) || !normalizedHost.includes(".")) {
    return normalizedHost;
  }

  const labels = normalizedHost.split(".").filter(Boolean);
  if (labels.length <= 2) return normalizedHost;

  const suffixLength = getPublicSuffixLabelCount(labels);
  return labels.slice(-Math.min(labels.length, suffixLength + 1)).join(".");
}

function getPublicSuffixLabelCount(labels) {
  const last = labels[labels.length - 1] || "";
  const secondLast = labels[labels.length - 2] || "";
  if (last.length === 2 && secondLast.length <= 3) {
    return 2;
  }
  return 1;
}

function isIpAddress(host) {
  return /^\d{1,3}(?:\.\d{1,3}){3}$/.test(host) || host.includes(":");
}

function normalizeIsoDate(value) {
  const text = String(value || "").trim();
  const time = Date.parse(text);
  return Number.isFinite(time) ? new Date(time).toISOString() : new Date().toISOString();
}

function buildSiteRuleKey(rule) {
  return (rule.scope || "domain") + "::" + (rule.pattern || "");
}

function readCheckboxGroupValues(nodeList) {
  const values = [];
  for (const cb of nodeList) {
    if (cb.checked) values.push(cb.value);
  }
  return values;
}

function readIntegerField(field) {
  const text = String(field.value || "").trim();
  return text ? Number(text) : "";
}

async function saveSettings(event) {
  event.preventDefault();
  setBusy(true);
  hideStatus();

  try {
    await sendMessage("saveSettings", { settings: readForm() });
    showSuccess("设置已保存。");
  } catch (error) {
    showError(error);
  } finally {
    setBusy(false);
  }
}

async function saveSiteRules() {
  hideStatus();

  // Find new domains by comparing with current saved settings
  const settings = await sendMessage("getSettings");
  const currentPatterns = new Set(
    (settings.pageAnnotationSiteRules || []).map(r => r.pattern)
  );
  const newDomains = siteRules.filter(r => !currentPatterns.has(r.pattern));
  const origins = newDomains.map(r => {
    if (r.scope === "page") return getOriginWildcard(r.pattern);
    return `https://${r.pattern}/*`;
  });

  const doSave = () => {
    sendMessage("saveSiteRules", { siteRules, declinedSiteRules })
      .then(() => showSuccess("网站规则已保存。"))
      .catch(showError);
  };

  if (origins.length === 0) {
    doSave();
    return;
  }

  // Show a modal dialog for new domains only. The permission request is
  // deferred to the dialog button so Chrome gets a fresh click gesture.
  const dialog = document.createElement("dialog");
  dialog.style.border = "1px solid var(--line)";
  dialog.style.borderRadius = "10px";
  dialog.style.padding = "20px 24px";
  dialog.style.maxWidth = "420px";
  dialog.style.boxShadow = "0 8px 32px rgba(0,0,0,0.18)";
  dialog.innerHTML =
    `<p style="margin:0 0 12px;font-weight:650">为新网站授权</p>` +
    `<p style="margin:0 0 12px;color:var(--muted);font-size:12px">需要为新添加的网站授予权限才能启用标注：</p>` +
    origins.map((o) => `<strong style="display:block;margin-bottom:4px">${o}</strong>`).join("") +
    `<div style="display:flex;gap:8px;justify-content:flex-end;margin-top:16px">` +
      `<button id="permDialogCancel" class="secondary" style="min-height:28px;font-size:12px">取消</button>` +
      `<button id="permDialogGrant" style="min-height:28px;font-size:12px">授权并保存</button>` +
    `</div>`;
  document.body.appendChild(dialog);
  dialog.showModal();

  dialog.querySelector("#permDialogCancel").addEventListener("click", () => {
    dialog.close();
    dialog.remove();
  });
  dialog.querySelector("#permDialogGrant").addEventListener("click", function grantHandler() {
    dialog.close();
    chrome.permissions.request({ origins }).then((granted) => {
      if (!granted) {
        showError(new Error("授权被拒绝，无法启用网站标注。"));
        return;
      }
      doSave();
    }).catch((error) => {
      showError(new Error("权限请求出错: " + (error?.message || error)));
    });
    dialog.remove();
  });
}

// clearUsageStats removed — 统计页只展示余额

function setBusy(value) {
  for (const button of form.querySelectorAll("button")) {
    button.disabled = value;
  }
}

function showSuccess(message) {
  statusBox.className = "status-box success";
  statusBox.textContent = message;
}

function showError(error) {
  statusBox.className = "status-box error";
  statusBox.textContent = error?.message || String(error);
}

function hideStatus() {
  statusBox.className = "status-box hidden";
  statusBox.textContent = "";
}

function showSiteRuleSuccess(message) {
  siteRuleStatus.className = "status-box success";
  siteRuleStatus.textContent = message;
}

function showSiteRuleError(message) {
  siteRuleStatus.className = "status-box error";
  siteRuleStatus.textContent = message;
}

function hideSiteRuleStatus() {
  siteRuleStatus.className = "status-box hidden";
  siteRuleStatus.textContent = "";
}

async function sendMessage(action, payload = {}) {
  const response = await chrome.runtime.sendMessage({ action, ...payload });
  if (!response?.ok) {
    throw new Error(response?.error?.message || "扩展后台没有返回有效响应。");
  }
  return response.result;
}

async function loadUsageStats() {
  var section = document.getElementById("usageStatsSection");
  if (!section) return;
  const status = await sendMessage("getLicenseStatus");
  if (status.plan_type === "token") {
    section.style.display = "";
    updateStat("statTokenBalance", formatTokenRatio(status.token_remaining, status.token_quota));
  } else {
    section.style.display = "none";
  }
}

function updateStat(id, value, format) {
  var el = document.getElementById(id);
  if (!el) return;
  var card = el.closest(".stat-card");
  if (value == null) {
    if (card) card.style.display = "none";
    return;
  }
  if (card) card.style.display = "";
  el.textContent = format ? format(value) : String(value);
}

function formatTokenCount(value) {
  const num = Number(value);
  if (!Number.isFinite(num)) return "0";
  if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
  if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
  return String(Math.floor(num));
}

function formatTokenRatio(remaining, total) {
  return `${formatTokenCount(remaining)} / ${formatTokenCount(total)}`;
}

async function downloadBtLogs() {
  try {
    const logs = await sendMessage("getBtLogs");
    const blob = new Blob([logs], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `bt-logs-${Date.now()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
    showSuccess("日志已下载。");
  } catch (error) {
    showError(error);
  }
}

async function handlePendingSiteEnable() {
  const data = await chrome.storage.local.get("pendingSiteEnable");
  const domain = data.pendingSiteEnable;
  if (!domain) return;

  await chrome.storage.local.remove("pendingSiteEnable");

  const pattern = normalizeSiteDomain(domain);
  if (!pattern) {
    siteRuleInput.value = domain;
    showSiteRuleError(`无效的域名：${domain}`);
    return;
  }

  if (pendingDialog) {
    pendingDialog.close();
    pendingDialog.remove();
    pendingDialog = null;
  }

  // Show a modal dialog so the user can authorize with one click.
  // chrome.permissions.request needs both a user gesture and an extension
  // page context — the dialog button provides both.
  const dialog = document.createElement("dialog");
  dialog.style.border = "1px solid var(--line)";
  dialog.style.borderRadius = "10px";
  dialog.style.padding = "20px 24px";
  dialog.style.maxWidth = "400px";
  dialog.style.boxShadow = "0 8px 32px rgba(0,0,0,0.18)";
  dialog.innerHTML =
    `<p style="margin:0 0 8px;font-weight:650">启用标注</p>` +
    `<p style="margin:0 0 4px;color:var(--muted);font-size:12px">为以下网站授予标注权限：</p>` +
    `<p style="margin:0 0 16px;font-weight:650;font-size:15px">${pattern}</p>` +
    `<div style="display:flex;gap:8px;justify-content:flex-end">` +
      `<button id="permDlgCancel" class="secondary" style="min-height:28px;font-size:12px">取消</button>` +
      `<button id="permDlgGrant" style="min-height:28px;font-size:12px;background:var(--accent);color:#fff" autofocus>授权</button>` +
    `</div>`;
  document.body.appendChild(dialog);
  pendingDialog = dialog;
  dialog.showModal();

  dialog.querySelector("#permDlgCancel").addEventListener("click", () => {
    pendingDialog = null;
    dialog.close();
    dialog.remove();
    siteRuleInput.value = pattern;
    siteRuleInput.focus();
    showSiteRuleSuccess(`已在输入框中填入域名，点击「添加」可手动授权。`);
  });

  dialog.querySelector("#permDlgGrant").addEventListener("click", function grantHandler() {
    pendingDialog = null;
    dialog.close();
    dialog.remove();

    const scopeEl = document.getElementById("siteRuleScope");
    const scope = scopeEl?.value === "domain" ? "domain" : "page";
    const finalPattern = scope === "page" ? normalizeSitePageUrl("https://" + pattern) : pattern;
    const origins = scope === "page"
      ? [getOriginWildcard(finalPattern)]
      : [`https://${pattern}/*`, `https://*.${pattern}/*`];
    chrome.permissions.request({ origins }).then((granted) => {
      if (!granted) {
        showSiteRuleError("授权被拒绝。");
        return;
      }

      const scopeEl = document.getElementById("siteRuleScope");
      const scope = scopeEl?.value === "domain" ? "domain" : "page";
      const finalPattern = scope === "page" ? normalizeSitePageUrl("https://" + pattern) : pattern;
      const rule = {
        scope,
        pattern: finalPattern || pattern,
        addedAt: new Date().toISOString()
      };
      const key = buildSiteRuleKey(rule);
      siteRules = [rule, ...siteRules.filter((item) => buildSiteRuleKey(item) !== key)];
      declinedSiteRules = declinedSiteRules.filter((item) => buildSiteRuleKey(item) !== key);
      renderSiteRules();
      showSiteRuleSuccess(`已为 ${pattern} 启用标注。`);

      sendMessage("saveSiteRules", { siteRules, declinedSiteRules }).catch(showError);
    }).catch((error) => {
      showSiteRuleError(error?.message || "授权请求失败。");
    });
  });
}
