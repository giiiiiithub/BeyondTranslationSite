import {
  DEFAULT_SETTINGS,
  LICENSE_API_BASE,
  LLM_API_BASE,
  PAGE_ANNOTATION_LIMITS,
  analyzeText,
  annotateSentence as fcallAnnotateSentence,
  annotateSentences as fcallAnnotateSentences,
  followUp as fcallFollowUp,
  normalizePageAnnotationSiteRules,
  redactSensitiveText,
  resolveSettings,
  segmentSentence as fcallSegmentSentence,
  segmentSentences as fcallSegmentSentences,
  setTokenInfoHandler,
  setQuotaErrorHandler
} from "./provider.js";

const MENU_ID = "english-grammar-analysis";
const SITE_TOGGLE_MENU_ID = "toggle-page-annotation-site";
const ACTIVE_SESSION_KEY = "activeSession";
const SETTINGS_KEY = "settings";
const USAGE_STATS_KEY = "usageStatsV1";
const SENTENCE_ANNOTATION_CACHE_KEY = "sentenceAnnotationCacheV1";
const SENTENCE_ANNOTATION_CACHE_LIMIT = 600;
const SENTENCE_ANNOTATION_SCHEMA_VERSION = "sentence-components-v19";
const SENTENCE_SEGMENTATION_CACHE_KEY = "sentenceSegmentationCacheV1";
const SENTENCE_SEGMENTATION_CACHE_LIMIT = 300;
const SENTENCE_SEGMENTATION_SCHEMA_VERSION = "sentence-seg-v1";
const REGISTERED_SCRIPT_PREFIX = "bt-page-annotation-";
const LICENSE_KEY = "licenseV1";
const DEVICE_ID_KEY = "btDeviceId";
const sentenceAnnotationInFlight = new Map();
const segmentationInFlight = new Map();
const contextMenuReadyIds = new Set();
let sentenceAnnotationCache = null;
let segmentationCache = null;
let siteToggleContextMenuTimer = 0;
let _freeQuotaExhausted = false;
const _btLogs = [];
function btLog(...args) {
  const msg = args.join(" ");
  const entry = `[${new Date().toISOString().slice(11, 23)}] ${msg}`;
  _btLogs.push(entry);
}
function getBtLogs() { return _btLogs.join("\n"); }

// ── 设备 ID（免费用户 Token 额度追踪用）───────────
var _deviceIdPromise = null;

async function getDeviceId() {
  if (!_deviceIdPromise) {
    _deviceIdPromise = resolveDeviceId();
  }
  return _deviceIdPromise;
}

async function resolveDeviceId() {
  try {
    const data = await chrome.storage.local.get(DEVICE_ID_KEY);
    if (data[DEVICE_ID_KEY]) {
      chrome.storage.sync.set({ [DEVICE_ID_KEY]: data[DEVICE_ID_KEY] }).catch(() => {});
      return data[DEVICE_ID_KEY];
    }
    // 尝试从 sync 恢复（跨设备同步或 local 被清时）
    const syncData = await chrome.storage.sync.get(DEVICE_ID_KEY);
    if (syncData[DEVICE_ID_KEY]) {
      await chrome.storage.local.set({ [DEVICE_ID_KEY]: syncData[DEVICE_ID_KEY] });
      return syncData[DEVICE_ID_KEY];
    }
    var id = crypto.randomUUID();
    await Promise.all([
      chrome.storage.local.set({ [DEVICE_ID_KEY]: id }),
      chrome.storage.sync.set({ [DEVICE_ID_KEY]: id })
    ]);
    return id;
  } catch (e) {
    _deviceIdPromise = null;  // 失败时重置，下次重试
    throw e;
  }
}

chrome.runtime.onInstalled.addListener((details) => {
  setupExtension().catch(console.error);
});

chrome.runtime.onStartup.addListener(() => {
  setupExtension().catch(console.error);
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === MENU_ID) {
    openPanelFromUserGesture(tab).catch(console.error);
    handleSelection(info, tab).catch(console.error);
    return;
  }

  if (info.menuItemId === SITE_TOGGLE_MENU_ID) {
    toggleSiteRuleForContext(info, tab).catch(console.error);
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  handleMessage(message, sender)
    .then((result) => sendResponse({ ok: true, result }))
    .catch((error) => sendResponse({ ok: false, error: serializeError(error) }));
  return true;
});

chrome.contextMenus.onShown?.addListener((info, tab) => {
  updateSiteToggleContextMenu(info, tab).catch(() => {});
});

chrome.tabs?.onActivated?.addListener(() => {
  queueSiteToggleContextMenuUpdate();
});

chrome.tabs?.onUpdated?.addListener((tabId, changeInfo) => {
  if (changeInfo.url || changeInfo.status === "complete") {
    queueSiteToggleContextMenuUpdate();
  }
});

chrome.windows?.onFocusChanged?.addListener((windowId) => {
  if (windowId === chrome.windows.WINDOW_ID_NONE) return;
  queueSiteToggleContextMenuUpdate();
});

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === "local" && changes[SETTINGS_KEY]) {
    queueSiteToggleContextMenuUpdate();
  }
});

async function setupExtension() {
  await restrictStorageAccess();
  setTokenInfoHandler(async (tokenInfo) => {
    if (!tokenInfo || tokenInfo.error) return;
    try {
      const license = await getLicenseState();
      if (license && license.plan_type === "token" && tokenInfo.token_remaining != null) {
        license.tokens_used = (license.token_quota || 0) - tokenInfo.token_remaining;
        license.last_sync_at = Date.now();
        await saveLicenseState(license);
      }
      // 免费用户成功请求时重置额度耗尽标记（新的一天自然重置）
      if (tokenInfo.mode === "free" && tokenInfo.token_remaining != null) {
        _freeQuotaExhausted = tokenInfo.token_remaining <= 0;
        var set = { _quotaExhausted: tokenInfo.token_remaining <= 0 };
        if (tokenInfo.token_remaining <= 0) set._quotaExhaustedMsg = '免费额度已用完';
        await chrome.storage.local.set(set);
      }
      // 每次 token 信息更新都通知面板刷新
      notifyLicenseUpdate();
    } catch (e) { /* ignore */ }
  });
  setQuotaErrorHandler(async (code, msg) => {
    if (code === "000002") {
      // 从后端拉真实状态，不自己篡改
      const license = await getLicenseState();
      if (license && license.activation_code) {
        await syncLicense(license);
      }
    } else if (code === "000001") {
      // 免费额度耗尽。但若用户已有有效激活码，说明是激活前的在途请求
      // 产生的过期错误，不应覆盖已激活状态。
      const license = await getLicenseState();
      var hasValidLicense = license && license.plan_type === "token"
        && (license.token_quota - license.tokens_used) > 0;
      if (!hasValidLicense) {
        _freeQuotaExhausted = true;
        await chrome.storage.local.set({ _quotaExhausted: true, _quotaExhaustedMsg: msg || '免费额度已用完' });
      }
    }
    notifyQuotaExhausted();
  });
  await setupContextMenu();
  queueSiteToggleContextMenuUpdate();
  if (chrome.sidePanel?.setPanelBehavior) {
    await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
  }
  try {
    const settings = await getSettings();
    await syncContentScriptRegistration(settings.pageAnnotationSiteRules);
  } catch (error) {
    btLog("Failed to sync content script registration", error);
  }
}

async function restrictStorageAccess() {
  if (!chrome.storage?.local?.setAccessLevel) return;
  await chrome.storage.local.setAccessLevel({ accessLevel: "TRUSTED_CONTEXTS" }).catch(() => {});
}

async function setupContextMenu() {
  await removeAllContextMenus();
  contextMenuReadyIds.clear();
  await ensureContextMenu(MENU_ID);
  await ensureContextMenu(SITE_TOGGLE_MENU_ID);
}

async function handleSelection(info, tab) {
  const text = String(info.selectionText || "").trim();
  if (!text) return;

  const session = {
    id: crypto.randomUUID(),
    text,
    sourceUrl: tab?.url || "",
    pageTitle: tab?.title || "",
    createdAt: new Date().toISOString(),
    status: "pending",
    analysis: ""
  };

  await chrome.storage.local.set({ [ACTIVE_SESSION_KEY]: session });
  await notifyPanel({ type: "selection-ready", session });
}

async function openPanelFromUserGesture(tab) {
  if (!chrome.sidePanel?.open) {
    await openFallbackWindow();
    return;
  }

  try {
    if (typeof tab?.windowId === "number") {
      await chrome.sidePanel.open({ windowId: tab.windowId });
      return;
    }

    if (typeof tab?.id === "number") {
      await chrome.sidePanel.open({ tabId: tab.id });
      return;
    }
  } catch (error) {
    console.warn("Failed to open side panel, falling back to popup window.", error);
  }

  await openFallbackWindow();
}

async function openPanelWithAnalysis(payload, sender) {
  const session = {
    id: crypto.randomUUID(),
    text: payload?.sentence || "",
    analysis: payload?.analysis || "",
    analysisData: payload?.analysisData || null,
    sourceUrl: payload?.sourceUrl || "",
    pageTitle: payload?.pageTitle || "",
    createdAt: new Date().toISOString(),
    status: payload?.analysis ? "completed" : "pending"
  };
  await chrome.storage.local.set({ [ACTIVE_SESSION_KEY]: session });
  const screenW = payload?.screenAvailWidth || 1920;
  const screenH = payload?.screenAvailHeight || 1080;
  const screenX = payload?.screenLeft || 0;
  const screenY = payload?.screenTop || 0;
  const width = Math.min(Math.max(600, Math.round(screenW * 0.56)), Math.round(screenW * 0.9));
  const height = Math.min(Math.max(640, Math.round(screenH * 0.72)), Math.round(screenH * 0.9));
  const left = screenX + Math.round((screenW - width) / 2);
  const top = screenY + Math.round((screenH - height) / 2);
  await chrome.windows.create({
    url: chrome.runtime.getURL("panel.html"),
    type: "popup", width, height, left, top, focused: true
  }).catch(() => {});
}

async function openFallbackWindow() {
  const url = chrome.runtime.getURL("panel.html");
  let width = 600, height = 760, left, top;
  try {
    const displays = await chrome.system.display?.getInfo().catch(() => []);
    if (displays?.length) {
      const primary = displays.find((d) => d.isPrimary) || displays[0];
      const wa = primary.workArea;
      width = Math.min(Math.max(600, Math.round(wa.width * 0.56)), Math.round(wa.width * 0.9));
      height = Math.min(Math.max(640, Math.round(wa.height * 0.72)), Math.round(wa.height * 0.9));
      left = wa.left + Math.round((wa.width - width) / 2);
      top = wa.top + Math.round((wa.height - height) / 2);
    }
  } catch {}
  await chrome.windows.create({
    url,
    type: "popup",
    width,
    height,
    left,
    top,
    focused: true
  });
}

async function openPanelForActivation(message, sender) {
  await chrome.storage.local.set({ pendingActivation: true });
  const tab = sender?.tab;
  if (tab?.windowId != null) {
    try { await chrome.sidePanel.open({ windowId: tab.windowId }); } catch (e) {}
    try { await chrome.sidePanel.open({ tabId: tab.id }); } catch (e) {}
  }
  await notifyPanel({ type: "guideActivation" });
}

async function notifyPanel(payload) {
  await chrome.runtime.sendMessage(payload).catch(() => {});
}

async function handleMessage(message, sender) {
  switch (message?.action) {
    case "getActiveSession":
      return getActiveSession();
    case "getSettings":
      assertExtensionPageSender(sender);
      return getSettings();
    case "getSettingsSummary":
      return getSettingsSummary(sender);
    case "saveSettings":
      assertExtensionPageSender(sender);
      return saveSettings(message.settings);
    case "resetSettings":
      assertExtensionPageSender(sender);
      return saveSettings(DEFAULT_SETTINGS);
    case "analyze":
      return analyzeSelection(message.sessionId, message.text);
    case "followUp":
      return answerFollowUp(message.payload);
    case "annotateSentence":
      return annotateSentence(message.sentence, sender);
    case "annotateSentences":
      return annotateSentences(message.sentences, sender);
    case "segmentSentences":
      return segmentSentences(message.sentences, sender);
    case "segmentSentence":
      return segmentSentence(message.sentence, sender);
    case "getUsageStats":
      assertExtensionPageSender(sender);
      return getUsageStats();
    case "saveSiteRules":
      assertExtensionPageSender(sender);
      return saveSiteRules(message.siteRules, message.declinedSiteRules);
    case "getBtLogs":
      return getBtLogs();
    case "clearUsageStats":
      assertExtensionPageSender(sender);
      return clearUsageStats();
    case "activateLicense":
      return activateLicense(message.activation_code, message.device_id);
    case "getLicenseStatus":
      return getLicenseStatus();
    case "refreshTokenBalance":
      return refreshTokenBalance();
    case "openPanelForActivation":
      return openPanelForActivation(message, sender);
    case "openPanelWithAnalysis":
      return openPanelWithAnalysis(message.payload, sender);
    default:
      throw new Error("未知的扩展消息。");
  }
}

function assertExtensionPageSender(sender) {
  if (isExtensionPageSender(sender)) return;
  throw new Error("该操作只能在扩展页面中执行。");
}

function isExtensionPageSender(sender) {
  const senderUrl = sender?.url || sender?.origin || "";
  if (!senderUrl) return false;

  try {
    return new URL(senderUrl).origin === new URL(chrome.runtime.getURL("")).origin;
  } catch {
    return false;
  }
}

async function getActiveSession() {
  const data = await chrome.storage.local.get(ACTIVE_SESSION_KEY);
  return data[ACTIVE_SESSION_KEY] || null;
}

// ── License ────────────────────────────────────

async function getLicenseState() {
  const data = await chrome.storage.local.get(LICENSE_KEY);
  return data[LICENSE_KEY] || null;
}

async function saveLicenseState(state) {
  await chrome.storage.local.set({ [LICENSE_KEY]: state });
}

async function getLicenseStatus() {
  const license = await getLicenseState();

  // Token 套餐
  if (license && license.plan_type === "token") {
    if (!license.last_sync_at || (Date.now() - license.last_sync_at > 60000)) {
      syncLicense(license).catch(() => {});
    }
    const tokenRemaining = Math.max(0, (license.token_quota || 0) - (license.tokens_used || 0));
    return {
      active: tokenRemaining > 0,
      plan_type: "token", plan_name: "Token 套餐",
      token_quota: license.token_quota || 0,
      tokens_used: license.tokens_used || 0,
      token_remaining: tokenRemaining,
      tokens_exhausted: tokenRemaining <= 0
    };
  }

  var data = await chrome.storage.local.get(["_quotaExhausted", "_quotaExhaustedMsg"]);
  return {
    active: false,
    free_quota_exhausted: !!data._quotaExhausted,
    free_quota_exhausted_msg: data._quotaExhaustedMsg || ''
  };
}

async function refreshTokenBalance() {
  const license = await getLicenseState();
  if (!license || !license.activation_code) return getLicenseStatus();
  await syncLicense(license);
  return getLicenseStatus();
}

async function syncLicense(localLicense) {
  if (!localLicense || !localLicense.activation_code) return;
  try {
    const resp = await fetch(LICENSE_API_BASE + "/api/verify-license", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ activation_code: localLicense.activation_code, device_id: await getDeviceId() })
    });
    const json = await resp.json();
    if (json.code === "000200") {
      var data = json.data;
      localLicense.last_sync_at = Date.now();
      localLicense.status = "active";
      localLicense.token_quota = data.token_quota || localLicense.token_quota;
      localLicense.tokens_used = data.tokens_used != null ? data.tokens_used : localLicense.tokens_used;
      await saveLicenseState(localLicense);
    } else if (json.code === "000002") {
      // Token 耗尽，保留状态用于展示
      const updated = { ...localLicense, tokens_used: localLicense.token_quota, last_sync_at: Date.now() };
      await saveLicenseState(updated);
    } else if (json.code === "001001" || json.code === "001002") {
      // 激活码不存在或已过期 → terminal，删除本地状态
      await chrome.storage.local.remove(LICENSE_KEY);
    }
    // 其他错误（网络抖动、FC 冷启动超时等）保留已有 license 状态，不做降级
  } catch (err) { /* 网络故障，下次再试 */ }
}

async function activateLicense(activationCode, deviceId) {
  const code = String(activationCode || "").trim();
  if (!code) throw new Error("激活码不能为空");
  const did = deviceId || await getDeviceId();
  const resp = await fetch(LICENSE_API_BASE + "/api/verify-license", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ activation_code: code, device_id: did })
  });
  const json = await resp.json();
  if (json.code === "000200") {
    const data = json.data;
    const state = {
      activation_code: code, plan_type: data.plan_type, status: "active",
      device_id: did, last_sync_at: Date.now()
    };
    state.token_quota = data.token_quota || 0;
    state.tokens_used = data.tokens_used || 0;
    await saveLicenseState(state);
    // 清除免费额度耗尽标记，避免路上请求的过期错误覆盖已激活状态
    await chrome.storage.local.remove(["_quotaExhausted", "_quotaExhaustedMsg"]).catch(() => {});
    _freeQuotaExhausted = false;
    return data;
  }
  var err = new Error(json.msg || "激活码无效或已过期");
  err.code = json.code || "";
  throw err;
}

// ── Settings ──────────────────────────────────

async function getSettings() {
  const data = await chrome.storage.local.get(SETTINGS_KEY);
  return resolveSettings(data[SETTINGS_KEY] || {});
}

async function getSettingsSummary(sender) {
  const settings = await getSettings();
  syncSiteToggleContextMenuForSender(sender).catch(() => {});
  const senderSite = getSenderSite(sender);
  const siteAllowed = senderSite.supported
    ? isPageAnnotationEnabledForSite(settings, senderSite.host)
    : isExtensionPageSender(sender);

  return {
    pageAnnotationEnabledForSite: siteAllowed,
    currentSite: senderSite.supported ? senderSite : null,
    pageAnnotationTrigger: settings.pageAnnotationTrigger || DEFAULT_SETTINGS.pageAnnotationTrigger,
    pageAnnotationBatchSize: settings.pageAnnotationBatchSize,
    pageAnnotationConcurrency: settings.pageAnnotationConcurrency,
    pageAnnotationMode: settings.pageAnnotationMode || "components",
    pageAnnotationPrepositionFocus: settings.pageAnnotationPrepositionFocus !== false,
    pageAnnotationWordLevels: settings.pageAnnotationWordLevels,
    pageAnnotationLimits: PAGE_ANNOTATION_LIMITS,
    llmBackend: LLM_API_BASE
  };
}

async function saveSettings(settings) {
  const normalized = resolveSettings(settings || {});
  await chrome.storage.local.set({ [SETTINGS_KEY]: normalized });
  await notifyPageAnnotationSettingsChanged();
  queueSiteToggleContextMenuUpdate();
  return { saved: true };
}

async function saveSiteRules(siteRules, declinedSiteRules) {
  const data = await chrome.storage.local.get(SETTINGS_KEY);
  const settings = resolveSettings(data[SETTINGS_KEY] || {});
  settings.pageAnnotationSiteRules = normalizePageAnnotationSiteRules(siteRules || []);
  settings.pageAnnotationDeclinedSiteRules = normalizePageAnnotationSiteRules(declinedSiteRules || []);
  await chrome.storage.local.set({ [SETTINGS_KEY]: settings });
  await notifyPageAnnotationSettingsChanged();
  queueSiteToggleContextMenuUpdate();
  await syncContentScriptRegistration(settings.pageAnnotationSiteRules);
  return { saved: true };
}

function queueSiteToggleContextMenuUpdate() {
  clearTimeout(siteToggleContextMenuTimer);
  siteToggleContextMenuTimer = setTimeout(() => {
    syncSiteToggleContextMenuForActiveTab().catch(() => {});
  }, 80);
}

async function syncSiteToggleContextMenuForActiveTab() {
  const tab = await getCurrentTab();
  await updateSiteToggleContextMenu({}, tab);
}

async function syncSiteToggleContextMenuForSender(sender) {
  if (!sender?.tab) return;
  await updateSiteToggleContextMenu({}, sender.tab);
}

async function updateSiteToggleContextMenu(info, tab) {
  const pageUrl = info?.pageUrl || info?.frameUrl || tab?.url || tab?.pendingUrl || "";
  let host = "";
  try { host = normalizeSiteHost(new URL(pageUrl).hostname); } catch { /* 忽略 */ }

  if (!host) {
    chrome.contextMenus.update(SITE_TOGGLE_MENU_ID, { enabled: true, title: "启用BeyondTranslation" }, () => {
      chrome.runtime.lastError;
    });
    chrome.contextMenus.refresh?.();
    return;
  }

  chrome.contextMenus.update(SITE_TOGGLE_MENU_ID, { enabled: true, title: "启用BeyondTranslation" }, () => {
    chrome.runtime.lastError;
  });
  chrome.contextMenus.refresh?.();

  const settings = await getSettings();
  const enabled = isPageAnnotationEnabledForSite(settings, host);
  await updateContextMenu(SITE_TOGGLE_MENU_ID, {
    enabled: true,
    title: `${enabled ? "关闭" : "启用"}BeyondTranslation`
  });
}

async function toggleSiteRuleForContext(info, tab) {
  const pageUrl = info?.pageUrl || info?.frameUrl || tab?.url || tab?.pendingUrl || "";
  let url;
  try { url = new URL(pageUrl); } catch { return; }
  const host = normalizeSiteHost(url.hostname);
  if (!host) return;
  const domain = getRegistrableDomain(host);

  const origins = [`https://${domain}/*`];
  let granted;
  try {
    granted = await chrome.permissions.request({ origins });
  } catch (error) {
    btLog("permissions.request failed", error);
    return;
  }
  if (!granted) return;

  const settings = await getSettings();
  const rules = normalizePageAnnotationSiteRules(settings.pageAnnotationSiteRules);
  const enabled = isPageAnnotationEnabledForSite(settings, host);

  if (enabled) {
    const nextRules = removeMatchingSiteRule(rules, host);
    const nextDeclinedRules = addSiteRule(settings.pageAnnotationDeclinedSiteRules, {
      scope: "domain",
      pattern: domain
    });
    await saveSettings({
      ...settings,
      pageAnnotationSiteRules: nextRules,
      pageAnnotationDeclinedSiteRules: nextDeclinedRules
    });
    await unregisterContentScriptForDomain(domain);
    await updateSiteToggleContextMenu(info, tab);
  } else {
    const nextRules = addSiteRule(rules, { scope: "domain", pattern: domain });
    const nextDeclinedRules = removeMatchingSiteRule(settings.pageAnnotationDeclinedSiteRules, host);
    await saveSiteRules(nextRules, nextDeclinedRules);
  }
}


async function notifyPageAnnotationSettingsChanged() {
  const tabs = await chrome.tabs.query({}).catch(() => []);
  await Promise.all((tabs || []).map(async (tab) => {
    await notifyPageAnnotationTab(tab);
  }));
}

async function notifyPageAnnotationTab(tab) {
  if (typeof tab?.id !== "number" || !isInjectablePageUrl(tab.url)) return;

  const message = { type: "pageAnnotationSettingsChanged" };
  const delivered = await chrome.tabs.sendMessage(tab.id, message).then(
    () => true,
    () => false
  );
  if (delivered) return;

  await injectPageAnnotationContentScript(tab.id);
  const ok = await chrome.tabs.sendMessage(tab.id, message).then(
    () => true,
    () => false
  );
  if (!ok) {
    chrome.tabs.reload(tab.id).catch(() => {});
  }
}

async function injectPageAnnotationContentScript(tabId) {
  if (!chrome.scripting?.executeScript) return;
  await chrome.scripting.executeScript({
    target: { tabId },
    files: ["src/page-annotation-content.js"]
  }).catch(() => {});
}

function isInjectablePageUrl(value) {
  try {
    const url = new URL(String(value || ""));
    return url.protocol === "http:" || url.protocol === "https:";
  } catch {
    return false;
  }
}

function scriptIdForDomain(domain, protocol) {
  return `${REGISTERED_SCRIPT_PREFIX}${domain}-${protocol}`;
}

async function unregisterContentScriptForDomain(domain) {
  const ids = ["https", "http"].map((p) => scriptIdForDomain(domain, p));
  await chrome.scripting.unregisterContentScripts({ ids }).catch(() => {});
}

async function syncContentScriptRegistration(rules) {
  const existing = await chrome.scripting.getRegisteredContentScripts().catch(() => []);
  const existingIds = new Set(existing.map((s) => s.id));
  const prefix = REGISTERED_SCRIPT_PREFIX;
  const targetIds = new Set();
  for (const rule of (Array.isArray(rules) ? rules : [])) {
    if (!rule?.pattern) continue;
    for (const protocol of ["https", "http"]) {
      targetIds.add(scriptIdForDomain(rule.pattern, protocol));
    }
  }

  const toRemove = [...existingIds].filter((id) => id.startsWith(prefix) && !targetIds.has(id));
  if (toRemove.length) {
    await chrome.scripting.unregisterContentScripts({ ids: toRemove }).catch(() => {});
  }

  for (const rule of (Array.isArray(rules) ? rules : [])) {
    if (!rule?.pattern) continue;
    for (const protocol of ["https", "http"]) {
      const id = scriptIdForDomain(rule.pattern, protocol);
      if (existingIds.has(id)) continue;

      const pattern = `${protocol}://${rule.pattern}/*`;
      const permitted = await chrome.permissions.contains({ origins: [pattern] }).catch(() => false);
      if (!permitted) continue;

      await chrome.scripting.registerContentScripts([{
        id,
        js: ["src/page-annotation-content.js"],
        matches: [pattern],
        runAt: "document_idle"
      }]).catch((error) => {
        if (/duplicate id/i.test(error?.message)) return;
        throw error;
      });
    }
  }
}

function addSiteRule(rules, rule) {
  const normalizedRules = normalizePageAnnotationSiteRules(rules);
  const normalizedRule = normalizePageAnnotationSiteRules([{ ...rule, addedAt: new Date().toISOString() }])[0];
  if (!normalizedRule) return normalizedRules;

  return [
    normalizedRule,
    ...normalizedRules.filter((item) => item.pattern !== normalizedRule.pattern)
  ];
}

function removeMatchingSiteRule(rules, host) {
  const matchingRule = getMatchingSiteRule(host, rules);
  if (!matchingRule) return normalizePageAnnotationSiteRules(rules);
  return normalizePageAnnotationSiteRules(rules).filter((rule) => (
    rule.pattern !== matchingRule.pattern
  ));
}

function isPageAnnotationEnabledForSite(settings, host) {
  return Boolean(getMatchingSiteRule(host, settings.pageAnnotationSiteRules));
}

function getMatchingSiteRule(host, rules) {
  const normalizedHost = normalizeSiteHost(host);
  if (!normalizedHost) return null;

  const normalizedRules = normalizePageAnnotationSiteRules(rules);
  return normalizedRules.find((rule) => siteRuleMatchesHost(rule, normalizedHost)) || null;
}

function siteRuleMatchesHost(rule, host) {
  if (!rule?.pattern) return false;
  return host === rule.pattern || host.endsWith(`.${rule.pattern}`);
}

function getSenderSite(sender) {
  return getSiteFromUrl(sender?.tab?.url || sender?.url || "");
}

function getSiteFromContext(info, tab) {
  const urls = [
    info?.pageUrl,
    info?.frameUrl,
    tab?.url,
    tab?.pendingUrl
  ];

  for (const url of urls) {
    const site = getSiteFromUrl(url || "");
    if (site.supported) return site;
  }

  return getSiteFromUrl("");
}

async function getCurrentTab() {
  const tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true }).catch(() => []);
  return tabs?.[0] || null;
}

function getSiteFromUrl(value) {
  const text = String(value || "").trim();
  if (!text) {
    return { supported: false, reason: "当前页面没有可识别的网址。" };
  }

  let url;
  try {
    url = new URL(text);
  } catch {
    return { supported: false, reason: "当前页面没有可识别的网址。" };
  }

  if (url.protocol !== "http:" && url.protocol !== "https:") {
    return { supported: false, reason: "当前页面不是普通网页，不能启用BeyondTranslation。" };
  }

  const host = normalizeSiteHost(url.hostname);
  if (!host) {
    return { supported: false, reason: "当前页面没有可识别的网站域名。" };
  }

  return {
    supported: true,
    host,
    domain: getRegistrableDomain(host),
    url: url.href
  };
}

function normalizeSiteHost(value) {
  return String(value || "")
    .trim()
    .toLowerCase()
    .replace(/^\.+|\.+$/g, "");
}

function getRegistrableDomain(host) {
  const normalizedHost = normalizeSiteHost(host);
  if (!normalizedHost || isIpAddress(normalizedHost) || !normalizedHost.includes(".")) {
    return normalizedHost;
  }

  const labels = normalizedHost.split(".").filter(Boolean);
  if (labels.length <= 2) return normalizedHost;

  const suffixLength = getPublicSuffixLabelCount(labels);
  return labels.slice(-Math.min(labels.length, suffixLength + 1)).join(".");
}

function getPublicSuffixLabelCount(labels) {
  const last = labels[labels.length - 1] || "";
  const secondLast = labels[labels.length - 2] || "";
  if (last.length === 2 && secondLast.length <= 3) {
    return 2;
  }
  return 1;
}

function isIpAddress(host) {
  return /^\d{1,3}(?:\.\d{1,3}){3}$/.test(host) || host.includes(":");
}

// ── LLM 调用（委托 FC 后端） ─────────────────

async function analyzeSelection(sessionId, text) {
  const selectedText = String(text || "").trim();
  if (!selectedText) {
    throw new Error("没有可分析的选中文本。");
  }

  const [license, deviceId] = await Promise.all([getLicenseState(), getDeviceId()]);
  const response = await analyzeText(selectedText, license?.activation_code, deviceId);
  const session = await getActiveSession();

  if (session && session.id === sessionId) {
    await chrome.storage.local.set({
      [ACTIVE_SESSION_KEY]: {
        ...session,
        status: "done",
        analysis: response.content,
        analysisData: null,
        updatedAt: new Date().toISOString()
      }
    });
  }

  return response;
}

async function answerFollowUp(payload = {}) {
  const selectedText = String(payload.selectedText || "").trim();
  const question = String(payload.question || "").trim();
  if (!selectedText) {
    throw new Error("没有原始选中文本上下文。");
  }
  if (!question) {
    throw new Error("追问内容不能为空。");
  }

  const [settings, license, deviceId] = await Promise.all([getSettings(), getLicenseState(), getDeviceId()]);
  return fcallFollowUp({
    selectedText,
    analysis: payload.analysis || "",
    history: payload.history || [],
    question
  }, license?.activation_code, deviceId, settings.pageAnnotationWordLevels);
}

async function annotateSentence(sentence, sender) {
  const text = normalizeAnnotationSentence(sentence);
  if (!text) {
    throw new Error("没有可划分的英文句子。");
  }

  const settings = await getSettings();
  assertPageAnnotationAllowed(settings, sender);

  const wordLevels = settings.pageAnnotationWordLevels;
  const [license, deviceId] = await Promise.all([getLicenseState(), getDeviceId()]);
  const results = await annotateSentencesWithCache(settings, [text], license?.activation_code, deviceId, wordLevels);
  return results[0];
}

async function annotateSentences(sentences, sender) {
  const texts = (Array.isArray(sentences) ? sentences : [])
    .map((sentence) => normalizeAnnotationSentence(sentence))
    .filter(Boolean);
  if (!texts.length) {
    return [];
  }

  const settings = await getSettings();
  assertPageAnnotationAllowed(settings, sender);
  btLog(`background receive: ${texts.length} sentences, batchSize=${settings.pageAnnotationBatchSize}, concurrency=${settings.pageAnnotationConcurrency}`);
  const wordLevels = settings.pageAnnotationWordLevels;
  const [license, deviceId] = await Promise.all([getLicenseState(), getDeviceId()]);
  return annotateSentencesWithCache(settings, texts, license?.activation_code, deviceId, wordLevels);
}

function assertPageAnnotationAllowed(settings, sender) {
  if (isExtensionPageSender(sender)) return;

  const site = getSenderSite(sender);
  if (!site.supported || !isPageAnnotationEnabledForSite(settings, site.host)) {
    throw new Error("当前网站未启用网页句子成分划分。");
  }
}

async function annotateSentencesWithCache(settings, texts, activationCode, deviceId, wordLevels) {
  const uniqueTexts = Array.from(new Set(texts.map((text) => normalizeAnnotationSentence(text)).filter(Boolean)));
  const resultsByText = new Map();
  const missing = [];

  for (const text of uniqueTexts) {
    const cacheKey = await buildSentenceAnnotationCacheKey(settings, text, wordLevels);
    const cached = await getCachedSentenceAnnotation(cacheKey);
    if (cached) {
      resultsByText.set(text, cached);
      continue;
    }

    const inFlight = sentenceAnnotationInFlight.get(cacheKey);
    if (inFlight) {
      missing.push({ text, cacheKey, inFlight });
      continue;
    }

    missing.push({ text, cacheKey, inFlight: null });
  }

  const waitingForExisting = missing.filter((entry) => entry.inFlight);
  const pending = missing.filter((entry) => !entry.inFlight);
  const batchSize = getSentenceAnnotationBatchSize(settings);
  const chunks = chunkSentences(pending, batchSize);
  if (pending.length) btLog(`cache: ${uniqueTexts.length - pending.length} hits, ${pending.length} pending, chunked into ${chunks.length} (batchSize=${batchSize}): ${chunks.map(c => c.length).join(",")}`);
  else btLog(`cache: all ${uniqueTexts.length} hits, no model request`);

  await Promise.all([
    ...waitingForExisting.map(async (item) => {
      resultsByText.set(item.text, await item.inFlight);
    }),
    runWithConcurrency(chunks, getSentenceAnnotationConcurrency(settings), async (chunk) => {
      const fresh = chunk.filter((item) => !sentenceAnnotationInFlight.get(item.cacheKey));
      const alreadyRunning = chunk.filter((item) => sentenceAnnotationInFlight.get(item.cacheKey));

      const alreadyRunningResults = Promise.all(alreadyRunning.map(async (item) => {
        resultsByText.set(item.text, await sentenceAnnotationInFlight.get(item.cacheKey));
      }));
      if (!fresh.length) {
        await alreadyRunningResults;
        return;
      }

      // Call FC with the fresh sentences
      const sentences = fresh.map((item) => item.text);
      const chunkPromise = fcallAnnotateSentences(sentences, activationCode, deviceId, wordLevels);

      for (const [index, item] of fresh.entries()) {
        const itemPromise = chunkPromise
          .then((results) => results[index] || buildFallbackAnnotate(item.text, "批量结果缺少该句。"))
          .then(async (result) => {
            await setCachedSentenceAnnotation(item.cacheKey, result);
            return result;
          })
          .finally(() => {
            sentenceAnnotationInFlight.delete(item.cacheKey);
          });
        sentenceAnnotationInFlight.set(item.cacheKey, itemPromise);
      }

      const [chunkResults] = await Promise.all([
        Promise.all(fresh.map((item) => sentenceAnnotationInFlight.get(item.cacheKey))),
        alreadyRunningResults
      ]);
      for (const [index, item] of fresh.entries()) {
        resultsByText.set(item.text, chunkResults[index]);
      }
    })
  ]);

  return texts.map((text) => resultsByText.get(normalizeAnnotationSentence(text)) || buildFallbackAnnotate(text, "没有生成结果。"));
}

function buildFallbackAnnotate(sentence, error) {
  return {
    sentence,
    fallback: true,
    translation: "",
    segments: [
      {
        text: sentence,
        syntacticComponent: "other",
        label: "整句",
        translation: "",
        note: error || "没有生成结果。"
      }
    ],
    sentenceAnalysis: {
      skeleton: "", paraphrase: "", tone: "",
      structure: [], readingPath: [], learningPoints: []
    },
    notes: [],
    words: [], phrases: [], examples: []
  };
}

async function segmentSentence(sentence, sender) {
  const text = normalizeAnnotationSentence(sentence);
  if (!text) throw new Error("没有可断句的英文句子。");

  const settings = await getSettings();
  assertPageAnnotationAllowed(settings, sender);

  const [license, deviceId] = await Promise.all([getLicenseState(), getDeviceId()]);
  const results = await segmentSentencesWithCache(settings, [text], license?.activation_code, deviceId);
  return results[0];
}

async function segmentSentences(sentences, sender) {
  const texts = (Array.isArray(sentences) ? sentences : [])
    .map((sentence) => normalizeAnnotationSentence(sentence))
    .filter(Boolean);
  if (!texts.length) return [];

  const settings = await getSettings();
  assertPageAnnotationAllowed(settings, sender);
  const [license, deviceId] = await Promise.all([getLicenseState(), getDeviceId()]);
  return segmentSentencesWithCache(settings, texts, license?.activation_code, deviceId);
}

async function segmentSentencesWithCache(settings, texts, activationCode, deviceId) {
  const uniqueTexts = Array.from(new Set(texts.map((text) => normalizeAnnotationSentence(text)).filter(Boolean)));
  const resultsByText = new Map();
  const missing = [];

  for (const text of uniqueTexts) {
    const cacheKey = await buildSegmentationCacheKey(settings, text);
    const cached = await getCachedSegmentation(cacheKey);
    if (cached) {
      resultsByText.set(text, cached);
      continue;
    }

    const inFlight = segmentationInFlight.get(cacheKey);
    if (inFlight) {
      missing.push({ text, cacheKey, inFlight });
      continue;
    }

    missing.push({ text, cacheKey, inFlight: null });
  }

  const waitingForExisting = missing.filter((entry) => entry.inFlight);
  const pending = missing.filter((entry) => !entry.inFlight);
  const batchSize = getSentenceAnnotationBatchSize(settings);
  const chunks = chunkSentences(pending, batchSize);

  await Promise.all([
    ...waitingForExisting.map(async (item) => {
      resultsByText.set(item.text, await item.inFlight);
    }),
    runWithConcurrency(chunks, getSentenceAnnotationConcurrency(settings), async (chunk) => {
      const fresh = chunk.filter((item) => !segmentationInFlight.get(item.cacheKey));
      const alreadyRunning = chunk.filter((item) => segmentationInFlight.get(item.cacheKey));

      const alreadyRunningResults = Promise.all(alreadyRunning.map(async (item) => {
        resultsByText.set(item.text, await segmentationInFlight.get(item.cacheKey));
      }));
      if (!fresh.length) {
        await alreadyRunningResults;
        return;
      }

      const sentences = fresh.map((item) => item.text);
      const chunkPromise = fcallSegmentSentences(sentences, activationCode, deviceId);

      for (const [index, item] of fresh.entries()) {
        const itemPromise = chunkPromise
          .then((results) => results[index] || buildFallbackSegmentation(item.text))
          .then(async (result) => {
            await setCachedSegmentation(item.cacheKey, result);
            return result;
          })
          .finally(() => {
            segmentationInFlight.delete(item.cacheKey);
          });
        segmentationInFlight.set(item.cacheKey, itemPromise);
      }

      const [chunkResults] = await Promise.all([
        Promise.all(fresh.map((item) => segmentationInFlight.get(item.cacheKey))),
        alreadyRunningResults
      ]);
      for (const [index, item] of fresh.entries()) {
        resultsByText.set(item.text, chunkResults[index]);
      }
    })
  ]);

  return texts.map((text) => resultsByText.get(normalizeAnnotationSentence(text)) || buildFallbackSegmentation(text));
}

function buildFallbackSegmentation(sentence) {
  return {
    sentence,
    fallback: true,
    segments: [{ text: sentence, translation: "" }]
  };
}

async function buildSegmentationCacheKey(settings, sentence) {
  const material = JSON.stringify({
    schema: SENTENCE_SEGMENTATION_SCHEMA_VERSION,
    sentence
  });
  return `seg:${await sha256Hex(material)}`;
}

async function getCachedSegmentation(cacheKey) {
  await loadSegmentationCache();
  const entry = segmentationCache?.[cacheKey];
  if (!entry?.result) return null;
  entry.lastUsedAt = Date.now();
  return entry.result;
}

async function setCachedSegmentation(cacheKey, result) {
  if (!cacheKey || !result) return;
  if (result.fallback) return;
  await loadSegmentationCache();
  segmentationCache[cacheKey] = {
    result,
    updatedAt: Date.now(),
    lastUsedAt: Date.now()
  };
  pruneSegmentationCache();
  await chrome.storage.local.set({ [SENTENCE_SEGMENTATION_CACHE_KEY]: segmentationCache });
}

async function loadSegmentationCache() {
  if (segmentationCache && typeof segmentationCache === "object") return;
  const data = await chrome.storage.local.get(SENTENCE_SEGMENTATION_CACHE_KEY);
  const stored = data[SENTENCE_SEGMENTATION_CACHE_KEY];
  segmentationCache = stored && !Array.isArray(stored) && typeof stored === "object" ? stored : {};
}

function pruneSegmentationCache() {
  const entries = Object.entries(segmentationCache || {});
  if (entries.length <= SENTENCE_SEGMENTATION_CACHE_LIMIT) return;

  entries
    .sort((left, right) => {
      const leftTime = Number(left[1]?.lastUsedAt || left[1]?.updatedAt || 0);
      const rightTime = Number(right[1]?.lastUsedAt || right[1]?.updatedAt || 0);
      return leftTime - rightTime;
    })
    .slice(0, entries.length - SENTENCE_SEGMENTATION_CACHE_LIMIT)
    .forEach(([key]) => {
      delete segmentationCache[key];
    });
}

function normalizeAnnotationSentence(sentence) {
  return String(sentence || "").replace(/\s+/g, " ").trim();
}

function chunkArray(items, size) {
  const chunks = [];
  const chunkSize = Math.max(1, Number(size) || 1);
  for (let index = 0; index < items.length; index += chunkSize) {
    chunks.push(items.slice(index, index + chunkSize));
  }
  return chunks;
}

function chunkSentences(items, configuredSize) {
  const count = items.length;
  if (count <= configuredSize || configuredSize <= 0) return [items];

  const standardChunkCount = Math.ceil(count / configuredSize);
  const lastChunkSize = count % configuredSize || configuredSize;

  if (lastChunkSize <= 2 && standardChunkCount > 1) {
    const reducedCount = standardChunkCount - 1;
    const newSize = Math.ceil(count / reducedCount);
    return chunkArray(items, newSize);
  }

  return chunkArray(items, configuredSize);
}

function getSentenceAnnotationBatchSize(settings) {
  return normalizeBoundedInteger(
    settings.pageAnnotationBatchSize,
    DEFAULT_SETTINGS.pageAnnotationBatchSize,
    PAGE_ANNOTATION_LIMITS.batchSize
  );
}

function getSentenceAnnotationConcurrency(settings) {
  return normalizeBoundedInteger(
    settings.pageAnnotationConcurrency,
    DEFAULT_SETTINGS.pageAnnotationConcurrency,
    PAGE_ANNOTATION_LIMITS.concurrency
  );
}

async function runWithConcurrency(items, concurrency, worker) {
  if (!items.length) return;

  let nextIndex = 0;
  const workerCount = Math.min(items.length, Math.max(1, Math.floor(Number(concurrency) || 1)));
  const workers = Array.from({ length: workerCount }, async () => {
    while (nextIndex < items.length) {
      const index = nextIndex;
      nextIndex += 1;
      await worker(items[index], index);
    }
  });

  await Promise.all(workers);
}

function normalizeBoundedInteger(value, fallback, limits) {
  if (value === "" || value == null) return fallback;
  const number = Math.floor(Number(value));
  if (!Number.isFinite(number)) return fallback;
  return Math.min(limits.max, Math.max(limits.min, number));
}

async function buildSentenceAnnotationCacheKey(settings, sentence, wordLevels) {
  const material = JSON.stringify({
    schema: SENTENCE_ANNOTATION_SCHEMA_VERSION,
    sentence,
    wordLevels: Array.isArray(wordLevels) ? [...wordLevels].sort() : null
  });
  return `sentence:${await sha256Hex(material)}`;
}

async function getCachedSentenceAnnotation(cacheKey) {
  await loadSentenceAnnotationCache();
  const entry = sentenceAnnotationCache?.[cacheKey];
  if (!entry?.result) return null;
  entry.lastUsedAt = Date.now();
  return entry.result;
}

async function setCachedSentenceAnnotation(cacheKey, result) {
  if (!cacheKey || !result) return;
  if (result.fallback) return;
  await loadSentenceAnnotationCache();
  sentenceAnnotationCache[cacheKey] = {
    result,
    updatedAt: Date.now(),
    lastUsedAt: Date.now()
  };
  pruneSentenceAnnotationCache();
  await chrome.storage.local.set({ [SENTENCE_ANNOTATION_CACHE_KEY]: sentenceAnnotationCache });
}

async function loadSentenceAnnotationCache() {
  if (sentenceAnnotationCache && typeof sentenceAnnotationCache === "object") return;
  const data = await chrome.storage.local.get(SENTENCE_ANNOTATION_CACHE_KEY);
  const stored = data[SENTENCE_ANNOTATION_CACHE_KEY];
  sentenceAnnotationCache = stored && !Array.isArray(stored) && typeof stored === "object" ? stored : {};
}

function pruneSentenceAnnotationCache() {
  const entries = Object.entries(sentenceAnnotationCache || {});
  if (entries.length <= SENTENCE_ANNOTATION_CACHE_LIMIT) return;

  entries
    .sort((left, right) => {
      const leftTime = Number(left[1]?.lastUsedAt || left[1]?.updatedAt || 0);
      const rightTime = Number(right[1]?.lastUsedAt || right[1]?.updatedAt || 0);
      return leftTime - rightTime;
    })
    .slice(0, entries.length - SENTENCE_ANNOTATION_CACHE_LIMIT)
    .forEach(([key]) => {
      delete sentenceAnnotationCache[key];
    });
}

async function recordUsage(usage, annotatedSentenceCount) {
  if (!usage?.totalTokens || usage.totalTokens <= 0) return;
  const sentenceCount = Math.max(0, Number(annotatedSentenceCount) || 0);
  btLog(`recordUsage: +1 request, +${sentenceCount} sentences`);
  const stats = await loadUsageStats();
  stats.totalRequests += 1;
  stats.totalPromptTokens += usage.promptTokens || 0;
  stats.totalCompletionTokens += usage.completionTokens || 0;
  stats.totalTokens += usage.totalTokens;
  stats.totalAnnotatedSentences += sentenceCount;
  stats.recentRequests.push({
    timestamp: Date.now(),
    promptTokens: usage.promptTokens || 0,
    completionTokens: usage.completionTokens || 0,
    sentences: sentenceCount
  });
  pruneUsageStats(stats);
  await chrome.storage.local.set({ [USAGE_STATS_KEY]: stats });
}

async function getUsageStats() {
  // 仅从后端获取每日累计统计
  var deviceId = await getDeviceId();
  var cumulative = { tokens_used: 0, request_count: 0, sentence_count: 0 };
  try {
    var resp = await fetch(LICENSE_API_BASE + "/api/usage-stats?clientId=" + encodeURIComponent(deviceId));
    if (resp.ok) {
      var data = await resp.json();
      var remote = (data.data || data);
      cumulative = {
        total_tokens: Number(remote.total_tokens) || 0,
        request_count: Number(remote.request_count) || 0,
        sentence_count: Number(remote.sentence_count) || 0
      };
    }
  } catch (e) {
    btLog("getUsageStats: backend fetch failed: " + e.message);
  }

  var stats = await loadUsageStats();
  var cutoff = Date.now() - 5 * 60 * 1000;
  var recent = stats.recentRequests.filter(function (entry) { return entry.timestamp >= cutoff; });

  return {
    tokens_used: cumulative.tokens_used,
    request_count: cumulative.request_count,
    sentence_count: cumulative.sentence_count
  };
}

async function clearUsageStats() {
  const empty = {
    totalRequests: 0,
    totalPromptTokens: 0,
    totalCompletionTokens: 0,
    totalTokens: 0,
    totalAnnotatedSentences: 0,
    totalParseFailures: 0,
    recentRequests: []
  };
  await chrome.storage.local.set({ [USAGE_STATS_KEY]: empty });
  return empty;
}

function notifyLicenseUpdate() {
  try {
    chrome.runtime.sendMessage({ type: "quotaStateChanged" }).catch(function () {});
  } catch (e) { /* ignore */ }
}

function notifyQuotaExhausted() {
  notifyLicenseUpdate();
  try {
    if (chrome.sidePanel && chrome.sidePanel.open) {
      chrome.sidePanel.open().catch(function () {});
    }
  } catch (e) { /* ignore */ }
}

async function loadUsageStats() {
  const data = await chrome.storage.local.get(USAGE_STATS_KEY);
  const stored = data[USAGE_STATS_KEY];
  if (stored && typeof stored === "object" && !Array.isArray(stored)) {
    return {
      totalRequests: Math.max(0, Number(stored.totalRequests) || 0),
      totalPromptTokens: Math.max(0, Number(stored.totalPromptTokens) || 0),
      totalCompletionTokens: Math.max(0, Number(stored.totalCompletionTokens) || 0),
      totalTokens: Math.max(0, Number(stored.totalTokens) || 0),
      totalAnnotatedSentences: Math.max(0, Number(stored.totalAnnotatedSentences) || 0),
      totalParseFailures: Math.max(0, Number(stored.totalParseFailures) || 0),
      recentRequests: Array.isArray(stored.recentRequests) ? stored.recentRequests : []
    };
  }
  return {
    totalRequests: 0,
    totalPromptTokens: 0,
    totalCompletionTokens: 0,
    totalTokens: 0,
    totalAnnotatedSentences: 0,
    totalParseFailures: 0,
    recentRequests: []
  };
}

function pruneUsageStats(stats) {
  const cutoff = Date.now() - 10 * 60 * 1000;
  stats.recentRequests = stats.recentRequests.filter((entry) => entry.timestamp >= cutoff).slice(-500);
}

async function sha256Hex(text) {
  if (!crypto?.subtle) return simpleHash(text);
  const bytes = new TextEncoder().encode(String(text || ""));
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("");
}

function simpleHash(text) {
  let hash = 2166136261;
  for (const char of String(text || "")) {
    hash ^= char.charCodeAt(0);
    hash = Math.imul(hash, 16777619);
  }
  return (hash >>> 0).toString(16);
}

function serializeError(error) {
  return {
    message: redactSensitiveText(error?.message || String(error)),
    name: error?.name || "Error",
    code: error?.code || ""
  };
}

function removeAllContextMenus() {
  return new Promise((resolve) => {
    chrome.contextMenus.removeAll(() => {
      chrome.runtime.lastError;
      contextMenuReadyIds.clear();
      resolve();
    });
  });
}

function createContextMenu(options) {
  return new Promise((resolve, reject) => {
    chrome.contextMenus.create(options, () => {
      const error = chrome.runtime.lastError;
      if (error) {
        reject(new Error(error.message));
        return;
      }
      resolve();
    });
  });
}

async function updateContextMenu(id, options) {
  await ensureContextMenu(id, options);
  const result = await new Promise((resolve) => {
    chrome.contextMenus.update(id, options, () => {
      const error = chrome.runtime.lastError;
      chrome.contextMenus.refresh?.();
      resolve(error ? { ok: false, message: error.message || String(error) } : { ok: true });
    });
  });
  if (result.ok) return;
  if (!isMissingContextMenuError(result.message)) {
    console.warn("Failed to update context menu.", result.message);
    return;
  }

  contextMenuReadyIds.delete(id);
  await ensureContextMenu(id, options);
}

async function ensureContextMenu(id, options = {}) {
  if (contextMenuReadyIds.has(id)) return;
  const createOptions = getContextMenuCreateOptions(id, options);
  if (!createOptions) return;

  try {
    await createContextMenu(createOptions);
    contextMenuReadyIds.add(id);
  } catch (error) {
    const message = error?.message || String(error);
    if (/duplicate id/i.test(message)) {
      contextMenuReadyIds.add(id);
    } else {
      console.warn("Failed to create context menu.", message);
    }
  }
  chrome.contextMenus.refresh?.();
}

function getContextMenuCreateOptions(id, overrides = {}) {
  if (id === MENU_ID) {
    return {
      id: MENU_ID,
      title: "语法分析",
      contexts: ["selection"],
      ...overrides
    };
  }

  if (id === SITE_TOGGLE_MENU_ID) {
    return {
      id: SITE_TOGGLE_MENU_ID,
      title: "启用BeyondTranslation",
      contexts: ["page"],
      documentUrlPatterns: ["http://*/*", "https://*/*"],
      ...overrides
    };
  }

  return null;
}

function isMissingContextMenuError(message) {
  return /Cannot find menu item|找不到.*菜单|menu item.*not found/i.test(String(message || ""));
}
